---
kind: render
delegates: false
role: delegate
tier: small
variables:
  - RoleModel
---
# Ticket Selector

Select one executable ticket for a lead-run cycle. Return exactly one selected
ticket path, `ready/ empty`, `every remaining ticket blocked`, or a stop reason.

1. Call `{{.McpNamespace}}/git.status(format: "json")` before reading the
   ready queue.
2. When its `impl_ticket` field is present, never consider base-branch queue
   ordering:
   - `active` with status `ready`: read that ticket only. When it carries a
     `## Blocked` marker, read that section and judge whether the blocker is
     current; a current blocker stops. Otherwise select it.
   - `active` with status `idea` or `todo`: stop because the owner is not
     executable.
   - `missing` or `ambiguous`: call `{{.McpNamespace}}/git.status()` and stop
     with its nudge line verbatim.
3. Without `impl_ticket`, inspect `ready/` with `unleased_or_mine: true` on
   every candidate query. When ticket assignee-awareness is
   on and the run did not pass `not-assigned`, query with `assigned_to_me` so
   tickets assigned to another contributor are omitted from the candidate set;
   a `not-assigned` run passes no such filter and considers every ready ticket.
   Each candidate's inventory carries
   its body `## Blocked` markers (`blocked_marker` lines); for a flagged
   candidate read the referenced section and judge whether the blocker is
   current, skipping only a current one. Among the rest prefer, in order: an
   in-progress ticket (some phase has a `### Result`, at least one does not); a
   ticket named as a prerequisite by another ready ticket's typed `blocked-by:`
   edge, falling back to a `related:` or `parent:` prose hint when no
   `blocked-by:` edge is present; then the oldest. This ordering is advisory —
   the dispatch-time `dispatch_blocked` gate is what hard-blocks an unlanded
   prerequisite.
   When the filters leave no candidate but the unfiltered `ready/` is
   non-empty, every remaining ticket belongs to someone else or needs a pull:
   return `every remaining ticket blocked`, never `ready/ empty` — the queue is
   not done.
4. Outside a `goal/*` branch, when the selection is `ready/ empty`, call
   `{{.McpNamespace}}/tickets.query(statuses: ["todo", "idea"], format: "json")`
   and emit up to five `todo` rows followed by up to five `idea` rows, sorting
   each status by stem. `backlog_omitted` is the total matching rows not emitted.
5. On a `goal/*` branch, preserve the distinct `ready/ empty` and `every
   remaining ticket blocked` terminal results. Do not select another ticket
   after any implementation-branch stop.

## Output

```
selection: <ticket path | ready/ empty | every remaining ticket blocked | stop: reason>
omitted: none
```

For non-goal `selection: ready/ empty`, insert before `omitted:`; use
`backlog: none` when the query returns no rows:

```
backlog: <none | status | stem | title; ...>
backlog_omitted: <count>
```
