---
kind: print
---

# Bootstrap

Mode: user request

## Invariants

- Template sources are `AGENTS.template.md` and `WORKFLOW.md` in this skill directory; read both before any action.
- Canonical downstream workflow context is `AGENTS.md`.
- `CLAUDE.md` is a compatibility shim whose body is `@AGENTS.md`.
- Never overwrite project-specific sections: Architecture Rules, custom Code Standards entries, custom Project Knowledge entries.
- Merge surgically; flag unresolved conflicts inline with `<!-- CONFLICT: ... -->`.
- Every migration item is idempotent; re-running on an already-migrated project produces no changes.
- Index health checks are legacy/coexistence-only, apply only when a project still has `ai-docs/_index.md`, and are advisory; first pass reads `_index.md` only.
- Index cleanup writes only `ai-docs/_index.md`, when present; semantic migration routes through owning workflow skills.
- Commit each logical unit separately following the repository commit rules.
- A project tag above this skill's own `AGENTS.template.md` head, or one that does not parse, is a stop-and-report condition (see `## On: refuse`) enforced only by this instruction and the code-level staleness warning; there is no mechanical block on reconcile/restamp.

## On: invoke

1. Read `AGENTS.template.md` and `WORKFLOW.md`.
2. Read downstream `AGENTS.md` if it exists.
3. Read downstream `CLAUDE.md` if it exists.
4. Detect mode:
   - **fresh** - neither root file exists.
   - **upgrade** - `AGENTS.md` has `<!-- Template Version: vNNNN -->` at or below this skill directory's own `AGENTS.template.md` head.
   - **refuse** - `AGENTS.md` has a `Template Version` marker whose value is above this skill directory's own `AGENTS.template.md` head, or one that does not parse as `vNNNN` at all.
   - **adopt** - `AGENTS.md` exists without a version tag.
   - **claude-migrate** - `CLAUDE.md` exists and `AGENTS.md` does not.
5. Execute the matching handler.
6. Run the index health check when `ai-docs/_index.md` exists.
7. Unless the mode was refuse, run the ticket ownership index check.

## On: fresh

1. Copy template to `AGENTS.md`, stripping template-internal migration blocks.
2. Leave placeholder markers in project-specific sections.
3. Create `ai-docs/` structure per the template setup block.
4. Copy `WORKFLOW.md` to `ai-docs/WORKFLOW.md`.
5. Add `ai-docs/**/*.local.md` and `ai-docs/.deps/` to `.gitignore` if absent.
6. Create `ai-docs/.old/` as a tracked project archive when project archive material exists.
7. Set `<!-- Template Version: vNNNN -->` to the latest version from the template.
8. Write `CLAUDE.md` with body `@AGENTS.md`.
9. Commit scaffolding.
10. Suggest declaring `### Implementation Conventions` when the project has path-scoped rules, and creating the first ticket through `{{.SkillNamespace}}:lead-ticket`.

## On: upgrade

1. Parse current version from `AGENTS.md`.
2. Walk migration checklist items where version > current, in order.
3. Apply each item only when its condition is met.
4. Update `AGENTS.md` template-managed sections from `AGENTS.template.md`.
5. Ensure `ai-docs/WORKFLOW.md` exists from `WORKFLOW.md`; if a project-local guide already exists, preserve project additions and only merge missing bootstrap semantics.
6. Preserve or merge project-specific sections.
7. Ensure `CLAUDE.md` body is `@AGENTS.md`.
8. Update the template version tag.
9. Commit.

## On: refuse

1. Stop before making any change.
2. Do not update `AGENTS.md`, `WORKFLOW.md`, or `CLAUDE.md`.
3. Do not update the version tag.
4. Do not commit.
5. Report the mismatch to the user: the on-disk `AGENTS.md` tag versus this package's own `AGENTS.template.md` head, and whether the tag was above-head or unparseable.
6. Ask the user how to proceed.
7. Restate that this refusal is an agent-followed instruction backed by the code-level staleness warning, not a mechanical hard-block on reconcile/restamp.

## On: adopt

1. Audit v0001 through latest against current project state.
2. Apply only missing migration items.
3. Add the latest template version tag to `AGENTS.md`.
4. Proceed to the upgrade handler.

## On: claude-migrate

1. Create `AGENTS.md` from existing `CLAUDE.md` content.
2. Preserve project-specific sections and all existing template-version evidence.
3. Apply the AGENTS migration checklist in order.
4. Replace `CLAUDE.md` body with `@AGENTS.md`.
5. Preserve no separate Claude-only section unless explicitly requested.
6. Commit.

## On: ticket ownership index check

The ticket ownership index is an optional ref on `origin` that records which
person, clone, and branch holds each open ticket, so collaborators do not pick
up the same ticket. Call `{{.McpNamespace}}/tickets.index_init(check: true)`
and handle its `state:`:

- `uninitialized`: explain what the index does, and that setting it up pushes
  one ref to `origin` with the user's credentials and publishes each holder's
  git email there. Ask whether to set it up now. On yes, call
  `{{.McpNamespace}}/tickets.index_init()`; when it fails, report the failure
  and finish the rest of bootstrap. On no, change nothing; a later bootstrap
  run asks again.
- `initialized`: one line saying the index is active.
- `no-origin`: one line saying the index can be set up by re-running bootstrap
  once an `origin` remote exists.
- `unreachable`: one line saying the check could not reach `origin`.

## On: index health check

`ai-docs/_index.md` is a legacy all-in-one memory file; current projects
route orientation to `AGENTS.md`, procedures to `ai-docs/manuals/`, session
notes to the `repo` note layer, and inventories to generated output, and do
not have one. This flow only runs when a project still has one (gated by
`## On: invoke` step 6).

1. Read `ai-docs/_index.md`.
2. Apply **judge: index-scope-drift** as a cheap first pass.
3. Do not read the full document corpus for this pass.
4. Do not move semantic content into manuals, tickets, or refs.
5. Emit a concise health note when drift candidates exist.
6. When candidates exist, ask whether to clean up `_index.md` now, defer cleanup, or route semantic follow-up.
7. Route user-approved second passes by the table below.

| Finding | Route |
|---------|-------|
| Source-derived detail | Compact to source pointers; use `{{.SkillNamespace}}:lead-discuss` if meaning is unclear |
| Behavior inventory | Compact to the tests and source that already state the behavior |
| Modification knowledge | Prescriptive convention to `ai-docs/manuals/`; site-specific trap to a code comment at the site |
| Static reference material | Compact to `ai-docs/ref/` or API-doc pointers |
| Procedure or how-to content (has a one-line applicability description) | Move to `ai-docs/manuals/` with a `summary:` frontmatter line equal to that description |
| Project reading map | `AGENTS.md`'s `## Project Orientation` section, or `{{.SkillNamespace}}:lead-discuss` when mixed with status claims |
| Focus or ticket ordering | the lead-ticket procedure |
| Work history | Compact to Git history, ticket archives, or roadmap pointers |
| Duplicated doc map | Compact to start-here pointers |
| Ambiguous project direction | `{{.SkillNamespace}}:lead-discuss` |

## On: user approves index cleanup

1. Re-read `ai-docs/_index.md`.
2. Preserve the memory-policy comment.
3. Keep summary, stack, workspace, build/test commands, read-before-edit pointers, active inventory, and compact notes.
4. Compact deep sections into links only when a clear owning document already exists.
5. Leave unique project direction, active priorities, and unresolved operational caveats in place.
6. Do not author or semantically update manuals, tickets, or refs.
7. Report each compacted section with its replacement path or retained-note reason.

## Judgments

### judge: section-merge

| Decision | When |
|----------|------|
| Replace | Project section is identical to the old template or only trivially reformatted |
| Merge | Project section has meaningful additions that do not conflict with the new template |
| Conflict marker | Project section and template give incompatible instructions |

### judge: migration-condition

| Decision | When |
|----------|------|
| Skip | No matching files or no project state exists for the condition |
| Apply subset | Some matching files need the migration and others already satisfy it |
| Apply all | The condition is met across the affected project state |

### judge: index-scope-drift

Cheap `_index.md` scan only; report candidates, not confirmed defects.

| Candidate | Signal |
|-----------|--------|
| Source-derived detail | Deep source tree, file-by-file roles, type listings, or implementation inventory |
| Behavior inventory | Long "what works" lists, player-visible behavior descriptions, or feature semantics |
| Modification knowledge | Data flows, lifecycle narratives, extension recipes, common mistakes, audit/logging rules |
| Static reference material | Dependency API notes, archived design excerpts, or long external-reference summaries |
| Project reading map | Stable task/topic -> docs routing maps mixed into `_index.md`; feature or status claims remain behavior inventory |
| Work history | Done/dropped tickets, completed milestones, or stale session chronology |
| Duplicated doc map | Long manual, module, or ticket indexes beyond start-here pointers |

## Templates

### CLAUDE.md compatibility shim

```markdown
@AGENTS.md
```

## Doctrine

Bootstrap optimizes for **idempotent downstream migration**: preserve
project-specific content, apply only missing versioned migrations, and keep
Claude compatibility as a shim over host-neutral `AGENTS.md`. When ambiguous,
preserve idempotency and downstream content.
