import type { MailItem, OwnPrompt } from './captions'
import type { InboxCommand, InboxItem } from './dashboard'

/**
 * Pure mailbox-push controller for the Claude Code mod in register.ts; the
 * Claude counterpart of the pi adapter's mailbox waiter.
 *
 * `mailbox wait` only PEEKS: streaming emits JSONL arrivals; the one-shot
 * fallback exits 0 for mail, 3 for timeout, 130 for interruption, or another
 * code for error. It is purely the block-until-mail signal. Draining is
 * mailbox recv's job, in one of two modes:
 *
 * - `direct`: the controller drains through recv itself and submits exactly
 *   what recv removed as ONE prompt, so a re-arm never re-delivers the same
 *   mail. A refused drain falls back to the notice path; any other failed
 *   drain backs off and retries, since the mail stays queued. Once recv
 *   answered with mail, the loop is that mail's only holder: anything that
 *   keeps it from being submitted (a failed submit, a stop while the drain
 *   was in flight, or a crash before it is handed to the submit path) writes
 *   it to the user-visible `record` instead.
 * - `notice`: the controller never drains. It submits one notice asking the
 *   model to call recv, then suspends: the peek would exit at once over the
 *   still-queued mail, so the loop re-arms only when the model's own recv for
 *   the bound key completes successfully (`recvCompleted`). One arrival
 *   yields one notice, and a declined recv leaves the loop suspended rather
 *   than re-noticing.
 *
 * Either mode's prompt (the batch or the notice) goes by the turn state when
 * it is ready. While the session is idle it is submitted and starts a turn.
 * While a main-thread turn runs it is queued instead and joins that turn:
 * everything queued by the next tool boundary (`toolCompleted`) is appended
 * as ONE row, which the turn's next model request reads, and anything still
 * queued when the turn ends (`turnCompleted`) is submitted as ONE prompt. A
 * queued batch still holds drained mail, so a refused row, a turn-end
 * prompt neither submitted nor appended, or a stop records it as above; a lost notice is retried as a
 * failed notice submit is.
 *
 * Every submit (an idle batch or notice, the turn-end leftovers) that the
 * host rejects or drops falls back to appending the same text as a row: the
 * host drops a plugin's submit after the person stops a turn until they send
 * input, and a row appended while idle reaches the model with their next
 * prompt. Only when that append fails too does the text count as lost.
 *
 * Board messages (the `board` edges, present while the dashboard knob reads
 * on): the messages the user sends from the dashboard page, held in the
 * session's board-answer inbox until the mod drains them. The same wait also
 * wakes on a held one (its board flag), and the drain is an atomic claim, so
 * each message is submitted once. A wake while idle drains and submits at
 * once, as the user's own message. A wake while a main-thread turn runs, or
 * while the main conversation compacts, drains nothing: the message stays
 * held, so the page can still cancel or steer it, and the wait
 * re-arms without the flag, since it only peeks and would wake again at once.
 * Every main-thread turn end drains whatever is held, submits it, and re-arms
 * the wait with the flag; a tool boundary never does. What is held when a
 * compaction ends (a turn end during it leaves its board part held too) is
 * released only after any compaction continuation the mod queued
 * (`continuation`, waited on at most COMPACTION_CONTINUATION_WAIT_MS): when a
 * main-thread turn runs by then (the continuation's, or one the person
 * started), its turn end takes it; otherwise it is drained and submitted as a
 * turn end would. A main-thread turn end that carried a successful call of
 * the compaction lever (`leverPending`) holds its board part for the
 * compaction the lever requested, LEVER_HOLD_MS at most: the compaction's
 * start hands the held messages to its release above, and when no
 * compaction started by the cap they are released as a turn end would, or
 * left for the end of a turn that runs by then. The next main-thread turn
 * end lifts the hold too. A board wake meanwhile holds its message as one
 * during a running turn does, and the mail still queued at that turn end is
 * submitted as usual. The held board message goes ahead of the mail still queued
 * at that turn end: mail is delivered once the board drain and submit settle (or
 * BOARD_FIRST_WAIT_MS passes), so the user's own message starts the next turn
 * and the mail joins it as the mail path delivers it. A board submit the host
 * drops or rejects is appended as a row instead, and only when that fails too
 * is the message recorded for the user. A crash between the drain and the
 * submit loses the message, the same gap mail has.
 *
 * A drain may also claim slash command entries (the page's command picker),
 * each in its place among the messages. A command splits the batch and is
 * never joined with text, labelled, or appended as a row: for text A, command
 * C, text B the flush submits A as above, then runs C (`run`; the host queues
 * it until the session is idle, so it runs after A's turn), and only once C's
 * run settled goes on with B. B and everything claimed after it wait in this
 * controller (the backlog) meanwhile, although the inbox already shows them
 * drained: a flush while a command runs claims into the backlog and submits
 * nothing. When the run settles while a main-thread turn runs or the main
 * conversation compacts, the backlog is held as a held message is (that turn
 * end, or the compaction's release, takes it); otherwise it goes on at once.
 * A stop records the backlog's texts and typed lines for the user. Since a
 * command is only drained where a message would be submitted, one sent while
 * a turn runs or a compaction holds waits for that turn end or release.
 *
 * A held message the user promoted to steering is the one exception to
 * holding it for the turn end: every main-thread tool boundary (while board
 * submission is on) claims the steered messages alone (`drainSteer`) and
 * appends them as one user row (`steer`) before the queued mail row, so the
 * turn's next model request reads them; a promoted message may overtake held
 * ones. When the host refuses that row, the claimed texts are carried to the
 * turn end and go out ahead of what the turn-end drain claims, so a steered
 * message is never lost after its claim; a stop records them instead. The
 * boundary waits on that drain at most STEER_DRAIN_WAIT_MS: past it the
 * boundary claims nothing (the messages stay held for the turn end), no later
 * boundary starts another drain while it is out, and whatever it claims late
 * is carried as a refused row's texts are. A steer row the turn ends without
 * any model request reading (the person refused or interrupted the call) is
 * submitted again at that turn end, ahead of the carried ones; that submit
 * never falls back to another row, since the first still rides the next
 * prompt.
 *
 * The page's interrupt (the user asking it to stop the running turn) reaches
 * the same inbox as an interrupt entry, never a message. While board
 * submission is on, every wait also wakes on one (its interrupt flag, idle
 * or mid-turn, beside or without the board flag), and such a wake is never
 * read as a board message: the loop claims the interrupt entries alone
 * (`drainInterrupt`) and, when a main-thread turn runs that started before
 * the newest of them was made, aborts that turn. An entry claimed while no
 * main-thread turn runs, or older than the running turn (a click that landed
 * as the last turn ended), is dropped, so an interrupt never cuts a turn it
 * was not meant for; a rejected abort (the turn had already ended) is only
 * logged. Before asking for the abort the loop marks the session
 * interrupted, since the turn end can come before the abort settles, and the
 * mark lasts until the next main-thread turn starts (`turnStarted`). While it
 * stands, nothing the cut turn leaves behind starts a turn: mail still queued
 * at its end is appended as one row, a steered row no request read stays
 * where it is, and carried steered texts become a row; the next prompt
 * carries them all. Held messages the turn-end drain newly claims were sent
 * after the click (the page took every earlier one back) and are submitted
 * as usual, as is mail that arrives once the session is idle.
 *
 * Every side effect is an injected edge so the loop is testable without a
 * live mailbox or engine.
 */

/** What woke a wait that ended with an arrival: mail, a held board message, or both. */
export type WakeKind = 'mail' | 'board' | 'both'

/**
 * A wait's outcome; `board` and `both` say a held board message woke it,
 * alone or with mail. An interrupt entry is its own outcome, never a board
 * message: `also` names whatever else woke the same wait.
 */
export type WaitOutcome = WakeKind | 'timeout' | 'stopped' | 'error' | { interrupt: true; also?: WakeKind }

/** A wait's board flags: `board` also wakes it on a held board message, `interrupt` on an interrupt entry. */
export interface WaitFlags {
  board: boolean
  interrupt: boolean
}

/** The running main-thread turn as the interrupt sees it. */
export interface MainTurn {
  /** When it started, epoch ms on the clock an interrupt entry's creation time is read on. */
  startedAt: number
  /** Abort it; rejects when it is no longer the running turn. */
  abort: () => Promise<void>
}

export type DrainMode = 'direct' | 'notice'

export interface MailboxEnvelope {
  from?: string
  reply_to?: string
  label?: string
  content: string
  sent_at?: string
}

/** One drained item: an envelope, or recv output that is not one, delivered verbatim rather than dropped. */
export type DrainedMail = MailboxEnvelope | { raw: string }

/** One drain attempt: what recv removed, a refusal (permission or hook deny), or another failure. */
export type DrainResult =
  | { kind: 'mail'; mail: DrainedMail[] }
  | { kind: 'refused'; reason: string }
  | { kind: 'failed'; reason: string }

/** The board-message side: the session's board-answer inbox. */
export interface BoardEdges {
  /** Whether board submission is on now (the dashboard knob); read at every wait arm and turn end. */
  enabled: () => boolean
  /** Claim every held message of `key`'s inbox, in queue order (steered first, in the order promoted, then the rest, oldest first): their texts, a command entry in its place. Rejects when the drain failed. */
  drain: (key: string) => Promise<InboxItem[]>
  /**
   * Run a claimed slash command entry as if typed (the host queues it until
   * the session is idle) and report its outcome to the dashboard; resolves
   * once the run settled, rejects when the host refused it.
   */
  run: (command: InboxCommand) => Promise<void>
  /**
   * Submit the drained messages as one prompt, the user's own; rejects when
   * it did not reach the conversation. The first `shown` texts are steered
   * messages already in the conversation as a row no model request read, and
   * already recorded as the user's: submitted again only so a turn reads them.
   */
  submit: (texts: readonly string[], shown: number) => Promise<void>
  /** Append the same prompt as a user row instead, and record it as the user's; rejects when refused. */
  append: (texts: readonly string[]) => Promise<void>
  /** Claim only the held messages of `key`'s inbox promoted to steering, in steer order (the order promoted): their texts. Rejects when the drain failed. */
  drainSteer: (key: string) => Promise<string[]>
  /**
   * Append steered messages into the running turn as one user row, the
   * user's own, and record them in the dashboard conversation; rejects when
   * the row was refused.
   */
  steer: (texts: readonly string[]) => Promise<void>
  /**
   * Claim the interrupt entries of `key`'s inbox: each one's creation time,
   * epoch ms on the clock `mainTurn` reads. Rejects when the drain failed.
   */
  drainInterrupt: (key: string) => Promise<number[]>
  /** The running main-thread turn; undefined while none runs. */
  mainTurn: () => MainTurn | undefined
}

export interface WatcherEdges {
  mode: DrainMode
  /** Prefix for notice and prompt lines (`<plugin> mailbox`). */
  label: string
  /**
   * Await one arrival for `key`, adding the binding's named inbox `slug`,
   * and with `flags` also waking on a held board message or interrupt entry.
   * `signal` aborts this arm; `bindingSignal` also closes a cached stream
   * between arms (while a drain or notice is pending).
   */
  wait: (key: string, slug: string | undefined, flags: WaitFlags, signal: AbortSignal, bindingSignal: AbortSignal) => Promise<WaitOutcome>
  /** Drain via mailbox recv (direct mode only). */
  drain: (key: string) => Promise<DrainResult>
  /**
   * Submit one prompt, the given prompts joined, that starts a turn once the
   * session is idle; rejects when it did not reach the conversation. May
   * instead store and submit nothing: `busy` when a main-thread turn started
   * first (the prompts belong to that turn), `stale` when `live` read false.
   */
  submit: (prompts: readonly OwnPrompt[], live: () => boolean) => Promise<'busy' | 'stale' | void>
  /**
   * Whether a main-thread turn runs now: a prompt ready then is queued for
   * that turn's next tool boundary or its end rather than submitted.
   */
  turnRunning: () => boolean
  /**
   * Append one user row, the given prompts joined: a running main-thread
   * turn's next model request reads it, and while idle it rides the person's
   * next prompt. Rejects when refused.
   */
  append: (prompts: readonly OwnPrompt[]) => Promise<void>
  /** The recv tool's name as the model calls it, for prompt text. */
  recvTool: () => string
  /** Resolve after `ms`, or early (resolve, not reject) when `signal` aborts. */
  sleep: (ms: number, signal: AbortSignal) => Promise<void>
  /** Show the user (never the model) one line, once: only state changes reach it, never every re-arm. */
  notice: (text: string) => void
  /** Show the user (never the model) drained mail that could not be submitted. */
  record: (text: string) => void
  log: (text: string) => void
  /** Board messages; absent, the wait never carries a board flag and nothing is drained. */
  board?: BoardEdges
  /**
   * Resolves once no compaction continuation the mod queued is pending (the
   * compaction lever's resume prompt held, or its submit not yet settled);
   * absent, none is ever pending.
   */
  continuation?: () => Promise<void>
  /**
   * Read at a main-thread turn end, before the compaction feature hears of
   * it: whether that turn carried a successful compaction lever call whose
   * compaction is still owed, so the turn end holds the board messages for
   * it (LEVER_HOLD_MS at most). Absent, no turn end holds.
   */
  leverPending?: () => boolean
}

export type BindResult = 'bound' | 'unchanged' | 'rebound'

export const BACKOFF_MIN_MS = 1_000
export const BACKOFF_MAX_MS = 60_000
export const EMPTY_DRAIN_BACKOFF_MS = 2_000
/** At a turn end, the longest the queued mail waits for the held board message to go first. */
export const BOARD_FIRST_WAIT_MS = 5_000
/** At a tool boundary, the longest the tool result waits on the steered board message drain. */
export const STEER_DRAIN_WAIT_MS = 2_000
/** At a compaction end, the longest held board messages wait for a compaction continuation to go first. */
export const COMPACTION_CONTINUATION_WAIT_MS = 10_000
/** After a turn end that carried a compaction lever call, the longest board messages wait for that compaction to start. */
export const LEVER_HOLD_MS = 5_000

export function nextBackoff(prev: number): number {
  return prev <= 0 ? BACKOFF_MIN_MS : Math.min(prev * 2, BACKOFF_MAX_MS)
}

/** Map a finished `mailbox wait` child to an outcome (the pi adapter's mapMailboxWaitExit). */
export function mapWaitExit(code: number | null, aborted: boolean): WaitOutcome {
  if (aborted) return 'stopped'
  if (code === 0) return 'mail'
  if (code === 3) return 'timeout'
  // 130 (external SIGINT/SIGTERM) is deliberately an error, not stopped: a
  // stop we did not cause must not silently end push for the session.
  return 'error'
}

function isEnvelope(c: unknown): c is MailboxEnvelope {
  return !!c && typeof c === 'object' && typeof (c as { content?: unknown }).content === 'string'
    && ((c as { label?: unknown }).label === undefined || typeof (c as { label?: unknown }).label === 'string')
}

/**
 * Parse recv's `format: "json"` text: a bare array of envelopes, `null` when
 * empty. Recv has already removed whatever it returned, so only blank text,
 * `null`, or an empty array is an empty drain; text that is not an array, and
 * array elements that are not envelopes, come back verbatim as `raw`.
 */
export function parseRecvText(text: string | undefined): DrainedMail[] {
  const trimmed = text?.trim() ?? ''
  if (trimmed === '' || trimmed === 'null') return []
  let parsed: unknown
  try {
    parsed = JSON.parse(trimmed)
  } catch {
    return [{ raw: trimmed }]
  }
  if (!Array.isArray(parsed)) return [{ raw: trimmed }]
  return parsed.map((c): DrainedMail => (isEnvelope(c) ? c : { raw: JSON.stringify(c) }))
}

/**
 * The envelopes a recv drain returned, so a `--stream` arrival line buffered
 * before that drain does not wake the session again for mail it already
 * received. A line is matched by its envelopes (`sent_at` and `content`,
 * the fields recv's text and JSON forms both carry), with multiplicity; each
 * match is consumed. Only a line whose every mail envelope was received loses
 * its `mail` kind: mail that arrived after the drain still wakes at once, and
 * such a line clears the ledger, since nothing after it predates the drain.
 * Envelopes of lines already passed through (the line that woke the drain)
 * are not recorded: no later line reports them, and a stale record could
 * match an identical later message (same second, same text) and swallow it.
 */
export interface DrainLedger {
  /** Record what a drain received; items that are not envelopes are ignored. */
  record: (mail: readonly DrainedMail[]) => void
  /** The arrival line with an already-received `mail` kind removed; undefined when nothing is left to wake for. */
  filter: (line: string) => string | undefined
  /** Forget every record: a new stream child reports only mail still queued. */
  clear: () => void
}

const DRAIN_LEDGER_MAX = 1_000

export function createDrainLedger(): DrainLedger {
  const counts = new Map<string, number>()
  // Envelopes of lines passed through since the last record.
  const delivered = new Map<string, number>()
  const keyOf = (m: { sent_at?: unknown; content: string }) => `${typeof m.sent_at === 'string' ? m.sent_at : ''}\u0000${m.content}`
  const take = (map: Map<string, number>, key: string) => {
    const n = map.get(key) ?? 0
    if (n === 1) map.delete(key)
    else if (n > 1) map.set(key, n - 1)
    return n > 0
  }
  const add = (map: Map<string, number>, key: string) => {
    // Bounded: an entry no line ever matched only lingers until the next child.
    if (map.size >= DRAIN_LEDGER_MAX) map.clear()
    map.set(key, (map.get(key) ?? 0) + 1)
  }
  return {
    record(mail) {
      for (const m of mail) {
        if (!('content' in m) || typeof m.content !== 'string') continue
        const key = keyOf(m)
        if (!take(delivered, key)) add(counts, key)
      }
      delivered.clear()
    },
    filter(line) {
      let parsed: { kinds?: unknown; named?: unknown; reply?: unknown }
      try {
        parsed = JSON.parse(line) as typeof parsed
      } catch {
        return line
      }
      const kinds = parsed?.kinds
      if (!Array.isArray(kinds) || !kinds.includes('mail')) return line
      const envelopes = [parsed.named, parsed.reply].flatMap((list) => (Array.isArray(list) ? list : []))
      if (envelopes.length === 0) return line
      let covered = true
      for (const e of envelopes) {
        if (!isEnvelope(e)) {
          covered = false
          continue
        }
        const key = keyOf(e)
        if (take(counts, key)) continue
        covered = false
        add(delivered, key)
      }
      if (!covered) {
        // Mail the drain did not get arrived after it, so every later line is
        // newer than the drain too: forget its records, or one could match
        // an identical later message and swallow its wake.
        counts.clear()
        return line
      }
      const rest = kinds.filter((k) => k !== 'mail')
      return rest.some((k) => ['board', 'interrupt'].includes(k)) ? JSON.stringify({ ...parsed, kinds: rest }) : undefined
    },
    clear() {
      counts.clear()
      delivered.clear()
    },
  }
}

/**
 * The envelopes in a recv result as the model reads it: the `format: "json"`
 * array, or the text form's `[<sent_at>] <sender>: <content>` entries (only
 * `sent_at` and `content` are kept). Anything else yields none.
 */
export function recvResultMail(text: string | undefined): DrainedMail[] {
  const parsed = parseRecvText(text)
  if (parsed.length !== 1 || 'content' in parsed[0]!) return parsed
  const raw = parsed[0]!.raw
  const head = /^\[([^\]\n]+)\] [^\n]*?: /gm
  const found: { sent_at: string; start: number; end: number }[] = []
  for (let m = head.exec(raw); m !== null; m = head.exec(raw)) found.push({ sent_at: m[1]!, start: m.index, end: m.index + m[0].length })
  return found.map((h, i) => ({ sent_at: h.sent_at, content: raw.slice(h.end, i + 1 < found.length ? found[i + 1]!.start - 1 : raw.length) }))
}

const field = (v: unknown): string => (typeof v === 'string' ? v.trim() : '')

/** One envelope as the pi adapter frames it: `mail from <handle> (<sent_at>):` then the body. */
export function formatEnvelope(m: DrainedMail): string {
  if (!('content' in m)) return `unparsed mailbox recv output:\n${m.raw}`
  const handle = field(m.from) || field(m.reply_to) || field(m.label) || 'unknown'
  const stamp = field(m.sent_at)
  return `${stamp ? `mail from ${handle} (${stamp})` : `mail from ${handle}`}:\n${m.content}`
}

/** One prompt for the whole drained batch, never one per envelope. */
export function formatBatch(label: string, recvTool: string, key: string, mail: readonly DrainedMail[]): string {
  const head =
    `[${label}] ${mail.length} message(s) arrived for session_key ${key}. ` +
    `They were already received through ${recvTool}; do not call it again for these.`
  return [head, ...mail.map(formatEnvelope)].join('\n\n')
}

/** The notice-path prompt: the model drains through its own permission flow. */
export function formatNotice(label: string, recvTool: string, key: string): string {
  return `[${label}] Mail is waiting for session_key ${key}. Call ${recvTool} with session_key ${key} to receive it.`
}

/** A drained item as a caption unit reads it: its sender's handle (as formatEnvelope names it) and its body. */
export function mailItems(mail: readonly DrainedMail[]): MailItem[] {
  return mail.map((m) =>
    'content' in m ? { from: field(m.from) || field(m.reply_to) || field(m.label) || 'unknown', body: m.content } : { from: 'unparsed recv output', body: m.raw },
  )
}

/**
 * The one-liner a batch shows the person while captions are on: the count and
 * the senders, each once, a peer-supplied handle kept to one printable line.
 */
export function batchLine(label: string, mail: readonly DrainedMail[]): string {
  const senders = [...new Set(mailItems(mail).map((m) => m.from.replace(/[\s\u0000-\u001f\u007f]+/g, ' ')))]
  return `[${label}] ${mail.length} ${mail.length === 1 ? 'message' : 'messages'} from ${senders.join(', ')}`
}

/** The one-liner the notice-path prompt shows the person while captions are on. */
export function noticeLine(label: string): string {
  return `[${label}] mail waiting`
}

/** A drained batch as one of the mod's own prompts: its text, its one-liner, and its mail for a recap. */
export function batchPrompt(label: string, recvTool: string, key: string, mail: readonly DrainedMail[]): OwnPrompt {
  return { text: formatBatch(label, recvTool, key, mail), line: batchLine(label, mail), mail: { tag: `[${label}]`, items: mailItems(mail) } }
}

/** The notice-path prompt as one of the mod's own prompts. */
export function noticePrompt(label: string, recvTool: string, key: string): OwnPrompt {
  return { text: formatNotice(label, recvTool, key), line: noticeLine(label) }
}

/** The label the mailbox's prompts carry in brackets: `<plugin> mailbox`. */
export function mailboxLabel(plugin: string): string {
  return `${plugin} mailbox`
}

export interface Watcher {
  /** Arm the loop for `key`, waking on its reply-id queue and, when given, the named inbox `slug`. */
  bind: (key: string, slug?: string) => BindResult
  stop: (reason: string) => void
  current: () => string | undefined
  /** Whether the loop for the current key waits on the model's recv after a notice. */
  isSuspended: () => boolean
  /** The model's own recv for `key` completed successfully: resume a loop suspended on that key. */
  recvCompleted: (key: string) => void
  /**
   * A model-issued main-thread tool call completed: append the board
   * messages promoted to steering, then everything queued, each as one row
   * before its result returns, so the request that follows the result reads
   * them. Never rejects.
   */
  toolCompleted: () => Promise<void>
  /** A main-thread model request started: every steer row appended so far is read. */
  requestStarted: () => void
  /**
   * The main-thread turn ended: drain and submit the held board messages,
   * then submit whatever mail is still queued as one prompt, else append it;
   * after an interrupt, only the newly drained board messages are submitted
   * and the rest is appended. A turn that carried a compaction lever call
   * (`leverPending`) holds the board messages for that compaction instead
   * (LEVER_HOLD_MS at most); its mail is submitted as usual. Never throws.
   */
  turnCompleted: () => void
  /** A main-thread turn started: the interrupted mark, if any, is cleared. */
  turnStarted: () => void
  /** A main-conversation compaction began: board messages are held until it ends, and a lever hold is handed to that end. */
  compactStarted: () => void
  /**
   * That compaction settled (landed, vetoed, or failed): once any compaction
   * continuation went first, the held board messages are released as a turn
   * end releases them. Never throws.
   */
  compactEnded: () => void
  /** The board switch may have changed: a running wait whose board flags no longer match is re-armed. */
  boardChanged: () => void
}

/**
 * A prompt queued for the running turn, and what to do should it never reach
 * the model; `noticeFor` marks a notice, withdrawn once the model has
 * received that key's mail on its own.
 */
type Queued = { prompt: OwnPrompt; lost: (why: string) => void; noticeFor?: string }

export function createWatcher(edges: WatcherEdges): Watcher {
  let key: string | undefined
  let slug: string | undefined
  let ctrl: AbortController | undefined
  let suspended: { key: string; resume: () => void } | undefined
  // A stop ends delivery and a rebind does not, but both only abort a loop:
  // a loop compares this count with the one it started under to learn
  // whether a stop came since, even when a rebind had already superseded it.
  let stops = 0
  let lastStop = ''
  /**
   * Prompts waiting for the running turn's next tool boundary or its end.
   * Session-wide, not per loop: a rebind keeps them, a stop gives them up.
   */
  let queued: Queued[] = []
  /**
   * Set when a board message woke the wait while a main-thread turn ran or
   * the main conversation compacted: it stays held until the turn end (or
   * the compaction's release), and the wait re-arms without the board flag
   * meanwhile. Session-wide like the queue: a rebind keeps it.
   */
  let boardHeld = false
  /** Whether a main-conversation compaction runs, from compactStarted to compactEnded. */
  let compacting = false
  /** Bumped at every compaction start: a release a later compaction superseded does nothing. */
  let compactions = 0
  /**
   * The armed lever hold (see LEVER_HOLD_MS): set at a turn end whose turn
   * carried a compaction lever call, until that compaction starts, its cap
   * fires, the next main-thread turn end, or a stop. Aborting it ends its
   * cap wait.
   */
  let leverHold: AbortController | undefined
  /** Board drains run one at a time, so a turn end and an idle wake never interleave their submits. */
  let boardChain: Promise<unknown> = Promise.resolve()
  /**
   * Steered board messages claimed at a tool boundary whose row the host
   * refused: the next board flush submits them ahead of what it drains.
   * Session-wide like the queue: a rebind keeps them, a stop records them.
   */
  let steerCarry: string[] = []
  /** Steered texts whose row was appended since the last main-thread model request started: none has read it yet. */
  let steerUnread: string[] = []
  /**
   * Steered texts whose row the turn ended without reading: the next board
   * flush submits them again, ahead of the carried ones, never as a row.
   */
  let steerStranded: string[] = []
  /** Whether a steered drain that outlasted its boundary's wait is still out. */
  let steerDraining = false
  /**
   * Claimed board items behind a slash command entry, in drain order: what a
   * flush could not submit yet because a command goes first. Session-wide
   * like the queue: a rebind keeps them, a stop records them.
   */
  let backlog: InboxItem[] = []
  /** Whether a claimed slash command's run is out: nothing claimed after it goes until it settles. */
  let commandRunning = false
  /**
   * Set just before a dashboard interrupt asks for the running turn's abort,
   * cleared when the next main-thread turn starts: while set, what that turn
   * leaves behind is appended rather than submitted.
   */
  let interrupted = false
  /** The wait now running: its own abort, which re-arms it without ending the loop, and its board flags. */
  let waiting: { ctrl: AbortController; flags: WaitFlags } | undefined

  /** Whether board submission is on now. */
  function boardEnabled(): boolean {
    if (!edges.board) return false
    try {
      return edges.board.enabled()
    } catch (err) {
      edges.log(`${edges.label}: reading the board switch failed: ${String(err)}`)
      return false
    }
  }

  /**
   * Whether board messages are held rather than submitted now: a main-thread
   * turn runs, the main conversation compacts, or a requested compaction is
   * still to start (the lever hold).
   */
  function boardBusy(): boolean {
    return compacting || leverHold !== undefined || edges.turnRunning()
  }

  /** What holds board messages now, for a log line. */
  function holder(): string {
    if (compacting) return 'running compaction ends'
    if (leverHold !== undefined && !edges.turnRunning()) return 'requested compaction starts'
    return 'running turn ends'
  }

  /** Lift the armed lever hold, ending its cap wait; nothing is released here. */
  function liftLeverHold(): void {
    leverHold?.abort()
    leverHold = undefined
  }

  /** Whether the ending turn carried a compaction lever call still owed; a failing edge reads as none. */
  function leverOwed(): boolean {
    try {
      return edges.leverPending?.() === true
    } catch (err) {
      edges.log(`${edges.label}: reading the pending compaction request failed: ${String(err)}`)
      return false
    }
  }

  /**
   * Hold the board messages for the compaction the ending turn requested:
   * until it starts (compactStarted hands them to its release), or
   * LEVER_HOLD_MS. The cap wait is raced outside the board chain, never
   * awaited in it. At the cap, a compaction or a turn running by then takes
   * them at its end; otherwise they are released as a turn end would.
   */
  function armLeverHold(): void {
    liftLeverHold()
    const mine = new AbortController()
    leverHold = mine
    const stopsAt = stops
    edges.log(`${edges.label}: the turn requested a compaction; dashboard messages are held until it starts, ${LEVER_HOLD_MS}ms at most`)
    void Promise.resolve()
      .then(() => edges.sleep(LEVER_HOLD_MS, mine.signal))
      .catch((err) => edges.log(`${edges.label}: waiting on the requested compaction failed: ${String(err)}`))
      .then(() => {
        // Lifted meanwhile: a compaction start, a turn end, or a stop took over.
        if (leverHold !== mine) return
        leverHold = undefined
        if (compacting || stops !== stopsAt) return
        const myKey = key
        if (myKey === undefined || !edges.board || !(boardHeld || boardLeft())) return
        if (edges.turnRunning()) {
          edges.log(`${edges.label}: no compaction started within ${LEVER_HOLD_MS}ms and a main-thread turn runs; its turn end takes the held dashboard messages`)
          return
        }
        edges.log(`${edges.label}: no compaction started within ${LEVER_HOLD_MS}ms; releasing the held dashboard messages`)
        void releaseBoard(myKey, boardHeld, interrupted, 'lever-hold')
      })
  }

  /** Whether the next wait carries the board flag: board submission on and nothing held for a turn end. */
  function boardWanted(): boolean {
    return !boardHeld && boardEnabled()
  }

  /**
   * The next wait's flags: the board flag as boardWanted says, and the
   * interrupt flag whenever board submission is on, held message or not.
   */
  function waitFlags(): WaitFlags {
    const enabled = boardEnabled()
    return { board: enabled && !boardHeld, interrupt: enabled }
  }

  /** Re-arm the running wait when its flags no longer match. */
  function rearmStaleWait(): void {
    if (!waiting) return
    const want = waitFlags()
    if (waiting.flags.board !== want.board || waiting.flags.interrupt !== want.interrupt) waiting.ctrl.abort()
  }

  /** Write board messages that will not be submitted where the user can see them, and to the debug log. */
  function keepBoard(why: string, texts: readonly string[]): void {
    const text = `${edges.label}: a message from the dashboard was not submitted (${why}); recorded here instead:\n\n${texts.join('\n\n')}`
    try {
      edges.record(text)
    } catch (err) {
      edges.log(`${edges.label}: recording a dashboard message failed: ${String(err)}`)
    }
    edges.log(text)
  }

  /**
   * After a dashboard interrupt, the cut turn's steered texts start no turn:
   * a stranded row stays where it is, carried texts become one row, and the
   * next prompt carries both. A stop since `at`, or a refused row, records
   * the carried texts instead.
   */
  async function holdSteered(at: number, stranded: readonly string[], carried: readonly string[]): Promise<void> {
    if (stranded.length > 0) {
      edges.log(`${edges.label}: the turn was interrupted; ${stranded.length} unread steered message(s) stay in their row, which the next prompt carries`)
    }
    if (carried.length === 0 || !edges.board) return
    if (stops !== at) {
      keepBoard(`the push loop stopped: ${lastStop}`, carried)
      return
    }
    edges.log(`${edges.label}: the turn was interrupted; appending ${carried.length} carried steered message(s) as a row instead of submitting them`)
    try {
      await edges.board.append(carried)
    } catch (err) {
      keepBoard(`the turn was interrupted; row append failed: ${String(err)}`, carried)
    }
  }

  /** Whether anything waits for the next board flush: carried or stranded steered texts, or a backlog. */
  function boardLeft(): boolean {
    return steerCarry.length > 0 || steerStranded.length > 0 || backlog.length > 0
  }

  /** Take the backlog's leading text messages, up to its first command entry. */
  function takeBacklogTexts(): string[] {
    const end = backlog.findIndex((item) => typeof item !== 'string')
    return backlog.splice(0, end === -1 ? backlog.length : end) as string[]
  }

  /** A claimed item as text the user can read: a message's text, a command's typed line. */
  const itemText = (item: InboxItem) => (typeof item === 'string' ? item : item.text)

  /**
   * Run the slash command entry at the backlog's head, unless one runs:
   * the run is not awaited (the host queues it until the session is idle,
   * past a turn the flush just started), and once it settles the backlog
   * goes on (afterCommand). A rejected run is logged; its outcome reached the
   * dashboard through the edge.
   */
  function startCommand(board: BoardEdges, myKey: string): void {
    const head = backlog[0]
    if (commandRunning || head === undefined || typeof head === 'string') return
    backlog.shift()
    commandRunning = true
    edges.log(`${edges.label}: running the dashboard command ${head.text} for ${myKey}`)
    void Promise.resolve()
      .then(() => board.run(head))
      .then(
        () => edges.log(`${edges.label}: the dashboard command ${head.text} settled`),
        (err) => edges.log(`${edges.label}: the dashboard command ${head.text} failed: ${String(err)}`),
      )
      .then(() => {
        commandRunning = false
        afterCommand()
      })
  }

  /**
   * A dashboard command's run settled: what waited behind it goes on now,
   * or, while a main-thread turn runs or the main conversation compacts, is
   * held for that turn end or the compaction's release. A stop since already
   * recorded the backlog; a rebind's key takes what is left.
   */
  function afterCommand(): void {
    const myKey = key
    if (myKey === undefined || !edges.board || !boardLeft()) return
    if (boardBusy()) {
      boardHeld = true
      edges.log(`${edges.label}: dashboard messages behind a command are held until the ${holder()}`)
      rearmStaleWait()
      return
    }
    void flushBoard(myKey, false, interrupted)
  }

  /**
   * Drain `myKey`'s held board messages and submit them as one prompt, after
   * any drain already running; the carried steered messages go first. With
   * `drainHeld` false only the carried ones (and the backlog) are submitted.
   * With `hold` (a dashboard interrupt cut the turn) the carried and stranded
   * ones are held instead (holdSteered) and only what the drain claims is
   * submitted. What is claimed joins the backlog's end, and the text up to
   * its first command entry is submitted; that command then runs
   * (startCommand) and the rest waits for it. While a command runs nothing is
   * submitted: the claim only joins the backlog. Never rejects: answers
   * `empty` when nothing was held, carried, or backlogged, `failed` when the
   * drain failed (the held messages stay held; carried ones are still
   * submitted), and `done` once claimed messages were submitted, appended,
   * recorded, or backlogged.
   */
  function flushBoard(myKey: string, drainHeld = true, hold = false): Promise<'done' | 'empty' | { failed: string }> {
    const at = stops
    const run = boardChain.then(async (): Promise<'done' | 'empty' | { failed: string }> => {
      const board = edges.board
      if (!board) return 'empty'
      // A command still running holds everything behind it, the steered texts among them.
      const waiting = commandRunning
      let stranded = waiting ? [] : steerStranded
      let carried = waiting ? [] : steerCarry
      if (!waiting) {
        steerStranded = []
        steerCarry = []
      }
      if (hold && !waiting) {
        await holdSteered(at, stranded, carried)
        stranded = []
        carried = []
      }
      let drained: InboxItem[] = []
      let failed: string | undefined
      if (drainHeld) {
        try {
          drained = await board.drain(myKey)
        } catch (err) {
          failed = String(err)
        }
      }
      // The drain claimed these: from here this is their only holder. A stop
      // since means the conversation they were for is gone.
      if (stops !== at) {
        const lost = [...carried, ...drained.map(itemText)]
        if (stranded.length + lost.length === 0) return failed === undefined ? 'empty' : { failed }
        if (lost.length > 0) keepBoard(`the push loop stopped: ${lastStop}`, lost)
        return 'done'
      }
      const outcome = (claimed: boolean): 'done' | 'empty' | { failed: string } => (failed !== undefined ? { failed } : claimed ? 'done' : 'empty')
      backlog.push(...drained)
      if (waiting) {
        if (drained.length > 0) edges.log(`${edges.label}: drained ${drained.length} dashboard message(s) for ${myKey}; held behind the running dashboard command`)
        return outcome(drained.length > 0)
      }
      // `fresh` is in no conversation row yet; `stranded` already is.
      const fresh = [...carried, ...takeBacklogTexts()]
      const texts = [...stranded, ...fresh]
      if (texts.length === 0) {
        const command = backlog.length > 0
        startCommand(board, myKey)
        return outcome(command)
      }
      if (failed !== undefined) edges.log(`${edges.label}: dashboard message drain failed (${failed}); submitting the ${stranded.length + carried.length} carried steered message(s) alone`)
      await submitBoard(board, myKey, stranded, fresh)
      startCommand(board, myKey)
      return outcome(true)
    })
    boardChain = run.catch(() => {})
    return run.catch((err) => ({ failed: String(err) }))
  }

  /**
   * Submit board texts as one prompt, the stranded ones (already in an unread
   * steer row) first, falling back to a row for the fresh ones; only when
   * that fails too are they recorded. Never rejects.
   */
  async function submitBoard(board: BoardEdges, myKey: string, stranded: readonly string[], fresh: readonly string[]): Promise<void> {
    const texts = [...stranded, ...fresh]
    edges.log(`${edges.label}: drained ${texts.length} dashboard message(s) for ${myKey}; submitting them as the user's`)
    let submitErr: unknown
    try {
      await board.submit(texts, stranded.length)
      return
    } catch (err) {
      submitErr = err
    }
    if (fresh.length === 0) {
      edges.log(`${edges.label}: dashboard message submit failed (${String(submitErr)}); the ${stranded.length} unread steered message(s) stay in their row, which the next prompt carries`)
      return
    }
    edges.log(`${edges.label}: dashboard message submit failed (${String(submitErr)}); appending it as a row instead`)
    try {
      await board.append(fresh)
    } catch (err) {
      keepBoard(`prompt submit failed: ${String(submitErr)}; row append failed: ${String(err)}`, fresh)
    }
  }

  /**
   * Flush the board as a turn end does (flushBoard), then clear the held
   * mark and re-arm the wait with the flag; a failed drain keeps the
   * messages held, so the flagged wait retries them. Never rejects.
   */
  function releaseBoard(myKey: string, drainHeld: boolean, hold: boolean, what: string): Promise<void> {
    return flushBoard(myKey, drainHeld, hold).then((res) => {
      if (typeof res === 'object') edges.log(`${edges.label}: ${what} dashboard drain failed (${res.failed}); the messages stay held`)
      // Cleared only now, so the wait does not wake on what this drain is about to claim.
      boardHeld = false
      rearmStaleWait()
    })
  }

  /**
   * Carry claimed steered texts no row holds to the next board flush (the
   * turn end), or submit them now when that turn end has passed; a stop since
   * `at` records them instead.
   */
  function carrySteer(myKey: string, at: number, texts: readonly string[]): void {
    if (stops !== at) {
      keepBoard(`the push loop stopped: ${lastStop}`, texts)
      return
    }
    steerCarry.push(...texts)
    // The turn ended while they were pending (an interrupt): its flush has
    // run, so submit the carried messages now, or after a dashboard
    // interrupt append them as a row. During a compaction its release
    // submits them instead.
    if (!boardBusy()) void flushBoard(myKey, false, interrupted)
  }

  /**
   * Claim the board messages promoted to steering and append them into the
   * running turn as one row. A refused row carries them to the next board
   * flush (the turn end), so a claimed message is never lost. The drain gets
   * STEER_DRAIN_WAIT_MS: a hung server must not hold every tool result, so
   * past it this boundary claims nothing and what the drain claims late is
   * carried. Never rejects.
   */
  async function steerBoard(): Promise<void> {
    const board = edges.board
    const myKey = key
    if (!board || myKey === undefined || !boardEnabled()) return
    if (steerDraining) {
      edges.log(`${edges.label}: an earlier steered dashboard message drain for ${myKey} is still out; this tool boundary claims nothing`)
      return
    }
    const at = stops
    steerDraining = true
    const drain = Promise.resolve()
      .then(() => board.drainSteer(myKey))
      .finally(() => (steerDraining = false))
    const timer = new AbortController()
    const first = await Promise.race([
      drain.then(
        (texts) => ({ texts }),
        (err: unknown) => ({ err }),
      ),
      edges.sleep(STEER_DRAIN_WAIT_MS, timer.signal).then(() => 'late' as const),
    ])
    timer.abort()
    if (first === 'late') {
      edges.log(`${edges.label}: steered dashboard message drain for ${myKey} outlasted ${STEER_DRAIN_WAIT_MS}ms; this tool boundary claims nothing`)
      void drain.then(
        (texts) => {
          if (texts.length === 0) return
          edges.log(`${edges.label}: a late steered dashboard message drain claimed ${texts.length} message(s); submitting them at the turn end`)
          carrySteer(myKey, at, texts)
        },
        (err) => edges.log(`${edges.label}: late steered dashboard message drain failed for ${myKey}: ${String(err)}; they stay held`),
      )
      return
    }
    if ('err' in first) {
      edges.log(`${edges.label}: steered dashboard message drain failed for ${myKey}: ${String(first.err)}; they stay held`)
      return
    }
    const texts = first.texts
    if (texts.length === 0) return
    // The drain claimed these: from here this is their only holder.
    if (stops !== at) {
      keepBoard(`the push loop stopped: ${lastStop}`, texts)
      return
    }
    edges.log(`${edges.label}: appending ${texts.length} steered dashboard message(s) to the running turn as one row`)
    try {
      await board.steer(texts)
    } catch (err) {
      if (stops !== at) {
        keepBoard(`the push loop stopped: ${lastStop}; steer row: ${String(err)}`, texts)
        return
      }
      edges.log(`${edges.label}: steered dashboard message row refused (${String(err)}); submitting it at the turn end instead`)
      carrySteer(myKey, at, texts)
      return
    }
    if (stops !== at) return
    if (edges.turnRunning()) {
      steerUnread.push(...texts)
      return
    }
    // The turn ended while the row was pending: no model request reads it now.
    if (interrupted) {
      // A dashboard interrupt cut it: the row rides the next prompt instead.
      edges.log(`${edges.label}: the turn was interrupted; ${texts.length} unread steered message(s) stay in their row, which the next prompt carries`)
      return
    }
    steerStranded.push(...texts)
    // During a compaction, or while a requested one is still to start, its release submits them instead.
    if (!compacting && leverHold === undefined) void flushBoard(myKey, false)
  }

  /**
   * Claim `myKey`'s interrupt entries and abort the running main-thread turn
   * when it started before the newest of them was made; drop them otherwise
   * (no main-thread turn runs, or it started at or after that time). The
   * interrupted mark goes up before the abort is asked for; a rejected abort
   * is only logged, and whatever the mark held stays held. Never rejects:
   * `failed` when the drain failed (the entries stay for the next wake).
   */
  async function interruptTurn(myKey: string): Promise<'done' | { failed: string }> {
    const board = edges.board
    if (!board) return 'done'
    let times: number[]
    try {
      times = await board.drainInterrupt(myKey)
    } catch (err) {
      return { failed: String(err) }
    }
    if (times.length === 0) {
      edges.log(`${edges.label}: dashboard interrupt wake for ${myKey} claimed nothing`)
      return 'done'
    }
    const turn = board.mainTurn()
    if (!turn) {
      edges.log(`${edges.label}: ${times.length} dashboard interrupt(s) for ${myKey} claimed while no main-thread turn runs; dropped`)
      return 'done'
    }
    const newest = Math.max(...times)
    if (turn.startedAt >= newest) {
      edges.log(`${edges.label}: ${times.length} dashboard interrupt(s) for ${myKey} made before the running turn started; dropped`)
      return 'done'
    }
    // First: the turn end can come before the abort settles.
    interrupted = true
    edges.log(`${edges.label}: a dashboard interrupt for ${myKey}; aborting the running turn`)
    void Promise.resolve()
      .then(() => turn.abort())
      .catch((err) => edges.log(`${edges.label}: aborting the running turn was refused (${String(err)}); it had likely ended`))
    return 'done'
  }

  /** Queue `prompt` for the running main-thread turn; false when none runs, and the caller submits it. */
  function steer(prompt: OwnPrompt, lost: (why: string) => void, noticeFor?: string): boolean {
    if (!edges.turnRunning()) return false
    queued.push({ prompt, lost, noticeFor })
    return true
  }

  /** Take everything queued, in order; undefined when nothing is. */
  function takeQueued(): { items: Queued[]; prompts: OwnPrompt[] } | undefined {
    if (queued.length === 0) return undefined
    const items = queued
    queued = []
    return { items, prompts: items.map((q) => q.prompt) }
  }

  /**
   * Submit `items`' prompts, falling back to appending them as a row when the
   * submit is rejected or dropped. A turn that started first takes them into
   * the queue for its next tool boundary or its end, and a turn that ended
   * again by then gets the submit tried anew, so they are never left behind.
   * Never rejects: answers why they did not reach the conversation (a stop
   * since this call, or neither submit nor row), or undefined when they did
   * or were queued.
   */
  async function deliver(items: readonly Queued[]): Promise<string | undefined> {
    const prompts = items.map((q) => q.prompt)
    const at = stops
    let submitErr: unknown
    for (;;) {
      let res: 'busy' | 'stale' | void
      try {
        res = await edges.submit(prompts, () => stops === at)
      } catch (err) {
        submitErr = err
        break
      }
      if (res === 'stale') return `the push loop stopped: ${lastStop}`
      if (res !== 'busy') return undefined
      if (edges.turnRunning()) {
        // Ahead of anything steered in during the settle: mail keeps its arrival order.
        queued.unshift(...items)
        edges.log(`${edges.label}: a turn started before ${items.length} prompt(s) were submitted; queued for it`)
        return undefined
      }
    }
    edges.log(`${edges.label}: prompt submit failed (${String(submitErr)}); appending it as a row instead`)
    try {
      await edges.append(prompts)
      return undefined
    } catch (err) {
      return `prompt submit failed: ${String(submitErr)}; row append failed: ${String(err)}`
    }
  }

  function lose(items: readonly Queued[], why: string): void {
    for (const q of items) {
      try {
        q.lost(why)
      } catch (err) {
        edges.log(`${edges.label}: recording a lost prompt failed: ${String(err)}`)
      }
    }
  }

  /** `resumed` resolves when the model's recv for `myKey` completes, when `signal` aborts, or on `resume`. */
  function suspend(myKey: string, signal: AbortSignal): { resumed: Promise<void>; resume: () => void } {
    let resume!: () => void
    const resumed = new Promise<void>((resolve) => {
      const done = () => {
        if (suspended?.resume === done) suspended = undefined
        signal.removeEventListener('abort', done)
        resolve()
      }
      resume = done
      suspended = { key: myKey, resume: done }
      signal.addEventListener('abort', done, { once: true })
    })
    return { resumed, resume }
  }

  /** `healthy` is called after a wait that timed out with nothing queued: one whole clean cycle, which ends a crash streak. */
  async function loop(myKey: string, mySlug: string | undefined, signal: AbortSignal, healthy: () => void): Promise<void> {
    let backoff = 0
    let emptyStreak = 0
    const stopsAtStart = stops
    const backOff = async (what: string, detail: string) => {
      // Once per failure streak: a persistent fault retries every 60s and would flood the transcript.
      if (backoff === 0) edges.notice(`${edges.label}: ${what}, retrying with backoff`)
      backoff = nextBackoff(backoff)
      edges.log(`${edges.label}: ${what} for ${myKey}: ${detail}; backing off ${backoff}ms`)
      await edges.sleep(backoff, signal)
    }
    /** Deliver one notice and wait for the model's recv; false when the notice could not be delivered. */
    const notify = async (): Promise<boolean> => {
      const { resumed, resume } = suspend(myKey, signal)
      let failure: string | undefined
      const fail = (why: string) => {
        failure ??= why
        resume() // this loop's own suspension, never a rebound loop's
      }
      const notice = noticePrompt(edges.label, edges.recvTool(), myKey)
      if (steer(notice, fail, myKey)) {
        edges.log(`${edges.label}: notice for ${myKey} queued for the running turn`)
      } else {
        const why = await deliver([{ prompt: notice, lost: fail, noticeFor: myKey }])
        if (why !== undefined) fail(why)
      }
      await resumed
      if (failure === undefined) return true
      if (signal.aborted) return false
      await backOff('notice submit failed', failure)
      return false
    }
    /** Write drained mail that will not be submitted where the user can see it, and to the debug log. */
    const keep = (why: string, batch: string) => {
      const text = `${edges.label}: drained mail was not submitted (${why}); recorded here instead:\n\n${batch}`
      // The record goes first, and a throwing one must not cost the log line: it then carries the only copy.
      let recordErr: unknown
      try {
        edges.record(text)
      } catch (err) {
        recordErr = err
      }
      edges.log(text)
      if (recordErr !== undefined) edges.log(`${edges.label}: recording drained mail failed: ${String(recordErr)}; the log line above holds it`)
    }

    let emptyBoardStreak = 0
    while (!signal.aborted) {
      let outcome: WaitOutcome
      const flags = waitFlags()
      const own = { ctrl: new AbortController(), flags }
      const relay = () => own.ctrl.abort()
      signal.addEventListener('abort', relay, { once: true })
      waiting = own
      try {
        outcome = await edges.wait(myKey, mySlug, flags, own.ctrl.signal, signal)
      } catch (err) {
        edges.log(`${edges.label}: wait failed to start: ${String(err)}`)
        outcome = 'error'
      } finally {
        signal.removeEventListener('abort', relay)
        if (waiting === own) waiting = undefined
      }
      if (signal.aborted) return
      if (outcome === 'stopped') {
        // Its own abort re-arms it with the flags as they now stand.
        if (own.ctrl.signal.aborted) continue
        return
      }
      if (outcome === 'timeout') {
        backoff = 0
        emptyBoardStreak = 0
        healthy()
        continue
      }
      if (outcome === 'error') {
        await backOff('wait error', 'mailbox wait exited abnormally')
        continue
      }
      if (typeof outcome === 'object') {
        // The interrupt first; whatever else woke the same wait after it.
        const res = await interruptTurn(myKey)
        if (signal.aborted) return
        const rest = outcome.also
        if (typeof res === 'object') {
          // The entry stays, and the peek would wake again at once.
          if (rest === undefined) {
            await backOff('dashboard interrupt drain error', res.failed)
            continue
          }
          edges.log(`${edges.label}: dashboard interrupt drain failed for ${myKey}: ${res.failed}; handling the rest of the wake`)
        } else if (rest === undefined) backoff = 0
        if (rest === undefined) continue
        outcome = rest
      }
      if (outcome === 'board' || outcome === 'both') {
        if (boardBusy()) {
          // Held for the turn end (or the compaction's release), where the page can still cancel or steer it.
          boardHeld = true
          edges.log(`${edges.label}: a dashboard message for ${myKey} is held until the ${holder()}`)
        } else {
          const flushed = await flushBoard(myKey)
          if (signal.aborted) return
          // Mail that woke the same wait is still handled below; the board
          // message alone backs off, since the peek would wake again at once.
          if (typeof flushed === 'object') {
            if (outcome === 'board') {
              await backOff('dashboard message drain error', flushed.failed)
              continue
            }
            edges.log(`${edges.label}: dashboard message drain failed for ${myKey}: ${flushed.failed}; handling the mail`)
          } else if (flushed === 'empty') {
            if (outcome === 'board') {
              // The peek saw a held message the drain did not get (cancelled,
              // merged, or taken by a turn end's drain): never re-arm at once.
              emptyBoardStreak += 1
              const delay = Math.min(EMPTY_DRAIN_BACKOFF_MS * emptyBoardStreak, BACKOFF_MAX_MS)
              edges.log(`${edges.label}: dashboard wake with empty drain for ${myKey} (x${emptyBoardStreak}); sleeping ${delay}ms`)
              await edges.sleep(delay, signal)
              continue
            }
          } else {
            emptyBoardStreak = 0
            if (outcome === 'board') backoff = 0
          }
        }
        if (outcome === 'board') continue
      }
      if (edges.mode === 'notice') {
        if (await notify()) backoff = 0
        continue
      }
      let drained: DrainResult
      try {
        drained = await edges.drain(myKey)
      } catch (err) {
        drained = { kind: 'failed', reason: String(err) }
      }
      if (signal.aborted && drained.kind !== 'mail') return
      if (drained.kind === 'failed') {
        await backOff('drain error', drained.reason)
        continue
      }
      if (drained.kind === 'refused') {
        edges.log(`${edges.label}: recv refused for ${myKey} (${drained.reason}); asking the model to receive`)
        if (await notify()) backoff = 0
        continue
      }
      backoff = 0
      const mail = drained.mail
      if (mail.length === 0) {
        if (signal.aborted) return
        // wait saw mail but recv drained nothing (raced, or recv cannot reach
        // a queue wait can see): never re-arm instantly, or the peek spins.
        emptyStreak += 1
        const delay = Math.min(EMPTY_DRAIN_BACKOFF_MS * emptyStreak, BACKOFF_MAX_MS)
        edges.log(`${edges.label}: wake with empty drain for ${myKey} (x${emptyStreak}); sleeping ${delay}ms`)
        await edges.sleep(delay, signal)
        continue
      }
      emptyStreak = 0
      // recv already removed this mail, so this loop is its only holder until
      // steer or deliver takes it over. An unexpected throw before that point
      // records it and rethrows into the supervisor: redelivering would likely
      // crash on the same batch again, and a restart alone would lose it.
      let handedOff = false
      let batch: OwnPrompt | undefined
      try {
        batch = batchPrompt(edges.label, edges.recvTool(), myKey, mail)
        const text = batch.text
        // A stop means the conversation this mail was for is gone; a rebind
        // within it still delivers, since recv already removed this mail.
        if (stops !== stopsAtStart) {
          handedOff = true
          keep(`the push loop stopped: ${lastStop}`, text)
          return
        }
        const lost = (why: string) => keep(why, text)
        if (steer(batch, lost)) {
          handedOff = true
          edges.log(`${edges.label}: drained ${mail.length} message(s) for ${myKey}; queued for the running turn`)
          continue
        }
        edges.log(`${edges.label}: drained ${mail.length} message(s) for ${myKey}; submitting one prompt`)
        const why = await deliver([{ prompt: batch, lost }])
        handedOff = true // deliver never rejects once it has submitted, appended, or queued
        if (why !== undefined) lost(why)
      } catch (err) {
        if (!handedOff) {
          try {
            // Plain rendering when formatting is what failed.
            keep(`the push loop crashed: ${String(err)}`, batch?.text ?? mail.map((m) => JSON.stringify(m)).join('\n'))
          } catch {
            // the crash itself is what the supervisor must hear of
          }
        }
        throw err
      }
    }
  }

  /**
   * Run the loop for one binding, and run it again after any crash: push must
   * never end silently while its binding stands. The `signal` is the binding's
   * own, aborted by a stop and by a rebind alike, so a crash in a loop that
   * either superseded is never restarted, and a second loop never runs beside
   * the current one. The wait between restarts backs off like any other
   * failure, and the user hears of one crash streak once.
   */
  async function supervise(myKey: string, mySlug: string | undefined, signal: AbortSignal): Promise<void> {
    let backoff = 0
    edges.notice(`${edges.label}: armed ${myKey}`)
    while (!signal.aborted) {
      try {
        await loop(myKey, mySlug, signal, () => (backoff = 0))
        return
      } catch (err) {
        if (signal.aborted) {
          edges.log(`${edges.label}: loop for ${myKey} crashed after it was superseded or stopped; not restarted: ${String(err)}`)
          return
        }
        edges.log(`${edges.label}: loop crashed for ${myKey}: ${String(err)}; restarting in ${nextBackoff(backoff)}ms`)
        // Once per crash streak: a persistent fault restarts every 60s and would flood the transcript.
        if (backoff === 0) {
          try {
            edges.notice(`${edges.label}: push loop crashed, restarting with backoff`)
          } catch {
            // a failing notice edge must not end the restart
          }
        }
        backoff = nextBackoff(backoff)
        await edges.sleep(backoff, signal)
      }
    }
  }

  return {
    bind(next, nextSlug) {
      if (next === key && nextSlug === slug && ctrl && !ctrl.signal.aborted) return 'unchanged'
      const had = key !== undefined
      ctrl?.abort()
      key = next
      slug = nextSlug
      const mine = new AbortController()
      ctrl = mine
      void supervise(next, nextSlug, mine.signal).catch((err) => edges.log(`${edges.label}: push supervisor failed: ${String(err)}`))
      return had ? 'rebound' : 'bound'
    },
    stop(reason) {
      const left = takeQueued()
      if (left) lose(left.items, `the push loop stopped: ${reason}`)
      if (steerCarry.length > 0) keepBoard(`the push loop stopped: ${reason}`, steerCarry.splice(0))
      // Claimed behind a dashboard command (its typed line among them): only this holds them.
      if (backlog.length > 0) keepBoard(`the push loop stopped: ${reason}`, backlog.splice(0).map(itemText))
      // Already rows of the conversation the stop ends: nothing to record.
      steerUnread = []
      steerStranded = []
      boardHeld = false
      interrupted = false
      liftLeverHold()
      if (!ctrl) return
      stops += 1
      lastStop = reason
      ctrl.abort()
      ctrl = undefined
      key = undefined
      slug = undefined
      edges.log(`${edges.label}: stopped (${reason})`)
    },
    current: () => key,
    isSuspended: () => suspended !== undefined && suspended.key === key,
    recvCompleted(doneKey) {
      // A notice still queued for that key would only ask for mail already received.
      queued = queued.filter((q) => q.noticeFor !== doneKey)
      if (suspended && suspended.key === doneKey && doneKey === key) suspended.resume()
    },
    async toolCompleted() {
      try {
        await steerBoard()
      } catch (err) {
        edges.log(`${edges.label}: steering dashboard messages failed: ${String(err)}`)
      }
      const taken = takeQueued()
      if (!taken) return
      edges.log(`${edges.label}: appending ${taken.items.length} queued prompt(s) to the running turn as one row`)
      try {
        await edges.append(taken.prompts)
      } catch (err) {
        lose(taken.items, `row append failed: ${String(err)}`)
      }
    },
    requestStarted() {
      steerUnread = []
    },
    turnCompleted() {
      const taken = takeQueued()
      const at = stops
      // A dashboard interrupt cut this turn: what it leaves behind starts no turn.
      const hold = interrupted
      // Steer rows no model request read since they were appended: the
      // person refused or interrupted the call they rode on.
      if (steerUnread.length > 0) {
        steerStranded.push(...steerUnread)
        steerUnread = []
      }
      const sendMail = () => {
        if (!taken) return
        // A stop while the mail waited on the board drain took its conversation.
        if (stops !== at) return lose(taken.items, `the push loop stopped: ${lastStop}`)
        if (hold) {
          edges.log(`${edges.label}: the turn was interrupted; appending ${taken.items.length} prompt(s) still queued at its end as one row instead of submitting them`)
          void (async () => {
            try {
              await edges.append(taken.prompts)
            } catch (err) {
              lose(taken.items, `the turn was interrupted; row append failed: ${String(err)}`)
            }
          })()
          return
        }
        edges.log(`${edges.label}: submitting ${taken.items.length} prompt(s) still queued at the turn end as one prompt`)
        void deliver(taken.items).then((why) => {
          if (why !== undefined) lose(taken.items, why)
        })
      }
      const myKey = key
      const drainHeld = boardHeld || boardWanted()
      // Every main-thread turn end lifts an earlier lever hold: this one holds anew or releases as usual.
      liftLeverHold()
      if (myKey === undefined || !edges.board || !(drainHeld || boardLeft())) {
        boardHeld = false
        sendMail()
        return
      }
      if (compacting) {
        // The compaction's release takes the board part; the mail does not wait for it.
        edges.log(`${edges.label}: the turn ended during a compaction; the dashboard messages stay held for its end`)
        sendMail()
        return
      }
      if (leverOwed()) {
        // The compaction the turn requested goes first; mail keeps its turn-end submit.
        boardHeld = drainHeld
        rearmStaleWait()
        armLeverHold()
        sendMail()
        return
      }
      // The held board message goes first; the mail waits for it a bounded time.
      const flushed = releaseBoard(myKey, drainHeld, hold, 'turn-end')
      if (!taken) return
      const timer = new AbortController()
      void Promise.race([flushed, edges.sleep(BOARD_FIRST_WAIT_MS, timer.signal)])
        .catch((err) => edges.log(`${edges.label}: waiting on the turn-end dashboard drain failed: ${String(err)}`))
        .then(() => {
          timer.abort()
          sendMail()
        })
    },
    turnStarted() {
      interrupted = false
    },
    compactStarted() {
      compacting = true
      compactions += 1
      // The requested compaction started: its release takes what the lever hold kept.
      liftLeverHold()
    },
    compactEnded() {
      if (!compacting) return
      compacting = false
      if (!edges.board || !(boardHeld || boardLeft())) return
      const at = compactions
      const stopsAt = stops
      edges.log(`${edges.label}: the compaction ended with dashboard messages held; releasing them once any compaction continuation went first`)
      const timer = new AbortController()
      void Promise.resolve()
        .then(() => Promise.race([Promise.resolve().then(() => edges.continuation?.()), edges.sleep(COMPACTION_CONTINUATION_WAIT_MS, timer.signal)]))
        .catch((err) => edges.log(`${edges.label}: waiting on the compaction continuation failed: ${String(err)}`))
        .then(() => {
          timer.abort()
          // A later compaction holds them for its own end; a stop already recorded or forgot them.
          if (at !== compactions || compacting || stops !== stopsAt) return
          const myKey = key
          if (myKey === undefined || !(boardHeld || boardLeft())) return
          if (edges.turnRunning()) {
            edges.log(`${edges.label}: a main-thread turn runs after the compaction; its turn end takes the held dashboard messages`)
            return
          }
          void releaseBoard(myKey, boardHeld, interrupted, 'compaction-end')
        })
    },
    boardChanged() {
      rearmStaleWait()
    },
  }
}
