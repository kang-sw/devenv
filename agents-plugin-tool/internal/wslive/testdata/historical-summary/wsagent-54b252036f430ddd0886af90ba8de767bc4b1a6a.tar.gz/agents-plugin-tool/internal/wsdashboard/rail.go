package wsdashboard

import (
	"bytes"
	"fmt"
	"net/http"
	"strconv"

	"github.com/kang-sw/devenv/internal/wslive"
)

// The session rail's daemon side: its region, its read, its shared stream
// render, and its refresh route. The view model and its rules are in
// pageview_rail.go.

// regionRail is the session rail's region. It is in every session page,
// live or board-first, but not in sessionRegions: its render is shared by
// every session page (railPageSource), not part of one session's.
const regionRail = "rail"

// railRoute is the rail's refresh route (POST): an immediate re-read of the
// worktree lists.
const railRoute = "/rail/refresh"

// railEventsRoute is the iframe shell's stream: the rail alone
// (handleRailEvents).
const railEventsRoute = "/rail/events"

// railView reads what the rail shows: railBaseView, ordered by the rail
// layout (orderRailView), with each workspace's memo count.
func (d *Daemon) railView(r pageReader) RailView {
	view := d.railBaseView(r)
	layout, gen := d.layout.current()
	orderRailView(&view, layout, railFactsOf(view))
	view.LayoutGen = gen
	for i := range view.Workspaces {
		// Optional memo state must never prevent the rail from rendering.
		doc, err := readMemoDoc(memoFile(d.dir, view.Workspaces[i].Path))
		if err == nil {
			view.Workspaces[i].MemoCount = len(doc.memos())
		}
	}
	return view
}

// railBaseView reads the rail before its layout orders it: every listed
// session of the index, its snapshot (stale or not), its repository, and
// its last message, with the stored workspaces and the worktree lists read
// so far. A session's repository and a stored one join the lister's wanted
// set, so a render is what tells the lister which repositories to read.
// The layout route validates its ops against it (railFactsOf).
func (d *Daemon) railBaseView(r pageReader) RailView {
	if d.index == nil {
		return RailView{}
	}
	now := r.clock()
	var inputs []railInput
	wanted := map[string][]Registration{}
	for _, s := range d.index.Sessions() {
		if s.Unlisted {
			continue
		}
		reg := s.Registration
		in := railInput{Session: s, Snapshot: r.readSnapshot(reg.ReplyID), Repo: railRepoRoot(reg), CanRevive: d.agents != nil}
		if in.Repo != "" {
			in.Linked = worktreeMain(reg.Project) != ""
		}
		in.Message = d.railMsgs.last(reg.ReplyID, railRev(s.Rev, d.live.ringGen(reg.ReplyID)), wslive.RingDir(SessionDir(d.dir, reg.ReplyID)))
		if in.Repo != "" {
			wanted[in.Repo] = append(wanted[in.Repo], reg)
		}
		inputs = append(inputs, in)
	}
	// A stored repository's worktrees are listed whether or not a session
	// runs in it.
	stored := d.workspaces.workspaces()
	for _, w := range stored {
		if _, ok := wanted[w.Path]; w.Repo && !ok {
			wanted[w.Path] = nil
		}
	}
	view := buildRailView(inputs, d.rail.lists(wanted), stored, now)
	view.CanAdd = d.workspaces != nil
	view.CanSpawn = d.agents != nil
	return view
}

// renderRailRegion renders the rail region in lang.
func renderRailRegion(view RailView, lang string) (renderedRegion, error) {
	a, err := loadDashboardAssets()
	if err != nil {
		return renderedRegion{}, err
	}
	var buf bytes.Buffer
	if err := a.templateFor(lang).ExecuteTemplate(&buf, "r-"+regionRail, view); err != nil {
		return renderedRegion{}, fmt.Errorf("dashboard region %s: %w", regionRail, err)
	}
	return newRegion(buf.String()), nil
}

// railPageSource is the rail's shared render in lang and theme: one for
// every session page's stream, keyed without a reply-id. Like the index it
// depends on every wake (a session's change, the worktree lister's, and a
// layout write's), and its refresh stamp covers what follows the clock and
// the layout's generation.
func (d *Daemon) railPageSource(lang, theme string) pageSource {
	pages := d.pagesIn(lang)
	return pageSource{
		key: pageKey{kind: regionRail, lang: lang, theme: theme},
		render: func(*liveRender) pageRender {
			d.stats.RailRenders.Add(1)
			region, err := renderRailRegion(d.railView(pages), lang)
			if err != nil {
				fmt.Fprintf(d.log, "dashboard: render rail: %v\n", err)
				return pageRender{ok: true}
			}
			return pageRender{regions: regionSet{regionRail: region}, ok: true}
		},
		// The index's stamp covers every listed session's revision (its
		// snapshot and ring among what raises it), liveness, adapter
		// presence, and window; the lister's changes come by wake. The
		// layout's generation joins it, so a layout change (another
		// process's write among them) is never skipped as unchanged.
		stamp: func(refreshInputs) (string, bool) {
			stamp, ok := pages.indexStamp()
			_, gen := d.layout.current()
			return stamp + "/" + strconv.FormatUint(gen, 10), ok
		},
	}
}

// handleRailRefresh serves POST /rail/refresh: an immediate re-read of the
// rail's worktree lists. It needs the daemon's own Origin, as the other
// browser writes do, and answers 204 once the read is asked for (it lands
// on the pages through their streams), 409 when no page shows the rail.
func (d *Daemon) handleRailRefresh(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if !sameOrigin(r) {
		http.Error(w, "cross-origin request refused", http.StatusForbidden)
		return
	}
	if !d.rail.refresh() {
		http.Error(w, "no open page shows the session rail", http.StatusConflict)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
