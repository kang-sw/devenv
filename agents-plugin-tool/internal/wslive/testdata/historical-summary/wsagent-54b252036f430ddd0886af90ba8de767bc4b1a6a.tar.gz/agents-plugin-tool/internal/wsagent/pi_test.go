package wsagent

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"slices"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/kang-sw/devenv/internal/wslive"
)

func piSpec(t *testing.T, raw string) StartSpec {
	t.Helper()
	spec := claudeSpec(t, raw)
	spec.Dir = "/sess"
	return spec
}

func TestPiArgsAllOffByDefault(t *testing.T) {
	args := piArgs(piSpec(t, `{"backend":"pi"}`), "")
	for _, banned := range []string{"--system-prompt", "--extension", "-e", "--tools", "--model", "--thinking"} {
		if slices.Contains(args, banned) {
			t.Fatalf("args must not carry %s: %v", banned, args)
		}
	}
	for _, want := range []string{"--no-extensions", "--no-skills", "--no-prompt-templates", "--no-context-files", "--no-approve", "--no-tools"} {
		if !slices.Contains(args, want) {
			t.Fatalf("args lack %s: %v", want, args)
		}
	}
	checks := map[string]string{
		"--mode":                 "rpc",
		"--session":              filepath.Join("/sess", "pi", "session.jsonl"),
		"--session-dir":          filepath.Join("/sess", "pi"),
		"--append-system-prompt": "",
	}
	for flag, want := range checks {
		if got, ok := flagValue(args, flag); !ok || got != want {
			t.Fatalf("%s = %q (present %v), want %q", flag, got, ok, want)
		}
	}
}

func TestPiArgsFromProfile(t *testing.T) {
	// An absolute plugin path is a drive path on Windows, where "/abs" is
	// rooted but relative to the current drive.
	abs := "/abs/other.ts"
	if runtime.GOOS == "windows" {
		abs = `C:\abs\other.ts`
	}
	absJSON, _ := json.Marshal(abs)
	spec := piSpec(t, `{"backend":"pi","tools":["read","bash"],"ws_tools":["tickets.query","project.tree"],
		"mcp_servers":{"docs-x":{"command":"docs-mcp"}},"plugins":["ext.ts",`+string(absJSON)+`],"skills":true}`)
	spec.Instructions = "/sess/instructions.md"
	spec.Model, spec.Effort = "openai-codex/gpt-6.1-sol", "low"
	spec.WSMCP = &MCPCommand{Command: "/bin/ws-mcp"}
	args := piArgs(spec, "/sess/pi/ws-agent-mcp.ts")

	var extensions []string
	for i, a := range args {
		if a == "--extension" {
			extensions = append(extensions, args[i+1])
		}
	}
	if want := []string{"builtin:mcp", "/sess/pi/ws-agent-mcp.ts", filepath.Join("/work", "ext.ts"), abs}; !slices.Equal(extensions, want) {
		t.Fatalf("extensions = %v, want %v", extensions, want)
	}
	if !slices.Contains(args, "--no-extensions") || slices.Contains(args, "--no-skills") || slices.Contains(args, "--no-tools") {
		t.Fatalf("explicit extensions load under --no-extensions; skills stay on: %v", args)
	}
	checks := map[string]string{
		"--tools":                "read,bash,mcp__ws__tickets_query,mcp__ws__project_tree,mcp__docs_x__*",
		"--append-system-prompt": "/sess/instructions.md",
		"--model":                "openai-codex/gpt-6.1-sol",
		"--thinking":             "low",
	}
	for flag, want := range checks {
		if got, ok := flagValue(args, flag); !ok || got != want {
			t.Fatalf("%s = %q (present %v), want %q", flag, got, ok, want)
		}
	}
}

func TestPiToolSurface(t *testing.T) {
	spec := piSpec(t, `{"backend":"pi","tools":["read"],"ws_tools":["tickets.query"],"mcp_servers":{"docs":{"command":"d"}}}`)
	if got := piToolSurface(spec); len(got.entries) != 2 || got.allows("mcp__ws__tickets_query") {
		t.Fatalf("ws tools join the surface only when ws-mcp is attached: %+v", got)
	}
	spec.WSMCP = &MCPCommand{Command: "/bin/ws-mcp"}
	s := piToolSurface(spec)
	for _, ok := range []string{"read", "mcp__ws__tickets_query", "mcp__docs__search"} {
		if !s.allows(ok) {
			t.Fatalf("%s should be allowed", ok)
		}
	}
	err := checkPiTools([]string{"read", "bash", "mcp__ws__git_commit", "mcp__docs__search"}, s)
	if err == nil || !strings.Contains(err.Error(), "launch refused") || !strings.Contains(err.Error(), "bash, mcp__ws__git_commit") || strings.Contains(err.Error(), "docs") {
		t.Fatalf("tools outside the profile should be refused by name, got %v", err)
	}
	if err := checkPiToolEntries(Profile{Tools: []string{"read", "bash(git status)"}}); err == nil || !strings.Contains(err.Error(), "permission rule") {
		t.Fatalf("a permission rule would widen to the whole tool on pi, got %v", err)
	}
}

func TestPiBridgeRegistersOnlyTheProfileServers(t *testing.T) {
	spec := piSpec(t, `{"backend":"pi","ws_tools":["tickets.query"],"mcp_servers":{"docs":{"command":"docs-mcp"},"lazy":{"command":"l","exposure":"deferred"}}}`)
	spec.Root = "/work"
	spec.WSMCP = &MCPCommand{Command: "/bin/ws-mcp", Args: []string{"serve", "--stdio"}, Env: map[string]string{EnvAllowedTools: "tickets.query"}}
	servers, err := piMCPServers(spec)
	if err != nil {
		t.Fatal(err)
	}
	dir := t.TempDir()
	path, err := writePiBridge(dir, servers)
	if err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(path)
	if err != nil || !isPrivate(info) || path != filepath.Join(dir, piBridgeFile) {
		t.Fatalf("the bridge carries the conversation key's environment, so it is private: %s %v %v", path, info, err)
	}
	src, _ := os.ReadFile(path)
	text := string(src)
	start := strings.Index(text, "= ") + 2
	end := strings.Index(text, ";\n")
	var got map[string]map[string]any
	if err := json.Unmarshal([]byte(text[start:end]), &got); err != nil {
		t.Fatalf("bridge servers: %v\n%s", err, text)
	}
	if len(got) != 3 || got["ws"]["command"] != "/bin/ws-mcp" || got["ws"]["cwd"] != "/work" || got["ws"]["exposure"] != "direct" {
		t.Fatalf("ws-mcp should register direct at the root: %v", got)
	}
	timeout, _ := got["ws"]["timeout"].(float64)
	if timeout != piMCPTimeout.Seconds() || timeout <= (PiWaitMax+PiForwardSlack).Seconds() {
		t.Fatalf("ws-mcp timeout must outlast a maximum forwarded wait: %v", got["ws"])
	}
	if env, _ := got["ws"]["env"].(map[string]any); env[EnvAllowedTools] != "tickets.query" {
		t.Fatalf("ws-mcp's allowlist travels in its env: %v", got["ws"])
	}
	if got["docs"]["exposure"] != "direct" || got["lazy"]["exposure"] != "deferred" {
		t.Fatalf("a server's own exposure is kept, else direct: %v", got)
	}
	if !strings.Contains(text, "export default function") || !strings.Contains(text, "registerMcpServer(name, config)") {
		t.Fatalf("bridge source:\n%s", text)
	}
}

func TestPiMCPServersUseWorkingDirectory(t *testing.T) {
	for _, cwd := range []string{"", "/work", "/other-worktree"} {
		t.Run(cwd, func(t *testing.T) {
			spec := piSpec(t, `{"backend":"pi"}`)
			spec.Root, spec.Cwd = "/work", cwd
			spec.WSMCP = &MCPCommand{Command: "/bin/ws-mcp"}
			servers, err := piMCPServers(spec)
			if err != nil {
				t.Fatal(err)
			}
			want := cwd
			if want == "" {
				want = spec.Root
			}
			if got := servers[ReservedMCPServer].(map[string]any)["cwd"]; got != want {
				t.Fatalf("ws-mcp cwd = %q, want %q", got, want)
			}
		})
	}
}

func TestPiEnv(t *testing.T) {
	got := piEnv([]string{"PATH=/bin", "WS_PI_ROLE=lead", "WS_MAILBOX=lead@m", "WS_MAILBOX_AUTO=1", "PI_SKIP_VERSION_CHECK=0", "HOME=/h"})
	slices.Sort(got)
	want := []string{"HOME=/h", "PATH=/bin", "PI_SKIP_VERSION_CHECK=1"}
	if !slices.Equal(got, want) {
		t.Fatalf("piEnv = %v, want %v", got, want)
	}
}

// recordedReplies keeps what a mapper answers and sends.
type recordedReplies struct {
	answers []string
	sent    []map[string]any
}

func (r *recordedReplies) answer(id string, _ controlAnswer) { r.answers = append(r.answers, id) }
func (r *recordedReplies) send(v any) {
	raw, _ := json.Marshal(v)
	var m map[string]any
	_ = json.Unmarshal(raw, &m)
	r.sent = append(r.sent, m)
}

// replayPi runs a recorded RPC fixture through the mapper into a wslive
// state, with the runner's turn boundaries around each turn. before sees
// each line first, so a test can stand in for Send and Interrupt.
func replayPi(t *testing.T, fixture string, spec StartSpec, before func(line string, m *piMapper)) (*wslive.State, []wslive.RingEntry, []Event, *recordedReplies) {
	t.Helper()
	f, err := os.Open("testdata/" + fixture)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	m := newPiMapper(spec)
	clock := int64(1_000_000)
	m.now = func() time.Time { clock += 100; return time.UnixMilli(clock) }
	st := wslive.NewState("test-key")
	var ring []wslive.RingEntry
	var all []Event
	replies := &recordedReplies{}
	apply := func(ev wslive.Event) {
		res, err := st.Apply(ev, clock)
		if err != nil {
			t.Fatalf("apply %s: %v", ev.Kind, err)
		}
		ring = append(ring, res.Ring...)
	}
	inTurn := false
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	for sc.Scan() {
		line := sc.Text()
		if before != nil {
			before(line, m)
		}
		if !inTurn && strings.Contains(line, `"command":"prompt"`) {
			apply(wslive.Event{Kind: wslive.KindTurnStart, Origin: wslive.OriginWhiteboard})
			inTurn = true
		}
		for _, ev := range m.mapLine([]byte(line), replies) {
			all = append(all, ev)
			switch {
			case ev.Live != nil:
				apply(*ev.Live)
			case ev.TurnEnd:
				apply(wslive.Event{Kind: wslive.KindTurnEnd})
				inTurn = false
			}
		}
	}
	return st, ring, all, replies
}

func piToolTurnSpec(t *testing.T) StartSpec {
	spec := piSpec(t, `{"backend":"pi","tools":["read"],"ws_tools":["runtime.read","project.tree"]}`)
	spec.WSMCP = &MCPCommand{Command: "/bin/ws-mcp"}
	return spec
}

func TestPiMapperToolTurn(t *testing.T) {
	_, ring, events, replies := replayPi(t, "pi-tool-turn.jsonl", piToolTurnSpec(t), nil)
	ends := 0
	for _, ev := range events {
		if ev.Fatal != nil {
			t.Fatalf("a permitted fixture should not refuse: %v", ev.Fatal)
		}
		if ev.TurnEnd {
			ends++
			if ev.TurnError != "" {
				t.Fatalf("a clean turn ends with no error: %q", ev.TurnError)
			}
		}
	}
	if ends != 1 {
		t.Fatalf("one prompt is one turn, got %d ends", ends)
	}
	var reply string
	for _, e := range ring {
		if e.Kind == wslive.RingReply {
			reply = e.Text
		}
	}
	batches := map[int64]bool{}
	for _, ev := range events {
		if ev.Live != nil && ev.Live.Kind == wslive.KindAgent {
			var b wireBatch
			if err := json.Unmarshal(ev.Live.Batches[0], &b); err != nil {
				t.Fatal(err)
			}
			batches[b.Seq] = true
		}
	}
	last := ring[len(ring)-1]
	if reply != "alpha" || last.Kind != wslive.RingTurn || last.Done != 2 || last.Failed != 1 {
		t.Fatalf("reply %q, last %+v: want the reply and three calls, one failing", reply, last)
	}
	if len(batches) != 3 {
		t.Fatalf("each assistant message's calls are one batch: %v", batches)
	}
	if len(replies.sent) < 2 {
		t.Fatalf("running and settled turns ask for session statistics: %v", replies.sent)
	}
	for _, sent := range replies.sent {
		if sent["type"] != "get_session_stats" {
			t.Fatalf("unexpected mapper request: %v", sent)
		}
	}
}

func TestPiMapperRefusesUnlistedTool(t *testing.T) {
	spec := piSpec(t, `{"backend":"pi","tools":["read"]}`)
	_, _, events, _ := replayPi(t, "pi-tool-turn.jsonl", spec, nil)
	if len(events) < 2 || !events[0].TurnStart || events[0].Live != nil || events[1].Fatal == nil || !strings.Contains(events[1].Fatal.Error(), "mcp__ws__project_tree, mcp__ws__runtime_read") {
		t.Fatalf("agent_start must be followed by the loadout refusal before any call, got %+v", events)
	}
}

// TestPiMapperAbortAndResume: an interrupted run ends with no error and its
// cut-off call failed; the resumed session answers the next prompt, and the
// statistics carry the session id, context, and cost.
func TestPiMapperAbortAndResume(t *testing.T) {
	spec := piSpec(t, `{"backend":"pi","tools":["bash"]}`)
	st, ring, events, _ := replayPi(t, "pi-abort-resume.jsonl", spec, func(line string, m *piMapper) {
		switch {
		case strings.Contains(line, `"id":"p1"`):
			m.aborted.Store(true) // Interrupt during the first prompt
		case strings.Contains(line, `"id":"p2"`):
			m.aborted.Store(false) // Send of the second prompt
		}
	})
	var ends []Event
	sessionID := ""
	for _, ev := range events {
		if ev.Fatal != nil {
			t.Fatalf("unexpected refusal: %v", ev.Fatal)
		}
		if ev.TurnEnd {
			ends = append(ends, ev)
		}
		if ev.SessionID != "" {
			sessionID = ev.SessionID
		}
	}
	if len(ends) != 2 || ends[0].TurnError != "" || ends[1].TurnError != "" {
		t.Fatalf("an interrupt is no error: %+v", ends)
	}
	var turns []wslive.RingEntry
	for _, e := range ring {
		if e.Kind == wslive.RingTurn {
			turns = append(turns, e)
		}
	}
	if len(turns) != 2 || turns[0].Failed != 1 || ring[len(ring)-2].Text != "alpha" {
		t.Fatalf("the aborted call fails and the resumed turn replies: turns %+v", turns)
	}
	if sessionID != "01a1b8ce-7aa7-7047-86e9-1abee8a00288" {
		t.Fatalf("session id from the statistics = %q", sessionID)
	}
	snap := st.Snapshot(2_000_000)
	if snap.Usage == nil || snap.Usage.Context == nil || snap.Usage.Context.Window != 500000 || snap.Usage.Cost == nil || !snap.Usage.Cost.Estimate {
		t.Fatalf("usage should carry the context window and an estimated cost: %+v", snap.Usage)
	}

	// The same run without an interrupt asked for: the abort is the error.
	_, _, events, _ = replayPi(t, "pi-abort-resume.jsonl", spec, nil)
	for _, ev := range events {
		if ev.TurnEnd {
			if ev.TurnError != "This operation was aborted" {
				t.Fatalf("an abort no one asked for should fail the turn, got %q", ev.TurnError)
			}
			break
		}
	}
}

func TestPiMapperPromptAnswersAndDialogs(t *testing.T) {
	m := newPiMapper(piSpec(t, `{"backend":"pi"}`))
	r := &recordedReplies{}
	cases := []struct {
		line    string
		end     bool
		turnErr string
	}{
		{`{"id":"ws-1","type":"response","command":"prompt","success":false,"error":"busy"}`, true, "prompt refused: busy"},
		{`{"id":"ws-2","type":"response","command":"prompt","success":true,"data":{"disposition":"handled"}}`, true, ""},
		{`{"id":"ws-3","type":"response","command":"prompt","success":true,"data":{"disposition":"started"}}`, false, ""},
		{`{"id":"ws-4","type":"response","command":"prompt","success":true,"data":{"disposition":"queued"}}`, false, ""},
	}
	for _, tc := range cases {
		evs := m.mapLine([]byte(tc.line), r)
		ended := len(evs) > 0 && evs[len(evs)-1].TurnEnd
		if ended != tc.end || (ended && evs[len(evs)-1].TurnError != tc.turnErr) {
			t.Fatalf("%s: events %+v, want end %v error %q", tc.line, evs, tc.end, tc.turnErr)
		}
	}
	if !slices.Equal(r.answers, []string{"ws-1", "ws-2", "ws-3", "ws-4"}) {
		t.Fatalf("every response answers its request: %v", r.answers)
	}

	m.mapLine([]byte(`{"type":"extension_ui_request","id":"u1","method":"confirm","title":"Allow?"}`), r)
	m.mapLine([]byte(`{"type":"extension_ui_request","id":"u2","method":"notify","message":"hi"}`), r)
	if len(r.sent) != 1 || r.sent[0]["type"] != "extension_ui_response" || r.sent[0]["id"] != "u1" || r.sent[0]["cancelled"] != true {
		t.Fatalf("a blocking dialog is cancelled, a notification ignored: %v", r.sent)
	}

	start := m.mapLine([]byte(`{"type":"compaction_start","reason":"threshold"}`), r)
	end := m.mapLine([]byte(`{"type":"compaction_end","reason":"manual"}`), r)
	if len(start) != 1 || start[0].Live.Kind != wslive.KindCompact || start[0].Live.Phase != wslive.CompactStart || start[0].Live.Trigger != wslive.TriggerAuto ||
		len(end) != 1 || end[0].Live.Phase != wslive.CompactEnd || end[0].Live.Trigger != wslive.TriggerManual {
		t.Fatalf("compaction maps to compact events: %+v %+v", start, end)
	}
}

func TestPiMapperCommandAnswerDoesNotSettleActiveRun(t *testing.T) {
	for _, tc := range []struct {
		name, line, commandErr string
	}{
		{"handled prompt", `{"id":"p1","type":"response","command":"prompt","success":true,"data":{"disposition":"handled"}}`, ""},
		{"refused prompt", `{"id":"p1","type":"response","command":"prompt","success":false,"error":"Agent is already processing"}`, "prompt refused: Agent is already processing"},
		{"completed compact", `{"id":"p1","type":"response","command":"compact","success":true}`, ""},
		{"refused compact", `{"id":"p1","type":"response","command":"compact","success":false,"error":"busy"}`, "compact refused: busy"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			spec := piSpec(t, `{"backend":"pi"}`)
			spec.Lead = &LeadSpec{}
			m, r := newPiMapper(spec), &recordedReplies{}
			m.mapLine([]byte(`{"type":"agent_start"}`), r)
			events := m.mapLine([]byte(tc.line), r)
			var commandErr string
			for _, ev := range events {
				if ev.TurnEnd || ev.TurnError != "" || ev.Notice != "" || ev.Alert != nil || ev.Live != nil {
					t.Fatalf("a command answer must not settle, fail, or add conversation output to the active run: %+v", events)
				}
				commandErr += ev.CommandError
			}
			wantEvents := 0
			if tc.commandErr != "" {
				wantEvents = 1
			}
			if len(events) != wantEvents || commandErr != tc.commandErr || !slices.Equal(r.answers, []string{"p1"}) {
				t.Fatalf("command response = %+v, answers %v; want command error %q", events, r.answers, tc.commandErr)
			}
			settled := m.mapLine([]byte(`{"type":"agent_settled"}`), r)
			if len(settled) == 0 || !settled[len(settled)-1].TurnEnd || settled[len(settled)-1].TurnError != "" {
				t.Fatalf("only native settlement ends the active run, without the command refusal: %+v", settled)
			}
			idle := m.mapLine([]byte(tc.line), r)
			if len(idle) == 0 || !idle[len(idle)-1].TurnEnd || idle[len(idle)-1].TurnError != tc.commandErr {
				t.Fatalf("the same command answer still settles an idle command: %+v", idle)
			}
		})
	}
}

func TestPiMapperReplayDistinguishesUnknownFromIdle(t *testing.T) {
	for _, tc := range []struct {
		name, boundary string
		lost, gap      bool
		wantEnd        bool
	}{
		{"complete command-only replay", "", false, false, true},
		{"wrapped replay", "", true, false, false},
		{"gap in replay", "", false, true, false},
		{"start after gap", `{"type":"agent_start"}`, true, true, false},
		{"settlement after gap", `{"type":"agent_settled"}`, true, true, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			spec := piSpec(t, `{"backend":"pi"}`)
			spec.Holder = &holderChild{id: "existing"}
			m, r := newPiMapper(spec), &recordedReplies{}
			p := newStreamProcess(m, piProtocol{})
			// Even before replay loss is reported, an attached mapper does
			// not know that a surviving command-only answer means idle.
			line := []byte(`{"type":"response","command":"prompt","success":true,"data":{"disposition":"handled"}}`)
			if events := m.mapLine(line, r); len(events) != 0 {
				t.Fatalf("unknown native state must not settle: %+v", events)
			}
			if tc.gap {
				m.nativeProbes = map[string]uint64{"stale": m.nativeGeneration}
				p.deliver(Event{ReplayGap: true})
				m.mapLine([]byte(`{"type":"response","id":"stale","command":"get_state","success":true,"data":{"isStreaming":false}}`), r)
			}
			if tc.boundary != "" {
				m.mapLine([]byte(tc.boundary), r)
			}
			p.deliver(Event{ReplayDone: true, ReplayLost: tc.lost})
			events := m.mapLine(line, r)
			ended := len(events) > 0 && events[len(events)-1].TurnEnd
			if ended != tc.wantEnd {
				t.Fatalf("events %+v; want command-only completion %v", events, tc.wantEnd)
			}
		})
	}
}

func TestPiMapperNativeProbeRespectsNewerBoundaries(t *testing.T) {
	for _, tc := range []struct {
		name, boundary, state string
		wantEnd               bool
	}{
		{"lost start", "", `{"isStreaming":true,"isCompacting":false}`, false},
		{"newer start", `{"type":"agent_start"}`, `{"isStreaming":false}`, false},
		{"newer settlement", `{"type":"agent_settled"}`, `{"isStreaming":true}`, true},
		{"compact only", "", `{"isStreaming":false,"isCompacting":true}`, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			m, r := newPiMapper(piSpec(t, `{"backend":"pi"}`)), &recordedReplies{}
			m.nativeProbes = map[string]uint64{"probe": 0}
			if tc.boundary != "" {
				m.mapLine([]byte(tc.boundary), r)
			}
			m.mapLine([]byte(`{"type":"response","id":"probe","command":"get_state","success":true,"data":`+tc.state+`}`), r)
			events := m.mapLine([]byte(`{"type":"response","command":"prompt","success":true,"data":{"disposition":"handled"}}`), r)
			ended := len(events) > 0 && events[len(events)-1].TurnEnd
			if ended != tc.wantEnd || len(m.nativeProbes) != 0 {
				t.Fatalf("events %+v, pending probes %v; want end %v", events, m.nativeProbes, tc.wantEnd)
			}
		})
	}
}

// TestPiMapperSteerAnswersAndTakenMessages: a non-lead process's steer
// response is the steer's answer, a refusal named (a child's report then
// goes as a turn), and a user message its run took is named with the text
// pi matches it by; a lead keeps a refusal notice and names no taken
// message.
func TestPiMapperSteerAnswersAndTakenMessages(t *testing.T) {
	m := newPiMapper(piSpec(t, `{"backend":"pi"}`))
	r := &recordedReplies{}
	for _, tc := range []struct{ line, refusal string }{
		{`{"type":"response","command":"steer","success":true,"data":{"disposition":"queued"}}`, ""},
		{`{"type":"response","command":"steer","success":false,"error":"no"}`, "no"},
		{`{"type":"response","command":"steer","success":false}`, "refused"},
	} {
		evs := m.mapLine([]byte(tc.line), r)
		if len(evs) != 1 || evs[0].SteerAnswer == nil || evs[0].SteerAnswer.Refusal != tc.refusal || evs[0].Notice != "" {
			t.Fatalf("%s: events %+v, want one answer refusing %q", tc.line, evs, tc.refusal)
		}
	}
	for _, tc := range []struct{ line, text string }{
		{`{"type":"message_end","message":{"role":"user","content":"[Pi subagent x] turn done\nresult"}}`, "[Pi subagent x] turn done\nresult"},
		{`{"type":"message_end","message":{"role":"user","content":[{"type":"text","text":"part one, "},{"type":"image","data":"…"},{"type":"text","text":"part two"}]}}`, "part one, part two"},
	} {
		evs := m.mapLine([]byte(tc.line), r)
		if len(evs) != 1 || evs[0].UserTaken != tc.text {
			t.Fatalf("%s: events %+v, want the taken text %q", tc.line, evs, tc.text)
		}
	}
	if evs := m.mapLine([]byte(`{"type":"message_end","message":{"role":"user","content":[]}}`), r); len(evs) != 0 {
		t.Fatalf("an empty user message names nothing: %+v", evs)
	}

	lead := newPiMapper(StartSpec{Root: "/work", Dir: "/sess", Profile: Profile{Backend: BackendPi, Lead: true}, Lead: &LeadSpec{}})
	if evs := lead.mapLine([]byte(`{"type":"response","command":"steer","success":false,"error":"no"}`), r); len(evs) != 1 || evs[0].SteerAnswer != nil || evs[0].Notice != "pi refused a steered message: no" {
		t.Fatalf("a lead's refused steer is a notice: %+v", evs)
	}
	if evs := lead.mapLine([]byte(`{"type":"response","command":"steer","success":true}`), r); len(evs) != 0 {
		t.Fatalf("a lead's taken steer maps to nothing: %+v", evs)
	}
	for _, ev := range lead.mapLine([]byte(`{"type":"message_end","message":{"role":"user","content":"hi"}}`), r) {
		if ev.UserTaken != "" {
			t.Fatalf("a lead names no taken message: %+v", ev)
		}
	}
}

// piWidgetLine is the RPC line a hosted Pi lead's setWidget call writes.
func piWidgetLine(key string, lines ...string) []byte {
	raw, _ := json.Marshal(map[string]any{"type": "extension_ui_request", "id": "w", "method": "setWidget", "widgetKey": key, "widgetLines": lines})
	return raw
}

// TestPiMapperAgentsWidget: the hosted lead's subagent widget maps each
// line to the agent or permission event it carries, with the fields a CLI
// session's dashboard feed sends; a line with no agent id, of another kind,
// or that does not decode is skipped, as are other widgets, other UI
// requests, and widget lines of another shape.
func TestPiMapperAgentsWidget(t *testing.T) {
	m := newPiMapper(StartSpec{Root: "/work", Dir: "/sess", Profile: Profile{Backend: BackendPi, Lead: true}, Lead: &LeadSpec{}})
	r := &recordedReplies{}
	st := wslive.NewState("widget-test-key")
	apply := func(evs []Event) {
		t.Helper()
		for _, ev := range evs {
			if ev.Live == nil {
				t.Fatalf("a widget maps to live events only: %+v", ev)
			}
			if _, err := st.Apply(*ev.Live, 1_000); err != nil {
				t.Fatalf("apply %+v: %v", *ev.Live, err)
			}
		}
	}
	running := `{"kind":"agent","agentId":"child-1","label":"audit","sessionKey":"sk-child","status":"running","caption":"worker","batches":[{"epoch":"e","seq":1,"toolNames":["read"],"callCount":1,"failed":0,"startedAt":900,"running":{"toolName":"read","startedAt":900}}],"model":"gpt-x","effort":"high","contextTokens":1200,"outputTps":40}`
	nested := `{"kind":"agent","agentId":"grandchild","parentId":"child-1","label":"probe","status":"running","caption":"explore"}`
	evs := m.mapLine(piWidgetLine(piAgentsWidgetKey,
		running,
		nested,
		`{"kind":"agent","status":"running","batches":[]}`,
		`{"kind":"reset"}`,
		`{"kind":"turn_start","agentId":"child-1"}`,
		`{"kind":"reply","agentId":"child-1","text":"x"}`,
		`not json`,
		`{"kind":"permission","agentId":"child-1","tool":"ws-worker-exec","args":{"command":"go test"}}`,
	), r)
	if len(evs) != 3 {
		t.Fatalf("widget events = %+v, want two agents and a permission", evs)
	}
	apply(evs)
	agents := map[string]wslive.Agent{}
	for _, a := range st.Snapshot(2_000).Agents {
		agents[a.ID] = a
	}
	a := agents["child-1"]
	if len(agents) != 2 || a.Status != wslive.StatusRunning || a.Label != "audit" || a.Model != "gpt-x" || a.Effort != "high" || a.ContextTokens != 1200 || a.OutputTps != 40 ||
		a.ReplyID == "" || a.Caption != "worker" || len(a.Batches) != 1 || a.Permission == nil || a.Permission.ToolName != "ws-worker-exec" {
		t.Fatalf("child row = %+v", a)
	}
	if g := agents["grandchild"]; g.ParentID != "child-1" || g.Label != "probe" || g.Status != wslive.StatusRunning {
		t.Fatalf("nested row = %+v", g)
	}

	apply(m.mapLine(piWidgetLine(piAgentsWidgetKey,
		`{"kind":"permission","agentId":"child-1","clear":true}`,
		`{"kind":"agent","agentId":"grandchild","status":"done"}`,
	), r))
	for _, a := range st.Snapshot(3_000).Agents {
		if a.ID == "child-1" && (a.Permission != nil || a.Status != wslive.StatusRunning) {
			t.Fatalf("a cleared permission leaves the row running: %+v", a)
		}
		if a.ID == "grandchild" && a.Status != wslive.StatusDone {
			t.Fatalf("a done event ends the row: %+v", a)
		}
	}

	for _, line := range [][]byte{
		piWidgetLine("ws-agents", running),
		piWidgetLine("", running),
		[]byte(`{"type":"extension_ui_request","id":"w","method":"setStatus","statusKey":"ws-dashboard-agents","statusText":"x"}`),
		[]byte(`{"type":"extension_ui_request","id":"w","method":"setWidget","widgetKey":"ws-dashboard-agents"}`),
		[]byte(`{"type":"extension_ui_request","id":"w","method":"setWidget","widgetKey":"ws-dashboard-agents","widgetLines":"` + "x" + `"}`),
		[]byte(`{"type":"extension_ui_request","id":"w","method":"setWidget","widgetKey":"ws-dashboard-agents","widgetLines":[{"kind":"agent","agentId":"c"}]}`),
	} {
		if evs := m.mapLine(line, r); len(evs) != 0 {
			t.Fatalf("%s mapped to %+v", line, evs)
		}
	}
	if len(r.sent) != 0 {
		t.Fatalf("a widget is answered by nothing: %v", r.sent)
	}
}

// piResponder is a stand-in pi that answers every command with an id and
// logs each line it reads.
const piResponder = `import sys, json
log = open(sys.argv[1], "a", newline="")
for line in sys.stdin:
    log.write(line); log.flush()
    d = json.loads(line)
    if "id" in d:
        ok = d.get("type") != "set_thinking_level" or d.get("level") != "bogus"
        print(json.dumps({"type": "response", "id": d["id"], "command": d["type"], "success": ok, "error": "" if ok else "bad level"}), flush=True)
`

func TestPiProcessCommands(t *testing.T) {
	python := lookPython(t)
	logPath := filepath.Join(t.TempDir(), "commands.jsonl")
	m := newPiMapper(piSpec(t, `{"backend":"pi"}`))
	sp, err := startStreamProcess(exec.Command(python, "-I", "-c", piResponder, logPath), m, piProtocol{})
	if err != nil {
		t.Fatal(err)
	}
	p := &piProcess{streamProcess: sp, mapper: m}
	var drained sync.WaitGroup
	drained.Add(1)
	go func() {
		defer drained.Done()
		for range p.Events() {
		}
	}()

	for _, model := range []string{"", "gpt", "openai/gpt:high", "/x"} {
		if err := p.SetModel(model); !errors.Is(err, ErrUnsupported) {
			t.Fatalf("SetModel(%q) needs a restart, got %v", model, err)
		}
	}
	if err := p.SetEffort(""); !errors.Is(err, ErrUnsupported) {
		t.Fatalf("a return to the default effort needs a restart, got %v", err)
	}
	if err := p.SetModel("openai-codex/gpt-a"); err != nil {
		t.Fatal(err)
	}
	if err := p.SetEffort("high"); err != nil {
		t.Fatal(err)
	}
	if err := p.SetEffort("bogus"); err == nil || !strings.Contains(err.Error(), "bad level") {
		t.Fatalf("a refused level is the error, got %v", err)
	}
	if err := p.SetModel("openai-codex/gpt-b"); err != nil {
		t.Fatal(err)
	}
	if err := p.Send("hello"); err != nil || m.aborted.Load() {
		t.Fatal(err)
	}
	if err := p.Interrupt(); err != nil || !m.aborted.Load() {
		t.Fatalf("Interrupt: %v", err)
	}
	if err := p.Send("again"); err != nil || m.aborted.Load() {
		t.Fatalf("a send clears the interrupt: %v", err)
	}
	if err := p.Steer("a report"); err != nil {
		t.Fatalf("Steer: %v", err)
	}
	if err := p.ClearSteered(); err != nil {
		t.Fatalf("ClearSteered: %v", err)
	}
	p.Close()
	drained.Wait()

	raw, _ := os.ReadFile(logPath)
	var got []string
	for _, line := range strings.Split(strings.TrimSpace(string(raw)), "\n") {
		var d map[string]any
		if err := json.Unmarshal([]byte(line), &d); err != nil {
			t.Fatalf("%s: %v", line, err)
		}
		s := d["type"].(string)
		for _, k := range []string{"modelId", "level", "message"} {
			if v, ok := d[k].(string); ok {
				s += " " + v
			}
		}
		got = append(got, s)
	}
	want := []string{
		"set_model gpt-a",
		"set_thinking_level high", "set_thinking_level bogus",
		// set_model resets pi's thinking level, so the set effort follows it.
		"set_model gpt-b", "set_thinking_level high",
		"prompt hello", "abort", "prompt again",
		"steer a report", "clear_queue",
	}
	if !slices.Equal(got, want) {
		t.Fatalf("commands = %q, want %q", got, want)
	}
}

// TestPiBackendStart drives Start against a stand-in pi that records its
// command line, working directory, and environment.
func TestPiBackendStart(t *testing.T) {
	fake, out, outEnv := standin(t)
	// Close SIGTERMs a child that outlives closeGrace, so under load it could
	// kill the stand-in before it wrote its records. Close only once the
	// stand-in reports it finished writing.
	ready := filepath.Join(out, "ready")
	closeWhenWritten := func(proc Process) {
		t.Helper()
		deadline := time.Now().Add(30 * time.Second)
		for {
			if _, err := os.Stat(ready); err == nil {
				break
			}
			if time.Now().After(deadline) {
				t.Fatal("the stand-in pi never finished writing its records")
			}
			time.Sleep(5 * time.Millisecond)
		}
		_ = os.Remove(ready)
		proc.Close()
	}
	root, dir := t.TempDir(), t.TempDir()
	spec := piSpec(t, `{"backend":"pi","tools":["read"],"ws_tools":["tickets.query"]}`)
	spec.Root, spec.Dir = root, dir
	spec.WSMCP = &MCPCommand{Command: "/bin/ws-mcp"}
	spec.Env = []string{"PATH=" + os.Getenv("PATH"), "WS_PI_ROLE=lead", outEnv}
	proc, err := PiBackend{Command: fake}.Start(context.Background(), spec)
	if err != nil {
		t.Fatal(err)
	}
	closeWhenWritten(proc)

	read := func(name string) string {
		raw, err := os.ReadFile(filepath.Join(out, name))
		if err != nil {
			t.Fatal(err)
		}
		return string(raw)
	}
	args := strings.Split(read("args"), "\x00")
	bridge := filepath.Join(dir, "pi", piBridgeFile)
	if got, _ := flagValue(args, "--tools"); got != "read,mcp__ws__tickets_query" || !slices.Contains(args, bridge) {
		t.Fatalf("args = %v", args)
	}
	if info, err := os.Stat(bridge); err != nil || !isPrivate(info) {
		t.Fatalf("bridge: %v %v", info, err)
	}
	if cwd := read("cwd"); !sameDir(cwd, root) {
		t.Fatalf("pi runs at the working root: %q, want %q", cwd, root)
	}
	if env := read("env"); !strings.Contains(env, "PI_SKIP_VERSION_CHECK=1") || strings.Contains(env, "WS_PI_ROLE") {
		t.Fatalf("child env:\n%s", env)
	}

	// No MCP server allowed: no bridge, no MCP extension.
	plain := piSpec(t, `{"backend":"pi","tools":["read"]}`)
	plain.Root, plain.Dir, plain.Env = root, t.TempDir(), spec.Env
	proc, err = PiBackend{Command: fake}.Start(context.Background(), plain)
	if err != nil {
		t.Fatal(err)
	}
	closeWhenWritten(proc)
	if args := read("args"); strings.Contains(args, "builtin:mcp") {
		t.Fatalf("no MCP server, no MCP extension: %s", args)
	}
	if _, err := os.Stat(filepath.Join(plain.Dir, "pi", piBridgeFile)); !os.IsNotExist(err) {
		t.Fatalf("no bridge is written without a server: %v", err)
	}

	rule := piSpec(t, `{"backend":"pi","tools":["bash(git status)"]}`)
	rule.Root, rule.Dir = root, t.TempDir()
	if _, err := (PiBackend{Command: fake}).Start(context.Background(), rule); err == nil || !strings.Contains(err.Error(), "permission rule") {
		t.Fatalf("a permission rule is refused before launch, got %v", err)
	}
	if _, err := os.Stat(filepath.Join(rule.Dir, "pi")); !os.IsNotExist(err) {
		t.Fatalf("a refused launch leaves no session state: %v", err)
	}

	restore := lookPath
	lookPath = func(string) (string, error) { return "", exec.ErrNotFound }
	t.Cleanup(func() { lookPath = restore })
	if _, err := (PiBackend{}).Start(context.Background(), plain); err == nil || !strings.Contains(err.Error(), "pi backend") {
		t.Fatalf("a missing pi names the backend, got %v", err)
	}
}

// TestPiMCPOnly pins which Pi conversations run without the native ws Pi
// extension: a spawned conversation unless its launched profile loads the
// extension package (by directory or entry file), and a hosted lead only
// after its bridge fallback recorded a plugin warning.
func TestPiMCPOnly(t *testing.T) {
	root := t.TempDir()
	ext := filepath.Join(root, "ext")
	if err := os.MkdirAll(filepath.Join(ext, "src"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(ext, "package.json"), []byte(`{"name":"`+piExtensionPackage+`"}`), 0o644); err != nil {
		t.Fatal(err)
	}
	other := filepath.Join(root, "other")
	if err := os.MkdirAll(other, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(other, "package.json"), []byte(`{"name":"another-extension"}`), 0o644); err != nil {
		t.Fatal(err)
	}
	spawned := Record{Backend: BackendPi, Root: root}
	cases := []struct {
		name string
		rec  Record
		def  *Profile
		want bool
	}{
		{"spawned without a profile", spawned, nil, true},
		{"spawned with no plugins", spawned, &Profile{Backend: BackendPi}, true},
		{"spawned with another extension", spawned, &Profile{Backend: BackendPi, Plugins: []string{"other/index.ts"}}, true},
		{"spawned with the extension entry", spawned, &Profile{Backend: BackendPi, Plugins: []string{"ext/src/index.ts"}}, false},
		{"spawned with the extension directory", spawned, &Profile{Backend: BackendPi, Plugins: []string{ext}}, false},
		{"hosted lead on the bundled extension", Record{Backend: BackendPi, Lead: true}, nil, false},
		{"hosted lead on the bridge fallback", Record{Backend: BackendPi, Lead: true, PluginWarning: "Bundled Pi extension unavailable"}, nil, true},
		{"claude conversation", Record{Backend: BackendClaude, Root: root}, nil, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := PiMCPOnly(tc.rec, tc.def); got != tc.want {
				t.Fatalf("PiMCPOnly = %v, want %v", got, tc.want)
			}
		})
	}
}
