package wsagent

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/kang-sw/devenv/internal/wsdashboard"
	"github.com/kang-sw/devenv/internal/wsinbox"
	"github.com/kang-sw/devenv/internal/wslive"
)

const chatProfile = `{"backend":"claude","model":"haiku","tools":["Read"],"instructions":"agent.md"}`

func requestStatus(err error) int {
	var re *requestError
	if errors.As(err, &re) {
		return re.status
	}
	return 0
}

func TestCreateWritesRecordRegistrationAndSnapshot(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	st := h.create("chat")
	if st.Status != StatusIdle || st.Process || st.Model != "haiku" || st.Page != "/s/"+st.ID {
		t.Fatalf("a new conversation is idle with no process: %+v", st)
	}
	dir := wsdashboard.SessionDir(h.dir, st.ID)
	info, err := os.Stat(recordPath(dir))
	if err != nil || !isPrivate(info) {
		t.Fatalf("the record should be private: %v %v", info, err)
	}
	rec, err := readRecord(dir)
	if err != nil || rec.WSKey == "" || rec.Profile != "chat" || rec.Backend != suiteBackend || rec.Root != h.root {
		t.Fatalf("record = %+v, %v", rec, err)
	}
	reg, err := wsdashboard.ReadRegistration(h.dir, st.ID)
	if err != nil || !reg.Agent || !reg.Unlisted || reg.Project != h.root || !reg.Live(time.Now()) {
		t.Fatalf("registration should mark a live, unlisted agent session: %+v, %v", reg, err)
	}
	if !wslive.AdapterPresent(wslive.SnapshotPath(dir), time.Now()) {
		t.Fatalf("an open conversation's snapshot should name its adapter")
	}
	if h.backend.startCount() != 0 {
		t.Fatalf("create should not start a process")
	}
}

func TestCreateRefusesBadLaunch(t *testing.T) {
	h := newHarness(t, map[string]string{
		"other":   `{"backend":"@other"}`,
		"noinstr": `{"backend":"claude","instructions":"missing.md"}`,
	})
	for profile, want := range map[string]string{"absent": "unknown agent profile", "other": fmt.Sprintf("backend %q is not available", otherBackend()), "noinstr": "instruction file"} {
		_, err := h.runner.Create(profile, h.root)
		if err == nil || requestStatus(err) != http.StatusBadRequest || !strings.Contains(err.Error(), want) {
			t.Errorf("Create(%s) = %v, want a 400 naming %q", profile, err, want)
		}
	}
	if _, err := h.runner.Create("noinstr", "relative/root"); requestStatus(err) != http.StatusBadRequest {
		t.Errorf("a relative root should be refused, got %v", err)
	}
}

// TestSendRunsTurnAndHeldSendsGoAsOneTurn: each send during a turn is its
// own held message, and the turn end delivers them all as one next turn,
// joined in queue order: the steered message first, then the follow-ups.
func TestSendRunsTurnAndHeldSendsGoAsOneTurn(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	id := h.create("chat").ID
	if _, err := h.runner.Send(id, "first"); err != nil {
		t.Fatal(err)
	}
	eventually(t, "process start", func() bool { return h.backend.startCount() == 1 })
	p := h.backend.waitProc(t, 0)
	if got := p.nextSent(t); got != "first" {
		t.Fatalf("first turn = %q", got)
	}
	spec := h.backend.start(0)
	if spec.Root != h.root || spec.Model != "haiku" || spec.SessionID != "" || spec.WSMCP != nil {
		t.Fatalf("start spec = %+v", spec)
	}
	instr, err := os.ReadFile(spec.Instructions)
	if err != nil || !strings.Contains(string(instr), "Answer questions") {
		t.Fatalf("the composed instructions should hold the profile's file: %q, %v", instr, err)
	}
	if st := h.state(id); st.Status != StatusRunning || !st.Process {
		t.Fatalf("a sent turn runs: %+v", st)
	}

	for _, text := range []string{"second", "third", "fourth"} {
		st, err := h.runner.Send(id, text)
		if err != nil {
			t.Fatal(err)
		}
		if st.Status != StatusRunning {
			t.Fatalf("a send during a turn is held, the turn keeps running: %+v", st)
		}
	}
	if st := h.state(id); st.Held != 3 {
		t.Fatalf("three held sends should be three held messages, held %d", st.Held)
	}
	// Promote "fourth": a profile conversation's turn takes no steered
	// message, so it waits for the turn end, ahead of the follow-ups.
	inbox := wsinbox.Dir(wsdashboard.SessionDir(h.dir, id))
	held, _ := wsinbox.Held(inbox)
	if len(held) != 3 || held[2].Entry.Text() != "fourth" {
		t.Fatalf("held = %+v", held)
	}
	if _, err := wsinbox.Steer(inbox, held[2].Name); err != nil {
		t.Fatal(err)
	}
	p.events <- Event{SessionID: "backend-1"}
	p.reply("answer one")
	if got := p.nextSent(t); got != "fourth\n\nsecond\n\nthird" {
		t.Fatalf("the held sends should be the next turn as one message, steered first, got %q", got)
	}
	p.reply("answer two")
	eventually(t, "idle", func() bool { return h.state(id).Status == StatusIdle })

	ring, err := wslive.ReadRing(wslive.RingDir(wsdashboard.SessionDir(h.dir, id)))
	if err != nil {
		t.Fatal(err)
	}
	var texts []string
	for _, r := range ring {
		if r.Kind == wslive.RingUser || r.Kind == wslive.RingReply {
			texts = append(texts, r.Kind+":"+r.Text)
		}
	}
	want := "user:first reply:answer one user:fourth\n\nsecond\n\nthird reply:answer two"
	if strings.Join(texts, " ") != want {
		t.Fatalf("ring = %q, want %q", strings.Join(texts, " "), want)
	}
	rec, _ := readRecord(wsdashboard.SessionDir(h.dir, id))
	if rec.SessionID != "backend-1" {
		t.Fatalf("the backend session id should be persisted, got %q", rec.SessionID)
	}
}

func TestIdleTimerEndsProcessAndNextSendResumes(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": `{"backend":"claude","idle_timeout_seconds":1}`})
	id := h.create("chat").ID
	h.runner.Send(id, "hello")
	eventually(t, "start", func() bool { return h.backend.startCount() == 1 })
	p := h.backend.waitProc(t, 0)
	p.nextSent(t)
	p.events <- Event{SessionID: "backend-1"}
	p.reply("hi")
	eventually(t, "idle exit", func() bool { return p.isClosed() && !h.state(id).Process })

	h.runner.Send(id, "again")
	eventually(t, "resume", func() bool { return h.backend.startCount() == 2 })
	if got := h.backend.start(1).SessionID; got != "backend-1" {
		t.Fatalf("the next send should resume the backend session, got %q", got)
	}
	if got := h.backend.waitProc(t, 1).nextSent(t); got != "again" {
		t.Fatalf("resumed turn = %q", got)
	}
}

func TestIdleTimeoutZeroNeverExits(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": `{"backend":"claude","idle_timeout_seconds":0}`})
	id := h.create("chat").ID
	h.runner.Send(id, "hello")
	eventually(t, "start", func() bool { return h.backend.startCount() == 1 })
	p := h.backend.waitProc(t, 0)
	p.nextSent(t)
	p.reply("hi")
	time.Sleep(1200 * time.Millisecond)
	if p.isClosed() || !h.state(id).Process {
		t.Fatalf("idle_timeout_seconds 0 should keep the process")
	}
}

func TestRecordSurvivesDaemonRestart(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": `{"backend":"claude","ws_tools":["tickets.query"]}`})
	id := h.create("chat").ID
	h.runner.Send(id, "hello")
	eventually(t, "start", func() bool { return h.backend.startCount() == 1 })
	p := h.backend.waitProc(t, 0)
	p.nextSent(t)
	p.events <- Event{SessionID: "backend-7"}
	eventually(t, "session id", func() bool {
		rec, _ := readRecord(wsdashboard.SessionDir(h.dir, id))
		return rec.SessionID == "backend-7"
	})
	// A held send survives the restart too.
	h.runner.Send(id, "held over")
	h.runner.SetSettings(id, ptr("sonnet"), nil)
	h.runner.Close()
	if !p.isClosed() {
		t.Fatalf("the daemon's shutdown should end the process")
	}

	h.start()
	st := h.state(id)
	if st.Status != StatusIdle || st.Process || st.Held != 1 || st.Model != "sonnet" {
		t.Fatalf("after a restart the conversation is open, idle, processless, still holding its send: %+v", st)
	}
	if h.backend.startCount() != 1 {
		t.Fatalf("a restart must not start processes (lazy resume)")
	}
	h.runner.Send(id, "new")
	eventually(t, "resume", func() bool { return h.backend.startCount() == 2 })
	spec := h.backend.start(1)
	if spec.SessionID != "backend-7" || spec.Model != "sonnet" {
		t.Fatalf("the resumed process should carry the recorded session and model: %+v", spec)
	}
	if got := h.backend.waitProc(t, 1).nextSent(t); got != "held over\n\nnew" {
		t.Fatalf("the held send should merge with the next one, got %q", got)
	}
	rec := readEventually(t, "read the record", func() (Record, error) { return readRecord(wsdashboard.SessionDir(h.dir, id)) })
	instr, _ := os.ReadFile(spec.Instructions)
	if !strings.Contains(string(instr), rec.WSKey) {
		t.Fatalf("the agent should get its ws session key in its instructions")
	}
	if spec.WSMCP == nil || spec.WSMCP.Env[EnvAllowedTools] != "tickets.query" || spec.WSMCP.Env[EnvNoDashboard] != "1" {
		t.Fatalf("ws-mcp should carry the allowlist and the dashboard off: %+v", spec.WSMCP)
	}
	for _, name := range []string{"WS_MAILBOX", "WS_MAILBOX_AUTO"} {
		if v, ok := spec.WSMCP.Env[name]; !ok || v != "" {
			t.Fatalf("ws-mcp must not inherit a mailbox identity: %s=%q (set %v)", name, v, ok)
		}
	}
	if len(h.keys.ensured) != 2 || h.keys.ensured[1] != rec.WSKey {
		t.Fatalf("every start should keep the same key usable: %v", h.keys.ensured)
	}
}

func TestPiWorkerResumeAcceptsLegacyRootKeyAndRefusesForeignKey(t *testing.T) {
	for _, closed := range []bool{false, true} {
		for _, foreign := range []bool{false, true} {
			t.Run(fmt.Sprintf("closed=%t/foreign=%t", closed, foreign), func(t *testing.T) {
				h, _ := childHarness(t)
				worker := h.spawnWorker("small")
				p := h.backend.waitProc(t, 0)
				p.nextSent(t)
				p.reply("initial result")
				eventually(t, "initial turn settled", func() bool { return h.state(worker.ID).Status == StatusIdle })
				if closed {
					if _, err := h.runner.CloseConversation(worker.ID); err != nil {
						t.Fatal(err)
					}
				}
				h.runner.Close()
				dir := wsdashboard.SessionDir(h.dir, worker.ID)
				rec, err := readRecord(dir)
				if err != nil {
					t.Fatal(err)
				}
				// Model a 0.49.x record: the key remains bound to Root,
				// but the persisted child works in a different directory.
				rec.Cwd = filepath.Join(h.root, "work")
				if err := os.MkdirAll(rec.Cwd, 0o700); err != nil {
					t.Fatal(err)
				}
				if err := writeRecord(dir, rec); err != nil {
					t.Fatal(err)
				}
				if err := os.MkdirAll(filepath.Dir(piSessionFile(dir)), 0o700); err != nil {
					t.Fatal(err)
				}
				if err := os.WriteFile(piSessionFile(dir), []byte("persisted conversation\n"), 0o600); err != nil {
					t.Fatal(err)
				}
				if foreign {
					h.keys.mu.Lock()
					h.keys.roots[rec.WSKey] = t.TempDir()
					h.keys.mu.Unlock()
				}
				h.start()
				if _, err := h.runner.Send(worker.ID, "continue"); err != nil {
					t.Fatal(err)
				}
				if foreign {
					eventually(t, "foreign key refusal", func() bool {
						return strings.Contains(h.state(worker.ID).Error, "session key record is not this conversation's")
					})
					if h.backend.startCount() != 1 {
						t.Fatal("a foreign key started another process")
					}
					return
				}
				if got := h.backend.waitProc(t, 1).nextSent(t); got != "continue" {
					t.Fatalf("resumed prompt = %q", got)
				}
				if spec := h.backend.start(1); spec.Cwd != rec.Cwd || spec.Root != rec.Root {
					t.Fatalf("legacy resume changed root/cwd: %+v", spec)
				}
				h.keys.mu.Lock()
				boundRoot := h.keys.roots[rec.WSKey]
				h.keys.mu.Unlock()
				if boundRoot != rec.Root {
					t.Fatalf("legacy key binding changed: %q", boundRoot)
				}
			})
		}
	}
}

func TestHandedOffStatesDoNotCacheSnapshots(t *testing.T) {
	reads := 0
	r := NewRunner(Options{Dir: t.TempDir(), closedSnapshotRead: func(string) { reads++ }})
	rec := Record{ReplyID: "handedoff", Lead: true, Backend: BackendPi, Root: t.TempDir(), HandedOffAt: "2026-01-01T00:00:00Z"}
	r.mu.Lock()
	defer r.mu.Unlock()
	for range 2 {
		if st := r.closedState(rec); st.Status != StatusHandedOff {
			t.Fatalf("handed-off state = %+v", st)
		}
	}
	if reads != 2 {
		t.Fatalf("terminal-owned snapshots must remain uncached: reads = %d", reads)
	}
}

// TestFinishedAgentsSurviveDaemonRestart pins that a restarted daemon keeps
// the finished subagents of the snapshot the previous one left, and drops
// the ones it showed running.
func TestFinishedAgentsSurviveDaemonRestart(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	id := h.create("chat").ID
	h.runner.Close()

	path := wslive.SnapshotPath(wsdashboard.SessionDir(h.dir, id))
	snap, err := wslive.ReadSnapshot(path)
	if err != nil {
		t.Fatal(err)
	}
	snap.Agents = []wslive.Agent{
		{ID: "fin", Label: "worker", Status: wslive.StatusDone, StartedAt: 100, EndedAt: 200},
		{ID: "run", Label: "killed", Status: wslive.StatusRunning, StartedAt: 150},
	}
	raw, err := json.Marshal(snap)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, raw, 0o644); err != nil {
		t.Fatal(err)
	}

	h.start()
	h.state(id)
	after, err := wslive.ReadSnapshot(path)
	if err != nil {
		t.Fatal(err)
	}
	if len(after.Agents) != 1 || after.Agents[0].ID != "fin" || after.Agents[0].Status != wslive.StatusDone || after.Agents[0].Label != "worker" {
		t.Fatalf("the restarted daemon should keep the finished agent only: %+v", after.Agents)
	}
}

func TestStopKeepsHeldAndResumes(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	id := h.create("chat").ID
	h.runner.Send(id, "one")
	eventually(t, "start", func() bool { return h.backend.startCount() == 1 })
	p := h.backend.waitProc(t, 0)
	p.nextSent(t)
	p.events <- Event{SessionID: "s1"}
	// The event is buffered: the loop picks between it and the stop below
	// at random when both are ready, and a stop handled first ends the
	// process with the event unread.
	eventually(t, "session id", func() bool {
		rec, _ := readRecord(wsdashboard.SessionDir(h.dir, id))
		return rec.SessionID == "s1"
	})
	h.runner.Send(id, "two")
	st, err := h.runner.Stop(id)
	if err != nil {
		t.Fatal(err)
	}
	if !p.isClosed() || st.Process || st.Status != StatusIdle || st.Held != 1 {
		t.Fatalf("stop ends the process and the turn, keeping the held send: %+v", st)
	}
	h.runner.Send(id, "three")
	eventually(t, "resume", func() bool { return h.backend.startCount() == 2 })
	if h.backend.start(1).SessionID != "s1" {
		t.Fatalf("after stop the next send resumes the session")
	}
	if got := h.backend.waitProc(t, 1).nextSent(t); got != "two\n\nthree" {
		t.Fatalf("got %q", got)
	}
}

func TestCloseEndsConversationForGood(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	id := h.create("chat").ID
	h.runner.Send(id, "one")
	eventually(t, "start", func() bool { return h.backend.startCount() == 1 })
	p := h.backend.waitProc(t, 0)
	p.nextSent(t)
	h.runner.Send(id, "held")
	st, err := h.runner.CloseConversation(id)
	if err != nil {
		t.Fatal(err)
	}
	if st.Status != StatusClosed || st.ClosedAt == "" || !p.isClosed() || st.Held != 0 {
		t.Fatalf("close ends the process and drops held sends: %+v", st)
	}
	if _, err := h.runner.Send(id, "more"); requestStatus(err) != http.StatusConflict {
		t.Fatalf("a send to a closed conversation is refused, got %v", err)
	}
	dir := wsdashboard.SessionDir(h.dir, id)
	if ring, err := wslive.ReadRing(wslive.RingDir(dir)); err != nil || len(ring) == 0 {
		t.Fatalf("the closed conversation's ring stays readable: %v", err)
	}
	if reg, _ := wsdashboard.ReadRegistration(h.dir, id); reg.EndedAt == "" {
		t.Fatalf("the registration should be ended")
	}
	if wslive.AdapterPresent(wslive.SnapshotPath(dir), time.Now()) {
		t.Fatalf("a closed conversation's page should refuse input")
	}

	h.runner.Close()
	h.start()
	if st := h.state(id); st.Status != StatusClosed {
		t.Fatalf("closed stays closed across a restart: %+v", st)
	}
	if _, err := h.runner.Send(id, "more"); requestStatus(err) != http.StatusConflict {
		t.Fatalf("got %v", err)
	}
	if len(h.runner.List()) != 1 {
		t.Fatalf("List should still report the closed conversation")
	}
}

func TestInterruptTakesBackHeldAndStopsTurn(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	id := h.create("chat").ID
	h.runner.Send(id, "one")
	eventually(t, "start", func() bool { return h.backend.startCount() == 1 })
	p := h.backend.waitProc(t, 0)
	p.nextSent(t)
	h.runner.Send(id, "held")
	st, returned, err := h.runner.Interrupt(id)
	if err != nil {
		t.Fatal(err)
	}
	if len(returned) != 1 || returned[0] != "held" || st.Held != 0 {
		t.Fatalf("interrupt returns the held text: %v %+v", returned, st)
	}
	p.mu.Lock()
	n := p.interrupts
	p.mu.Unlock()
	if n != 1 {
		t.Fatalf("the running turn should be interrupted once, got %d", n)
	}
	p.events <- Event{TurnEnd: true}
	eventually(t, "idle", func() bool { return h.state(id).Status == StatusIdle })
	select {
	case s := <-p.sent:
		t.Fatalf("nothing should be submitted after an interrupt, got %q", s)
	case <-time.After(50 * time.Millisecond):
	}
}

func TestSettingsApplyAtTurnBoundary(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	id := h.create("chat").ID
	h.runner.Send(id, "one")
	eventually(t, "start", func() bool { return h.backend.startCount() == 1 })
	p := h.backend.waitProc(t, 0)
	p.nextSent(t)
	st, err := h.runner.SetSettings(id, ptr("sonnet"), nil)
	if err != nil || st.Model != "sonnet" {
		t.Fatalf("SetSettings: %+v %v", st, err)
	}
	p.mu.Lock()
	early := len(p.models)
	p.mu.Unlock()
	if early != 0 {
		t.Fatalf("a model change must wait for the turn boundary")
	}
	p.reply("done")
	eventually(t, "in-stream model", func() bool {
		p.mu.Lock()
		defer p.mu.Unlock()
		return len(p.models) == 1 && p.models[0] == "sonnet"
	})
	if p.isClosed() {
		t.Fatalf("an in-stream model change keeps the process")
	}

	// Effort has no in-stream control: the process restarts on the session.
	if _, err := h.runner.SetSettings(id, nil, ptr("high")); err != nil {
		t.Fatal(err)
	}
	eventually(t, "restart for effort", func() bool { return p.isClosed() })
	h.runner.Send(id, "two")
	eventually(t, "restart", func() bool { return h.backend.startCount() == 2 })
	if spec := h.backend.start(1); spec.Effort != "high" || spec.Model != "sonnet" {
		t.Fatalf("the restarted process carries the new settings: %+v", spec)
	}
	if _, err := h.runner.SetSettings(id, ptr("bad model!"), nil); requestStatus(err) != http.StatusBadRequest {
		t.Fatalf("a malformed model is refused, got %v", err)
	}
}

func TestFailuresSurfaceInState(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	id := h.create("chat").ID
	h.backend.mu.Lock()
	h.backend.startErr = errors.New("claude not found")
	h.backend.mu.Unlock()
	h.runner.Send(id, "one")
	eventually(t, "error", func() bool { return strings.Contains(h.state(id).Error, "claude not found") })
	if st := h.state(id); st.Held != 1 || st.Status != StatusIdle {
		t.Fatalf("a failed start keeps the message held: %+v", st)
	}

	h.backend.mu.Lock()
	h.backend.startErr = nil
	h.backend.mu.Unlock()
	h.runner.Send(id, "two")
	eventually(t, "start", func() bool { return h.backend.startCount() == 1 })
	p := h.backend.waitProc(t, 0)
	if got := p.nextSent(t); got != "one\n\ntwo" {
		t.Fatalf("got %q", got)
	}
	p.events <- Event{Fatal: errors.New("launch refused: claude reports tools outside the profile: Write")}
	eventually(t, "refusal", func() bool {
		st := h.state(id)
		return !st.Process && st.Status == StatusIdle && strings.Contains(st.Error, "launch refused")
	})

	h.runner.Send(id, "three")
	eventually(t, "restart", func() bool { return h.backend.startCount() == 2 })
	p = h.backend.waitProc(t, 1)
	p.nextSent(t)
	p.exit()
	eventually(t, "crash", func() bool {
		st := h.state(id)
		return !st.Process && st.Status == StatusIdle && st.Error != ""
	})
}

// TestFailedSendRetriesOnceOnANewProcess: a turn whose send fails stays
// queued and goes on a new process with no further inbox signal.
func TestFailedSendRetriesOnceOnANewProcess(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	id := h.create("chat").ID
	h.backend.setFailSends(1)
	h.runner.Send(id, "one")
	first := h.backend.waitProc(t, 0)
	if got := h.backend.waitProc(t, 1).nextSent(t); got != "one" {
		t.Fatalf("the retried turn = %q", got)
	}
	if !first.isClosed() || h.backend.startCount() != 2 {
		t.Fatalf("the failed send ends its process and one new one starts: %d starts", h.backend.startCount())
	}
	select {
	case s := <-first.sent:
		t.Fatalf("the failed process took %q", s)
	default:
	}
	eventually(t, "the turn to run with nothing held", func() bool {
		st := h.state(id)
		return st.Status == StatusRunning && st.Held == 0 && st.Error == ""
	})
}

// TestFailingSendRestartsOnceAndStops: a send that always fails restarts
// the process once, then waits for the next inbox signal, which gets one
// more attempt and no retry; the next send that goes through takes it all
// and arms the retry again.
func TestFailingSendRestartsOnceAndStops(t *testing.T) {
	h := newHarness(t, map[string]string{"chat": chatProfile})
	id := h.create("chat").ID
	h.backend.setFailSends(-1)
	h.runner.Send(id, "one")
	eventually(t, "the retry's start", func() bool { return h.backend.startCount() == 2 })
	eventually(t, "the retry's process to end", func() bool { return h.backend.proc(1).isClosed() })
	time.Sleep(200 * time.Millisecond)
	st := h.state(id)
	if n := h.backend.startCount(); n != 2 || st.Process || st.Held != 1 || !strings.Contains(st.Error, "send turn") {
		t.Fatalf("one retry, then nothing: %d starts, state %+v", n, st)
	}

	h.runner.Send(id, "two")
	eventually(t, "the next signal's attempt", func() bool { return h.backend.startCount() == 3 })
	eventually(t, "its process to end", func() bool { return h.backend.proc(2).isClosed() })
	time.Sleep(200 * time.Millisecond)
	if n := h.backend.startCount(); n != 3 || h.state(id).Held != 2 {
		t.Fatalf("a spent retry is not armed again by a failed send: %d starts, state %+v", n, h.state(id))
	}

	h.backend.setFailSends(0)
	h.runner.Send(id, "three")
	if got := h.backend.waitProc(t, 3).nextSent(t); got != "one\n\ntwo\n\nthree" {
		t.Fatalf("the queued turn = %q", got)
	}
	h.backend.proc(3).reply("done")
	eventually(t, "idle", func() bool { return h.state(id).Status == StatusIdle })

	// The send that went through armed the retry again.
	h.backend.setFailSends(1)
	h.runner.Send(id, "four")
	if got := h.backend.waitProc(t, 4).nextSent(t); got != "four" {
		t.Fatalf("the retried turn = %q", got)
	}
}

func ptr(s string) *string { return &s }

// TestRunnerSuiteOnPi runs the runner suite again with every profile on
// the pi backend: the runner treats the backends alike through Process.
func TestRunnerSuiteOnPi(t *testing.T) {
	suiteBackend = BackendPi
	t.Cleanup(func() { suiteBackend = BackendClaude })
	for name, test := range map[string]func(*testing.T){
		"CreateWritesRecordRegistrationAndSnapshot": TestCreateWritesRecordRegistrationAndSnapshot,
		"CreateRefusesBadLaunch":                    TestCreateRefusesBadLaunch,
		"SendRunsTurnAndHeldSendsGoAsOneTurn":       TestSendRunsTurnAndHeldSendsGoAsOneTurn,
		"IdleTimerEndsProcessAndNextSendResumes":    TestIdleTimerEndsProcessAndNextSendResumes,
		"IdleTimeoutZeroNeverExits":                 TestIdleTimeoutZeroNeverExits,
		"RecordSurvivesDaemonRestart":               TestRecordSurvivesDaemonRestart,
		"StopKeepsHeldAndResumes":                   TestStopKeepsHeldAndResumes,
		"CloseEndsConversationForGood":              TestCloseEndsConversationForGood,
		"InterruptTakesBackHeldAndStopsTurn":        TestInterruptTakesBackHeldAndStopsTurn,
		"SettingsApplyAtTurnBoundary":               TestSettingsApplyAtTurnBoundary,
		"FailuresSurfaceInState":                    TestFailuresSurfaceInState,
		"RESTRoutesEndToEnd":                        TestRESTRoutesEndToEnd,
		"RESTWritesRefuseOtherOrigins":              TestRESTWritesRefuseOtherOrigins,
	} {
		t.Run(name, test)
	}
}

// TestRunnerWithoutHoldersIsScannedAtStart: with no holder manager there is
// no first scan to wait for, so Start marks it done at once, and a second
// Start does not close it again.
func TestRunnerWithoutHoldersIsScannedAtStart(t *testing.T) {
	r := NewRunner(Options{Dir: t.TempDir()})
	t.Cleanup(r.Close)
	if r.scanDone() {
		t.Fatal("scanned before Start")
	}
	r.Start(nil)
	if !r.scanDone() {
		t.Fatal("a runner with no holder manager waits for a scan that never comes")
	}
	r.Start(nil)
	if !r.scanDone() {
		t.Fatal("scanned no longer reads done")
	}
}
