package wsconfig

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/gofrs/flock"
	"github.com/kang-sw/devenv/internal/wsstate"
)

const schemaVersion = 1

type Options struct {
	CacheHome string
	// ConfigHome overrides the global config directory. Resolution order:
	// ConfigHome → $WS_CONFIG_HOME → ~/.ws/config.json (note: ~/.ws, not ~/.cache).
	// Mirrors the CacheHome test-seam shape so tests can use Options{ConfigHome: t.TempDir()}.
	ConfigHome string
	// RepoRoot anchors the committed repo scope: when non-empty the resolver
	// reads <RepoRoot>/.ws-workflow/config.json (see RepoPath). It is the caller's
	// canonical Git worktree root — the same root the session key resolves to, so
	// each worktree reads its own checked-out copy of the committed file. Empty
	// means "no repo scope for this resolver" (the file scopes fall through to
	// global/builtin); the repo layer is never an error just for being absent.
	RepoRoot string
}

type Config struct {
	SchemaVersion int          `json:"schema_version"`
	Agents        AgentsConfig `json:"agents"`
	// Overrides is a generic key→value overlay for scope-aware config items.
	// Keys are item identifiers; values are string-encoded config values.
	// The field is additive: existing configs without it parse with a nil map.
	Overrides map[string]string `json:"overrides,omitempty"`
	// StructuredOverrides holds JSON-object values (a worktree profile) keyed by
	// the full item key, mirroring Overrides. It is a separate top-level member,
	// never an object inside Overrides: an older ws decodes Overrides as
	// map[string]string and fails the whole resolution on an object there, while
	// its json.Unmarshal ignores this unknown member. The member name is a
	// committed on-disk format downstream repositories carry; do not rename it.
	StructuredOverrides map[string]json.RawMessage `json:"structured_overrides,omitempty"`
}

type AgentsConfig struct {
	Tiers        map[string]AgentTier            `json:"tiers,omitempty"`
	ModelAliases map[string]map[string]AgentTier `json:"model_aliases,omitempty"`
}

type View struct {
	Path   string `json:"path"`
	Config Config `json:"config"`
	// ResolvedOverrides carries each scoped config item's value and the scope it
	// resolved from. Populated by ScopedShow; nil when populated by plain Show.
	ResolvedOverrides []ScopedItem `json:"resolved_overrides,omitempty"`
	// RepoScope describes the committed repo-scope file the view resolved
	// against. Populated by ScopedShow; nil when populated by plain Show.
	RepoScope *RepoScopeInfo `json:"repo_scope,omitempty"`
}

// ScopedItem pairs an item key with its resolved value and source scope for
// human-readable and JSON show output.
type ScopedItem struct {
	Key   string `json:"key"`
	Value string `json:"value"`
	Scope Scope  `json:"scope"`
	// RepoScope reports whether the committed repo scope can supply this key
	// (see RepoScoped).
	RepoScope bool `json:"repo_scope"`
}

type AgentTier struct {
	Backend string `json:"backend,omitempty"`
	Model   string `json:"model,omitempty"`
	Effort  string `json:"effort,omitempty"`
}

func Load(opts Options) (Config, error) {
	stored, err := loadProjectConfig(opts)
	if err != nil {
		return Config{}, err
	}
	cfg := effectiveAgentConfig(stored)
	cfg.Overrides = stored.Overrides
	cfg.StructuredOverrides = stored.StructuredOverrides
	return cfg, nil
}

// loadProjectConfig reads only the persisted project layer. Unlike Load, it
// does not add builtin aliases: callers that combine project and global layers
// must distinguish an absent leaf from a builtin fallback.
func loadProjectConfig(opts Options) (Config, error) {
	path, err := Path(opts)
	if err != nil {
		return Config{}, err
	}
	return loadConfigFile(path, "project")
}

func loadConfigFile(path, scope string) (Config, error) {
	raw, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		return Config{}, nil
	}
	if err != nil {
		return Config{}, fmt.Errorf("read %s ws config: %w", scope, err)
	}
	var cfg Config
	if err := json.Unmarshal(raw, &cfg); err != nil {
		return Config{}, fmt.Errorf("parse %s ws config: %w", scope, err)
	}
	return cfg, nil
}

// effectiveAgentConfig overlays sparse config layers onto builtin tier aliases.
// Later layers win per tier/harness leaf, rather than replacing a whole tier map.
func effectiveAgentConfig(layers ...Config) Config {
	cfg := Config{
		SchemaVersion: schemaVersion,
		Agents: AgentsConfig{
			Tiers:        map[string]AgentTier{},
			ModelAliases: map[string]map[string]AgentTier{},
		},
	}
	for _, layer := range layers {
		normalizeLegacyTierKeys(layer.Agents.Tiers, layer.Agents.ModelAliases)
		mergeAgentConfig(&cfg, layer)
	}
	explicitTiers := make(map[string]bool, len(cfg.Agents.Tiers))
	for tier := range cfg.Agents.Tiers {
		explicitTiers[tier] = true
	}
	applyDefaultTiers(cfg.Agents.Tiers)

	// Legacy configurations that define a tier but no aliases expect that tier
	// to seed every alias. Once a layer defines any alias leaf, however, missing
	// siblings are builtin leaves, not implicit copies of that layer's default
	// tier: this preserves sparse project/global leaf overlays.
	aliasTiers := defaultConfig().Agents.Tiers
	for tier, mapping := range cfg.Agents.Tiers {
		if explicitTiers[tier] || len(cfg.Agents.ModelAliases[tier]) == 0 {
			aliasTiers[tier] = mapping
		}
	}
	storedAliases := cfg.Agents.ModelAliases
	cfg.Agents.ModelAliases = defaultModelAliases(aliasTiers)
	mergeAgentConfig(&cfg, Config{Agents: AgentsConfig{ModelAliases: storedAliases}})
	return cfg
}

func mergeAgentConfig(dst *Config, src Config) {
	for tier, mapping := range src.Agents.Tiers {
		dst.Agents.Tiers[tier] = mapping
	}
	for tier, byHarness := range src.Agents.ModelAliases {
		if dst.Agents.ModelAliases[tier] == nil {
			dst.Agents.ModelAliases[tier] = map[string]AgentTier{}
		}
		for harness, mapping := range byHarness {
			dst.Agents.ModelAliases[tier][harness] = mapping
		}
	}
}

// LoadAgentTierConfig returns effective AgentTier values after applying the
// builtin < global < project leaf overlay. It intentionally leaves Overrides
// alone: scalar overrides remain the Resolver's responsibility.
func LoadAgentTierConfig(opts Options) (Config, error) {
	globalCfg, err := loadGlobalConfig(opts)
	if err != nil {
		return Config{}, err
	}
	projectCfg, err := loadProjectConfig(opts)
	if err != nil {
		return Config{}, err
	}
	return effectiveAgentConfig(globalCfg, projectCfg), nil
}

// normalizeLegacyTierKeys migrates persisted light/core/deep map keys to their
// capability equivalents (small/medium/large) in-memory. Capability key wins on
// collision; legacy key is dropped. Operates on both Tiers and ModelAliases.
func normalizeLegacyTierKeys(tiers map[string]AgentTier, aliases map[string]map[string]AgentTier) {
	// Normalize Tiers map.
	for legacyKey, val := range tiers {
		capKey := normalizedTier(legacyKey)
		if capKey == "" || capKey == legacyKey {
			// Already a capability key or unrecognized — skip.
			continue
		}
		if _, exists := tiers[capKey]; !exists {
			tiers[capKey] = val
		}
		// Capability key wins; drop the legacy duplicate.
		delete(tiers, legacyKey)
	}
	if aliases == nil {
		return
	}
	// Normalize ModelAliases outer (alias) key.
	for legacyKey, byHarness := range aliases {
		capKey := normalizedTier(legacyKey)
		if capKey == "" || capKey == legacyKey {
			continue
		}
		if _, exists := aliases[capKey]; !exists {
			aliases[capKey] = byHarness
		}
		delete(aliases, legacyKey)
	}
}

func Show(opts Options) (View, error) {
	path, err := Path(opts)
	if err != nil {
		return View{}, err
	}
	cfg, err := Load(opts)
	if err != nil {
		return View{}, err
	}
	return View{Path: path, Config: presentationAgentConfig(cfg)}, nil
}

// ShowResolved is Show's display-layer sibling: it composes the agents.tier
// model_aliases the same builtin<global<project way LoadAgentTierConfig
// already resolves them (the same precedence the MCP config.list tuning
// catalog surfaces via currentAgentTierMappings), instead of Show's
// project-only Load. Path and Overrides stay project-scoped, matching Show;
// only the agent-tier mapping gains global-scope visibility. Intended for CLI
// display callers that want the MCP-consistent resolved view without
// reimplementing precedence.
func ShowResolved(opts Options) (View, error) {
	path, err := Path(opts)
	if err != nil {
		return View{}, err
	}
	tierCfg, err := LoadAgentTierConfig(opts)
	if err != nil {
		return View{}, err
	}
	projectCfg, err := loadProjectConfig(opts)
	if err != nil {
		return View{}, err
	}
	cfg := presentationAgentConfig(tierCfg)
	cfg.Overrides = projectCfg.Overrides
	return View{Path: path, Config: cfg}, nil
}

// presentationAgentConfig keeps the legacy Tiers view aligned with an explicit
// default alias without making that compatibility view part of read precedence.
func presentationAgentConfig(cfg Config) Config {
	for tier, aliases := range cfg.Agents.ModelAliases {
		if mapping, ok := aliases["default"]; ok {
			cfg.Agents.Tiers[tier] = mapping
		}
	}
	return cfg
}

func SetAgentsTier(opts Options, tier, backend, model string, effortValues ...string) (Config, error) {
	return SetAgentsTierForHarness(opts, tier, backend, model, "", effortValues...)
}

// SetAgentsTierForHarness writes one tier/harness leaf to project scope.
func SetAgentsTierForHarness(opts Options, tier, backend, model, harness string, effortValues ...string) (Config, error) {
	cfg, err := setAgentsTierForHarness(opts, false, tier, backend, model, harness, effortValues...)
	if err != nil {
		return Config{}, err
	}
	return presentationAgentConfig(effectiveAgentConfig(cfg)), nil
}

// SetGlobalAgentsTierForHarness writes one tier/harness leaf to the cross-project
// global config. It stays separate from the resolver because AgentTier is a
// structured value, not a resolver override string.
func SetGlobalAgentsTierForHarness(opts Options, tier, backend, model, harness string, effortValues ...string) (Config, error) {
	cfg, err := setAgentsTierForHarness(opts, true, tier, backend, model, harness, effortValues...)
	if err != nil {
		return Config{}, err
	}
	return presentationAgentConfig(effectiveAgentConfig(cfg)), nil
}

// UnsetAgentsTierForHarness removes one persisted project-scope tier/harness leaf.
func UnsetAgentsTierForHarness(opts Options, tier, harness string) (Config, bool, error) {
	return unsetAgentsTierForHarness(opts, false, tier, harness)
}

// UnsetGlobalAgentsTierForHarness removes one persisted global tier/harness leaf.
func UnsetGlobalAgentsTierForHarness(opts Options, tier, harness string) (Config, bool, error) {
	return unsetAgentsTierForHarness(opts, true, tier, harness)
}

func unsetAgentsTierForHarness(opts Options, global bool, tier, harness string) (Config, bool, error) {
	tier = normalizedTier(tier)
	if tier == "" {
		return Config{}, false, fmt.Errorf("tier must be small, medium, large, or xlarge")
	}
	key, err := aliasTargetKey(harness)
	if err != nil {
		return Config{}, false, err
	}

	path, err := agentsConfigPath(opts, global)
	if err != nil {
		return Config{}, false, err
	}
	// An absent file has no leaf to remove; return before locking so the no-op
	// creates no directory or lock file.
	if !configFileExists(path) {
		return presentationAgentConfig(effectiveAgentConfig(Config{})), false, nil
	}
	removed := false
	stored, err := updateConfigFile(path, func(cfg *Config) error {
		normalizeLegacyTierKeys(cfg.Agents.Tiers, cfg.Agents.ModelAliases)
		byHarness := cfg.Agents.ModelAliases[tier]
		if _, removed = byHarness[key]; !removed {
			return errConfigUnchanged
		}
		delete(byHarness, key)
		if len(byHarness) == 0 {
			delete(cfg.Agents.ModelAliases, tier)
		}
		return nil
	})
	if err != nil {
		return Config{}, false, err
	}
	return presentationAgentConfig(effectiveAgentConfig(stored)), removed, nil
}

// HasProjectAgentsTierLeaf reports whether the exact tier/harness leaf is
// persisted in the project config, without counting resolver fallbacks.
func HasProjectAgentsTierLeaf(opts Options, tier, harness string) (bool, error) {
	tier = normalizedTier(tier)
	if tier == "" {
		return false, fmt.Errorf("tier must be small, medium, large, or xlarge")
	}
	key, err := aliasTargetKey(harness)
	if err != nil {
		return false, err
	}
	stored, err := loadProjectConfig(opts)
	if err != nil {
		return false, err
	}
	normalizeLegacyTierKeys(stored.Agents.Tiers, stored.Agents.ModelAliases)
	_, exists := stored.Agents.ModelAliases[tier][key]
	return exists, nil
}

func setAgentsTierForHarness(opts Options, global bool, tier, backend, model, harness string, effortValues ...string) (Config, error) {
	tier = normalizedTier(tier)
	if tier == "" {
		return Config{}, fmt.Errorf("tier must be small, medium, large, or xlarge")
	}
	backend = strings.TrimSpace(backend)
	model = strings.TrimSpace(model)
	hasBackendInput := backend != ""
	hasModelInput := model != ""
	effort, hasEffort, err := normalizeOptionalEffort(effortValues...)
	if err != nil {
		return Config{}, err
	}
	if backend == "" {
		backend = InferBackend(model)
	}

	key, err := aliasTargetKey(harness)
	if err != nil {
		return Config{}, err
	}
	path, err := agentsConfigPath(opts, global)
	if err != nil {
		return Config{}, err
	}
	return updateConfigFile(path, func(stored *Config) error {
		normalizeLegacyTierKeys(stored.Agents.Tiers, stored.Agents.ModelAliases)
		effective := effectiveAgentConfig(*stored)
		if stored.Agents.Tiers == nil {
			stored.Agents.Tiers = map[string]AgentTier{}
		}
		if stored.Agents.ModelAliases == nil {
			stored.Agents.ModelAliases = map[string]map[string]AgentTier{}
		}
		if stored.Agents.ModelAliases[tier] == nil {
			stored.Agents.ModelAliases[tier] = map[string]AgentTier{}
		}
		existing := effective.Agents.ModelAliases[tier][key]
		if fallback, ok := effective.Agents.Tiers[tier]; ok {
			if strings.TrimSpace(existing.Backend) == "" && strings.TrimSpace(existing.Model) == "" {
				existing = fallback
			}
		}
		mapping := AgentTier{}
		if !hasBackendInput && !hasModelInput {
			mapping = existing
		}
		if backend != "" {
			mapping.Backend = backend
		}
		if model != "" {
			mapping.Model = model
			if backend == "" {
				mapping.Backend = InferBackend(model)
			}
		}
		if hasEffort {
			mapping.Effort = effort
		} else {
			mapping.Effort = ""
		}
		stored.Agents.ModelAliases[tier][key] = mapping
		return nil
	})
}

func ResolveAgent(opts Options, tier, backend, model string) (string, string, error) {
	return ResolveAgentForHarness(opts, tier, backend, model, "")
}

func ResolveAgentForHarness(opts Options, tier, backend, model, harness string) (string, string, error) {
	backend, model, _, err := ResolveAgentForHarnessConfig(opts, tier, backend, model, harness)
	return backend, model, err
}

func ResolveAgentForHarnessConfig(opts Options, tier, backend, model, harness string) (string, string, string, error) {
	tier = normalizedTier(tier)
	backend = strings.TrimSpace(backend)
	model = strings.TrimSpace(model)
	if alias := ModelAlias(model); alias != "" {
		tier = alias
		model = ""
	}
	if tier == "" {
		tier = "medium"
	}
	if model != "" {
		if backend == "" {
			backend = InferBackend(model)
		}
		if backend == "" {
			backend = "codex"
		}
		return backend, model, "", nil
	}
	cfg, err := LoadAgentTierConfig(opts)
	if err != nil {
		return "", "", "", err
	}
	effort := ""
	if mapping, _, ok := resolveAliasMapping(cfg, tier, backend, harness); ok {
		if useAliasMappingForBackend(backend, mapping) {
			if model == "" {
				model = strings.TrimSpace(mapping.Model)
			}
			if backend == "" {
				backend = strings.TrimSpace(mapping.Backend)
			}
			if backend == "" {
				backend = InferBackend(model)
			}
			effort = strings.TrimSpace(mapping.Effort)
		}
	}
	if backend == "" {
		backend = "codex"
	}
	return backend, model, effort, nil
}

// ResolveAgentTierForHarness resolves a fixed tier's {backend, model, effort}
// under a given harness, applying the same alias-resolution fallback chain
// ResolveAgentForHarnessConfig uses, and reports which aliasResolutionKeys
// bucket answered (resolvedFrom) so a caller can distinguish a harness-local
// hit from a cross-harness fallback without re-deriving the chain itself.
// Unlike ResolveAgentForHarnessConfig (which silently coerces an
// empty/unrecognized tier to "medium" for its existing callers), this
// function rejects an unknown tier outright.
func ResolveAgentTierForHarness(opts Options, tier, harness string) (backend, model, effort, resolvedFrom string, err error) {
	normalized := normalizedTier(tier)
	if normalized == "" {
		return "", "", "", "", fmt.Errorf("tier must be small, medium, large, or xlarge; got %q", tier)
	}
	cfg, err := LoadAgentTierConfig(opts)
	if err != nil {
		return "", "", "", "", err
	}
	mapping, source, ok := resolveAliasMapping(cfg, normalized, "", harness)
	if !ok {
		return "", "", "", "", fmt.Errorf("no configuration found for tier %q", normalized)
	}
	backend = strings.TrimSpace(mapping.Backend)
	model = strings.TrimSpace(mapping.Model)
	effort = strings.TrimSpace(mapping.Effort)
	if backend == "" {
		backend = InferBackend(model)
	}
	return backend, model, effort, source, nil
}

// HarnessTiers is the tiers harness's own bucket sets (a model given), by
// tier, after the builtin < global < project overlay, with no fallback to
// another harness's bucket: a tier the bucket leaves unset is absent.
func HarnessTiers(opts Options, harness string) (map[string]AgentTier, error) {
	cfg, err := LoadAgentTierConfig(opts)
	if err != nil {
		return nil, err
	}
	key := normalizedHarness(harness)
	tiers := map[string]AgentTier{}
	for tier, byHarness := range cfg.Agents.ModelAliases {
		mapping, ok := byHarness[key]
		if !ok || strings.TrimSpace(mapping.Model) == "" {
			continue
		}
		mapping.Backend = strings.TrimSpace(mapping.Backend)
		mapping.Model = strings.TrimSpace(mapping.Model)
		mapping.Effort = strings.TrimSpace(mapping.Effort)
		tiers[tier] = mapping
	}
	return tiers, nil
}

func ModelAlias(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "small", "light":
		return "small"
	case "medium", "core":
		return "medium"
	case "large", "deep":
		return "large"
	case "xlarge":
		return "xlarge"
	default:
		return ""
	}
}

func InferBackend(model string) string {
	value := strings.ToLower(strings.TrimSpace(model))
	switch {
	case value == "":
		return ""
	case strings.HasPrefix(value, "gpt-") || strings.Contains(value, "codex"):
		return "codex"
	case strings.Contains(value, "haiku") || strings.Contains(value, "sonnet") ||
		strings.Contains(value, "opus") || strings.Contains(value, "claude"):
		return "claude"
	default:
		return ""
	}
}

func Path(opts Options) (string, error) {
	root, err := wsstate.CacheRoot(wsstate.Options{CacheHome: opts.CacheHome})
	if err != nil {
		return "", err
	}
	return filepath.Join(root, "config.json"), nil
}

func defaultConfig() Config {
	tiers := map[string]AgentTier{}
	applyDefaultTiers(tiers)
	return Config{
		SchemaVersion: schemaVersion,
		Agents: AgentsConfig{
			Tiers:        tiers,
			ModelAliases: defaultModelAliases(tiers),
		},
	}
}

func applyDefaultTiers(tiers map[string]AgentTier) {
	defaults := map[string]AgentTier{
		"small":  {Backend: "codex", Model: "gpt-6-luna", Effort: "high"},
		"medium": {Backend: "codex", Model: "gpt-6-luna", Effort: "xhigh"},
		"large":  {Backend: "codex", Model: "gpt-6-sol", Effort: "high"},
		"xlarge": {Backend: "codex", Model: "gpt-6-sol", Effort: "xhigh"},
	}
	for tier, mapping := range defaults {
		if _, ok := tiers[tier]; !ok {
			tiers[tier] = mapping
		}
	}
}

func applyDefaultModelAliases(tiers map[string]AgentTier, aliases map[string]map[string]AgentTier) {
	defaults := defaultModelAliases(tiers)
	for alias, byHarness := range defaults {
		if aliases[alias] == nil {
			aliases[alias] = map[string]AgentTier{}
		}
		for harness, mapping := range byHarness {
			if _, ok := aliases[alias][harness]; !ok {
				aliases[alias][harness] = mapping
			}
		}
	}
}

func defaultModelAliases(tiers map[string]AgentTier) map[string]map[string]AgentTier {
	return map[string]map[string]AgentTier{
		"small": {
			"default": tierOrDefault(tiers, "small", AgentTier{Backend: "codex", Model: "gpt-6-luna", Effort: "high"}),
			"codex":   tierOrDefault(tiers, "small", AgentTier{Backend: "codex", Model: "gpt-6-luna", Effort: "high"}),
			"claude":  {Backend: "claude", Model: "haiku", Effort: "high"},
		},
		"medium": {
			"default": tierOrDefault(tiers, "medium", AgentTier{Backend: "codex", Model: "gpt-6-luna", Effort: "xhigh"}),
			"codex":   tierOrDefault(tiers, "medium", AgentTier{Backend: "codex", Model: "gpt-6-luna", Effort: "xhigh"}),
			"claude":  {Backend: "claude", Model: "sonnet", Effort: "high"},
		},
		"large": {
			"default": tierOrDefault(tiers, "large", AgentTier{Backend: "codex", Model: "gpt-6-sol", Effort: "high"}),
			"codex":   tierOrDefault(tiers, "large", AgentTier{Backend: "codex", Model: "gpt-6-sol", Effort: "high"}),
			"claude":  {Backend: "claude", Model: "opus", Effort: "high"},
		},
		"xlarge": {
			"default": tierOrDefault(tiers, "xlarge", AgentTier{Backend: "codex", Model: "gpt-6-sol", Effort: "xhigh"}),
			"codex":   tierOrDefault(tiers, "xlarge", AgentTier{Backend: "codex", Model: "gpt-6-sol", Effort: "xhigh"}),
			"claude":  {Backend: "claude", Model: "opus", Effort: "xhigh"},
		},
	}
}

func tierOrDefault(tiers map[string]AgentTier, tier string, fallback AgentTier) AgentTier {
	if mapping, ok := tiers[tier]; ok {
		return mapping
	}
	return fallback
}

func resolveAliasMapping(cfg Config, alias, backend, harness string) (AgentTier, string, bool) {
	value := alias
	alias = ModelAlias(value)
	if alias == "" {
		alias = normalizedTier(value)
	}
	if alias == "" {
		return AgentTier{}, "", false
	}
	byHarness := cfg.Agents.ModelAliases[alias]
	for _, key := range aliasResolutionKeys(backend, harness) {
		if mapping, ok := byHarness[key]; ok {
			return mapping, key, true
		}
	}
	if mapping, ok := cfg.Agents.Tiers[alias]; ok {
		return mapping, "tiers", true
	}
	return AgentTier{}, "", false
}

func aliasResolutionKeys(backend, harness string) []string {
	keys := []string{}
	if key := normalizedHarness(backend); key != "" {
		keys = append(keys, key)
	}
	if key := normalizedHarness(harness); key != "" {
		keys = append(keys, key)
	}
	keys = append(keys, "default", "codex")
	seen := map[string]bool{}
	result := []string{}
	for _, key := range keys {
		if !seen[key] {
			seen[key] = true
			result = append(result, key)
		}
	}
	return result
}

func normalizedHarness(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "codex":
		return "codex"
	case "claude":
		return "claude"
	case "pi":
		return "pi"
	default:
		return ""
	}
}

func aliasTargetKey(harness string) (string, error) {
	value := strings.ToLower(strings.TrimSpace(harness))
	if value == "" || value == "default" {
		return "default", nil
	}
	if key := normalizedHarness(value); key != "" {
		return key, nil
	}
	return "", fmt.Errorf("harness must be codex, claude, pi, or default")
}

func normalizeOptionalEffort(values ...string) (string, bool, error) {
	if len(values) == 0 {
		return "", false, nil
	}
	value := strings.ToLower(strings.TrimSpace(values[0]))
	if value == "" || value == "none" {
		return "", true, nil
	}
	return value, true, nil
}

func useAliasMappingForBackend(explicitBackend string, mapping AgentTier) bool {
	explicitKey := normalizedHarness(explicitBackend)
	if explicitKey == "" {
		return true
	}
	mappingKey := normalizedHarness(mapping.Backend)
	if mappingKey != "" {
		return mappingKey == explicitKey
	}
	inferredKey := normalizedHarness(InferBackend(mapping.Model))
	if inferredKey == "" {
		return true
	}
	return inferredKey == explicitKey
}

// errConfigUnchanged is returned by an updateConfigFile mutate func to report
// that it changed nothing: the helper then skips the write and returns the
// config as read, with a nil error.
var errConfigUnchanged = errors.New("ws config unchanged")

// updateConfigFile is the single writer for project and global config files.
// It holds the sibling <path>.lock flock across read, mutate, and write, so
// every writer of one file (agents.tier and resolver overrides, in this process
// or another ws-mcp process) serializes against every other; readers stay
// unlocked and see the old or the new file via the temp-write + rename, never a
// torn one. It stamps schema_version on every write and returns the committed
// Config. A missing file reads as Config{}; callers whose no-op must not create
// the directory or lock file check for the file before calling.
func updateConfigFile(path string, mutate func(*Config) error) (Config, error) {
	var cfg Config
	// The lock is a sibling file so it survives the atomic rename of the config.
	err := rewriteLocked(path, path+".lock", func(raw []byte, exists bool) ([]byte, error) {
		if exists {
			if jerr := json.Unmarshal(raw, &cfg); jerr != nil {
				return nil, fmt.Errorf("parse config for update: %w", jerr)
			}
		}
		if err := mutate(&cfg); err != nil {
			return nil, err
		}
		cfg.SchemaVersion = schemaVersion
		payload, err := json.MarshalIndent(cfg, "", "  ")
		if err != nil {
			return nil, fmt.Errorf("encode config: %w", err)
		}
		return append(payload, '\n'), nil
	})
	if errors.Is(err, errConfigUnchanged) {
		return cfg, nil
	}
	if err != nil {
		return Config{}, err
	}
	return cfg, nil
}

// rewriteLocked holds lockPath's flock across reading path, transform, and an
// atomic temp-write + rename of transform's payload, so every writer of one
// file serializes against every other while unlocked readers see the old or
// the new file, never a torn one. A missing file reaches transform with
// exists=false. A transform error (errConfigUnchanged included) skips the write
// and is returned unchanged.
func rewriteLocked(path, lockPath string, transform func(raw []byte, exists bool) ([]byte, error)) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return fmt.Errorf("create config dir: %w", err)
	}
	if err := os.MkdirAll(filepath.Dir(lockPath), 0o755); err != nil {
		return fmt.Errorf("create config lock dir: %w", err)
	}
	fl := flock.New(lockPath)
	ctx, cancel := context.WithTimeout(context.Background(), lockTimeout)
	defer cancel()
	locked, err := fl.TryLockContext(ctx, 50*time.Millisecond)
	if err != nil {
		return fmt.Errorf("acquire config lock: %w", err)
	}
	if !locked {
		return fmt.Errorf("timed out waiting for config file lock: %s", lockPath)
	}
	defer fl.Unlock() //nolint:errcheck

	raw, err := os.ReadFile(path)
	if err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("read config for update: %w", err)
	}
	payload, err := transform(raw, err == nil)
	if err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), filepath.Base(path)+"-*.tmp")
	if err != nil {
		return fmt.Errorf("create temp config: %w", err)
	}
	tmpName := tmp.Name()
	fail := func(format string, err error) error {
		tmp.Close()
		os.Remove(tmpName)
		return fmt.Errorf(format, err)
	}
	// CreateTemp opens 0600: keep an existing file's mode, and give a new file
	// the 0644 the config file has always been created with.
	mode := os.FileMode(0o644)
	if info, err := os.Stat(path); err == nil {
		mode = info.Mode().Perm()
	}
	if err := tmp.Chmod(mode); err != nil {
		return fail("chmod temp config: %w", err)
	}
	if _, err := tmp.Write(payload); err != nil {
		return fail("write temp config: %w", err)
	}
	if err := tmp.Close(); err != nil {
		os.Remove(tmpName)
		return fmt.Errorf("close temp config: %w", err)
	}
	if err := replaceConfigFile(tmpName, path); err != nil {
		os.Remove(tmpName)
		return fmt.Errorf("atomic rename config: %w", err)
	}
	return nil
}

// configFileExists reports whether path exists, for no-op callers that must not
// create the config directory or lock file.
func configFileExists(path string) bool {
	_, err := os.Stat(path)
	return !os.IsNotExist(err)
}

// agentsConfigPath returns the project or global config file path.
func agentsConfigPath(opts Options, global bool) (string, error) {
	if global {
		return GlobalPath(opts)
	}
	return Path(opts)
}

func normalizedTier(tier string) string {
	switch strings.ToLower(strings.TrimSpace(tier)) {
	case "small", "light", "haiku":
		return "small"
	case "medium", "core", "sonnet":
		return "medium"
	case "large", "deep", "opus":
		return "large"
	case "xlarge":
		return "xlarge"
	default:
		return ""
	}
}

// NormalizedTier exposes normalizedTier's alias-folding to callers outside this
// package: any accepted spelling ("Large", "opus", "deep", ...) collapses to
// its first-class taxonomy value ("small"/"medium"/"large"/"xlarge"); an
// unknown/unrecognized tier returns "". Callers that already validated the
// tier via ResolveAgentTierForHarness use this to recover the canonical form
// for a return channel (e.g. a recommended-tier line) that must stay in
// first-class vocabulary regardless of which accepted alias the caller typed.
func NormalizedTier(tier string) string {
	return normalizedTier(tier)
}
