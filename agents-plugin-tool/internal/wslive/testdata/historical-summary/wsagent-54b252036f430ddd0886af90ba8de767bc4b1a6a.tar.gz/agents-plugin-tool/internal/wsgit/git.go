package wsgit

import (
	"bytes"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const (
	DiffModeFull     = "full"
	DiffModeStat     = "stat"
	DiffModeNameOnly = "name_only"
)

type Runner interface {
	RunGit(ctx context.Context, root string, args ...string) ([]byte, error)
}

// ExecRunner runs the user's git. Environ, when set, is the base
// environment of every run (the caller process's, for a server the
// dashboard daemon hosts for another process); nil means this process's.
// Env, when set, is appended to it (a caller that must pin a GIT_* variable,
// such as a ledger that forbids lazy fetches, sets it here).
type ExecRunner struct {
	Environ func() []string
	Env     []string
}

func (r ExecRunner) RunGit(ctx context.Context, root string, args ...string) ([]byte, error) {
	argv := append([]string{"-C", root}, args...)
	var cmd *exec.Cmd
	if r.Environ != nil {
		// The git binary comes from the caller's PATH too (see LookPathEnv);
		// a PATH without git fails the run rather than running this
		// process's git.
		base := r.Environ()
		bin, lookErr := LookPathEnv("git", base)
		cmd = exec.CommandContext(ctx, bin, argv...)
		if lookErr != nil {
			cmd.Err = lookErr
		}
		cmd.Env = append(base, r.Env...)
	} else {
		cmd = exec.CommandContext(ctx, "git", argv...)
		if len(r.Env) > 0 {
			cmd.Env = append(os.Environ(), r.Env...)
		}
	}
	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("git %s: %w: %s", strings.Join(args, " "), err, strings.TrimSpace(string(out)))
	}
	return out, nil
}

// Verifier is an optional structural hook Client.Commit invokes after staging
// and status validation, before the commit lands, so a caller can veto a
// commit whose staged paths fail a domain-specific check (e.g. ticket-file
// well-formedness). wsgit intentionally stays free of an internal/wsdoc
// import here — the dependency runs wsdoc -> wsgit and must not cycle back;
// a caller that needs ticket
// verification wires wsdoc.TicketVerify in through an adapter that produces
// this two-return-value shape, mirroring how Runner keeps wsgit free of an
// os/exec-specific dependency at the type level. The first return value
// carries non-blocking advisory text lines (pre-formatted, text-mode,
// order-preserving, no path/guardrail attribution baked into the type) that
// Client.Commit threads into CommitResult.Advisories without affecting the
// commit outcome. The second return value is the veto: a non-nil error stops
// Client.Commit before the commit lands, and in that case the advisories
// returned alongside it are discarded — a veto has nothing to advise on.
type Verifier func(root string, paths []string) ([]string, error)

type Client struct {
	Runner   Runner
	Verifier Verifier
	// MintID mints a follow-up id; nil uses wskey.Generate. Tests inject a
	// deterministic generator.
	MintID func() (string, error)
}

func NewClient() Client { return Client{Runner: ExecRunner{}} }

// CurrentUserEmail returns the repository's configured git user.email with
// surrounding whitespace trimmed (original case preserved for display). It
// returns "" when git reports no identity — user.email unset, or a CI/bot with
// none — because any error is folded into "": an ownership gate that cannot
// read an identity must degrade to assign-any, never surface a git error to a
// caller that only asked to list tickets. A nil runner falls back to
// ExecRunner, matching Client.runner.
func CurrentUserEmail(ctx context.Context, runner Runner, root string) string {
	if runner == nil {
		runner = ExecRunner{}
	}
	out, err := runner.RunGit(ctx, root, "config", "user.email")
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(out))
}

func (c Client) runner() Runner {
	if c.Runner == nil {
		return ExecRunner{}
	}
	return c.Runner
}

func (c Client) verifier() Verifier {
	if c.Verifier == nil {
		return func(string, []string) ([]string, error) { return nil, nil }
	}
	return c.Verifier
}

type StatusResult struct {
	Branch       BranchStatus `json:"branch"`
	Clean        bool         `json:"clean"`
	ChangedFiles []FileStatus `json:"changed_files"`
}

type BranchStatus struct {
	Head     string `json:"head,omitempty"`
	OID      string `json:"oid,omitempty"`
	Upstream string `json:"upstream,omitempty"`
	Ahead    int    `json:"ahead,omitempty"`
	Behind   int    `json:"behind,omitempty"`
}

// BranchSync reads root's branch and its standing against its upstream with
// cheap ref reads only (rev-parse, symbolic-ref, and rev-list, never a working-tree scan or a
// fetch, so Behind reflects the last fetch). Head is the branch name, or ""
// with OID set to the short commit id on a detached HEAD. Upstream is empty
// when the branch tracks none. ok is false when root is not a repository or
// HEAD names no commit yet.
func BranchSync(ctx context.Context, runner Runner, root string) (status BranchStatus, ok bool) {
	if runner == nil {
		runner = ExecRunner{}
	}
	short, err := runner.RunGit(ctx, root, "rev-parse", "--short", "HEAD")
	if err != nil {
		return BranchStatus{}, false
	}
	oid := strings.TrimSpace(string(short))
	if oid == "" {
		return BranchStatus{}, false
	}
	// The full ref name, trimmed here: both `rev-parse --abbrev-ref HEAD` and
	// `symbolic-ref --short HEAD` print "heads/main" when a tag shares the
	// branch's name. A detached HEAD fails symbolic-ref.
	ref, err := runner.RunGit(ctx, root, "symbolic-ref", "-q", "HEAD")
	head := strings.TrimPrefix(strings.TrimSpace(string(ref)), "refs/heads/")
	if err != nil || head == "" {
		return BranchStatus{OID: oid}, true
	}
	status.Head = head
	up, err := runner.RunGit(ctx, root, "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{upstream}")
	if err != nil {
		return status, true
	}
	status.Upstream = strings.TrimSpace(string(up))
	counts, err := runner.RunGit(ctx, root, "rev-list", "--left-right", "--count", "HEAD...@{upstream}")
	if err != nil {
		return status, true
	}
	if fields := strings.Fields(string(counts)); len(fields) == 2 {
		status.Ahead, _ = strconv.Atoi(fields[0])
		status.Behind, _ = strconv.Atoi(fields[1])
	}
	return status, true
}

// TreeCounts counts a working tree's entries by kind. A file changed in both
// the index and the working tree counts as Staged and as Modified; an
// unmerged path counts as Modified alone; an untracked directory counts once.
type TreeCounts struct {
	Modified  int
	Staged    int
	Untracked int
}

// WorkingTreeCounts reads root's working-tree standing with one `git status
// --porcelain`, untracked files included (one entry per untracked directory,
// whatever the user's status.showUntrackedFiles says) and ignored ones not.
// It takes no optional lock, so a periodic read never makes a concurrent git
// command of the user's fail on index.lock. ok is false when git fails (not a
// repository, a canceled or timed-out read).
func WorkingTreeCounts(ctx context.Context, runner Runner, root string) (counts TreeCounts, ok bool) {
	if runner == nil {
		runner = ExecRunner{}
	}
	out, err := runner.RunGit(ctx, root, "--no-optional-locks", "status", "--porcelain", "--untracked-files=normal")
	if err != nil {
		return TreeCounts{}, false
	}
	for _, line := range strings.Split(string(out), "\n") {
		if len(line) < 2 {
			continue
		}
		x, y := line[0], line[1]
		switch {
		case x == '?' && y == '?':
			counts.Untracked++
		case x == '!' && y == '!':
		case x == 'U' || y == 'U' || (x == 'A' && y == 'A') || (x == 'D' && y == 'D'):
			counts.Modified++
		default:
			if x != ' ' {
				counts.Staged++
			}
			if y != ' ' {
				counts.Modified++
			}
		}
	}
	return counts, true
}

type FileStatus struct {
	Path           string `json:"path"`
	OldPath        string `json:"old_path,omitempty"`
	Status         string `json:"status"`
	IndexStatus    string `json:"index_status,omitempty"`
	WorktreeStatus string `json:"worktree_status,omitempty"`
}

func (c Client) Status(ctx context.Context, root string) (StatusResult, error) {
	out, err := c.runner().RunGit(ctx, root, StatusArgs()...)
	if err != nil {
		return StatusResult{}, err
	}
	return ParseStatus(out), nil
}

func StatusArgs() []string {
	return []string{"status", "--porcelain=v2", "--branch"}
}

func ParseStatus(out []byte) StatusResult {
	result := StatusResult{Clean: true}
	for _, line := range strings.Split(strings.TrimRight(string(out), "\n"), "\n") {
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "# ") {
			parseBranchLine(&result.Branch, strings.TrimPrefix(line, "# "))
			continue
		}
		if file, ok := parseFileLine(line); ok {
			result.ChangedFiles = append(result.ChangedFiles, file)
		}
	}
	result.Clean = len(result.ChangedFiles) == 0
	return result
}

func parseBranchLine(branch *BranchStatus, line string) {
	key, value, ok := strings.Cut(line, " ")
	if !ok {
		return
	}
	switch key {
	case "branch.oid":
		branch.OID = value
	case "branch.head":
		branch.Head = value
	case "branch.upstream":
		branch.Upstream = value
	case "branch.ab":
		fields := strings.Fields(value)
		if len(fields) == 2 {
			branch.Ahead = parseAheadBehind(fields[0], "+")
			branch.Behind = parseAheadBehind(fields[1], "-")
		}
	}
}

func parseAheadBehind(value, prefix string) int {
	trimmed := strings.TrimPrefix(value, prefix)
	parsed, err := strconv.Atoi(trimmed)
	if err != nil {
		return 0
	}
	return parsed
}

func parseFileLine(line string) (FileStatus, bool) {
	typeCode, rest, ok := strings.Cut(line, " ")
	if !ok {
		return FileStatus{}, false
	}
	switch typeCode {
	case "1":
		fields := strings.SplitN(rest, " ", 8)
		if len(fields) < 8 {
			return FileStatus{}, false
		}
		return FileStatus{Path: cleanPath(fields[7]), Status: fields[0], IndexStatus: string(fields[0][0]), WorktreeStatus: string(fields[0][1])}, true
	case "2":
		fields := strings.SplitN(rest, " ", 9)
		if len(fields) < 9 {
			return FileStatus{}, false
		}
		path := fields[8]
		oldPath := ""
		if current, previous, ok := strings.Cut(path, "\t"); ok {
			path = current
			oldPath = previous
		}
		return FileStatus{Path: cleanPath(path), OldPath: cleanPath(oldPath), Status: fields[0], IndexStatus: string(fields[0][0]), WorktreeStatus: string(fields[0][1])}, true
	case "u":
		fields := strings.SplitN(rest, " ", 10)
		if len(fields) < 10 {
			return FileStatus{}, false
		}
		return FileStatus{Path: cleanPath(fields[9]), Status: fields[0], IndexStatus: string(fields[0][0]), WorktreeStatus: string(fields[0][1])}, true
	case "?", "!":
		return FileStatus{Path: cleanPath(rest), Status: typeCode}, true
	default:
		return FileStatus{}, false
	}
}

func cleanPath(path string) string {
	if path == "" {
		return ""
	}
	unquoted, err := strconv.Unquote(path)
	if err == nil {
		return unquoted
	}
	return path
}

type DiffOptions struct {
	Range string
	Paths []string
	Mode  string
}

type DiffResult struct {
	Mode   string   `json:"mode"`
	Range  string   `json:"range,omitempty"`
	Paths  []string `json:"paths,omitempty"`
	Output string   `json:"output"`
}

func (c Client) Diff(ctx context.Context, root string, opts DiffOptions) (DiffResult, error) {
	args, mode, err := DiffArgs(opts)
	if err != nil {
		return DiffResult{}, err
	}
	out, err := c.runner().RunGit(ctx, root, args...)
	if err != nil {
		return DiffResult{}, err
	}
	output := string(out)
	if opts.Range == "" {
		untracked, err := c.untrackedFiles(ctx, root, opts.Paths)
		if err != nil {
			return DiffResult{}, err
		}
		output = appendUntrackedDiffOutput(output, mode, untracked)
	}
	return DiffResult{Mode: mode, Range: opts.Range, Paths: opts.Paths, Output: output}, nil
}

func (c Client) untrackedFiles(ctx context.Context, root string, paths []string) ([]string, error) {
	args := []string{"ls-files", "--others", "--exclude-standard", "-z"}
	if len(paths) > 0 {
		args = append(args, "--")
		args = append(args, paths...)
	}
	out, err := c.runner().RunGit(ctx, root, args...)
	if err != nil {
		return nil, err
	}
	return parseNULTerminatedPaths(out), nil
}

func DiffArgs(opts DiffOptions) ([]string, string, error) {
	mode := opts.Mode
	if mode == "" {
		mode = DiffModeStat
	}
	args := []string{"diff"}
	switch mode {
	case DiffModeFull:
	case DiffModeStat:
		args = append(args, "--stat")
	case DiffModeNameOnly:
		args = append(args, "--name-only")
	default:
		return nil, "", fmt.Errorf("unsupported diff mode %q", opts.Mode)
	}
	if opts.Range != "" {
		if err := validateRevision("range", opts.Range); err != nil {
			return nil, "", err
		}
		args = append(args, opts.Range)
	}
	if len(opts.Paths) > 0 {
		args = append(args, "--")
		args = append(args, opts.Paths...)
	}
	return args, mode, nil
}

func validateRevision(name, value string) error {
	if strings.HasPrefix(value, "-") {
		return fmt.Errorf("%s must be a revision or range, not a git option", name)
	}
	return nil
}

func appendUntrackedDiffOutput(output, mode string, untracked []string) string {
	if len(untracked) == 0 {
		return output
	}
	sort.Strings(untracked)
	var b strings.Builder
	b.WriteString(output)
	if b.Len() > 0 && !strings.HasSuffix(output, "\n") {
		b.WriteString("\n")
	}
	switch mode {
	case DiffModeNameOnly:
		for _, path := range untracked {
			b.WriteString(path)
			b.WriteString("\n")
		}
	default:
		if b.Len() > 0 {
			b.WriteString("\n")
		}
		b.WriteString("Untracked files:\n")
		for _, path := range untracked {
			b.WriteString("  ")
			b.WriteString(path)
			b.WriteString("\n")
		}
	}
	return b.String()
}

func parseNULTerminatedPaths(out []byte) []string {
	if len(out) == 0 {
		return nil
	}
	parts := bytes.Split(out, []byte{0})
	paths := make([]string, 0, len(parts))
	for _, part := range parts {
		if len(part) == 0 {
			continue
		}
		paths = append(paths, string(part))
	}
	return paths
}

type LogOptions struct {
	Range       string
	Limit       int
	IncludeBody bool
}

type Commit struct {
	Hash    string `json:"hash"`
	Subject string `json:"subject"`
	Author  string `json:"author"`
	Date    string `json:"date"`
	Body    string `json:"body,omitempty"`
}

type LogResult struct {
	Range       string   `json:"range,omitempty"`
	Limit       int      `json:"limit"`
	IncludeBody bool     `json:"include_body"`
	Commits     []Commit `json:"commits"`
}

func (c Client) Log(ctx context.Context, root string, opts LogOptions) (LogResult, error) {
	args, limit, err := LogArgs(opts)
	if err != nil {
		return LogResult{}, err
	}
	out, err := c.runner().RunGit(ctx, root, args...)
	if err != nil {
		return LogResult{}, err
	}
	return LogResult{Range: opts.Range, Limit: limit, IncludeBody: opts.IncludeBody, Commits: ParseLog(out, opts.IncludeBody)}, nil
}

func LogArgs(opts LogOptions) ([]string, int, error) {
	limit := opts.Limit
	if limit <= 0 {
		limit = 20
	}
	if limit > 100 {
		limit = 100
	}
	args := []string{"log", "-n", strconv.Itoa(limit), "--date=iso-strict", "--pretty=format:%H%x1f%an%x1f%aI%x1f%s%x1f%b%x1e"}
	if opts.Range != "" {
		if err := validateRevision("range", opts.Range); err != nil {
			return nil, 0, err
		}
		args = append(args, opts.Range)
	}
	return args, limit, nil
}

func ParseLog(out []byte, includeBody bool) []Commit {
	trimmed := bytes.TrimRight(out, "\x1e\n")
	if len(trimmed) == 0 {
		return nil
	}
	records := bytes.Split(trimmed, []byte("\x1e"))
	commits := make([]Commit, 0, len(records))
	for _, record := range records {
		parts := strings.SplitN(strings.TrimLeft(string(record), "\n"), "\x1f", 5)
		if len(parts) < 5 {
			continue
		}
		commit := Commit{Hash: parts[0], Author: parts[1], Date: parts[2], Subject: parts[3]}
		if includeBody {
			commit.Body = strings.TrimSpace(parts[4])
		}
		commits = append(commits, commit)
	}
	return commits
}

type MergeBaseResult struct {
	Base      string `json:"base"`
	Head      string `json:"head"`
	MergeBase string `json:"merge_base"`
}

func (c Client) MergeBase(ctx context.Context, root, base, head string) (MergeBaseResult, error) {
	if base == "" || head == "" {
		return MergeBaseResult{}, fmt.Errorf("base and head are required")
	}
	if err := validateRevision("base", base); err != nil {
		return MergeBaseResult{}, err
	}
	if err := validateRevision("head", head); err != nil {
		return MergeBaseResult{}, err
	}
	out, err := c.runner().RunGit(ctx, root, MergeBaseArgs(base, head)...)
	if err != nil {
		return MergeBaseResult{}, err
	}
	return MergeBaseResult{Base: base, Head: head, MergeBase: strings.TrimSpace(string(out))}, nil
}

func MergeBaseArgs(base, head string) []string {
	return []string{"merge-base", base, head}
}

type CommitOptions struct {
	Paths          []string `json:"paths"`
	Title          string   `json:"title"`
	Description    string   `json:"description,omitempty"`
	AIContext      []string `json:"ai_context"`
	UpdatedTickets []string `json:"updated_tickets,omitempty"`
	// Followups are written under "## Follow-ups", one minted id each. The
	// root-lead authorization gate is the caller's (internal/mcp owns sessions).
	Followups []Followup `json:"followups,omitempty"`
	// Resolves are follow-up ids written under "## Resolves".
	Resolves []string `json:"resolves,omitempty"`
	// ExpectedBranch is the branch the caller believes it is checked out on.
	// Commit resolves the actual current branch and refuses (no mutation) when
	// they disagree or when HEAD is detached — the guard against a parallel
	// session switching the shared worktree out from under the caller. It is
	// required: an empty value is rejected by normalizeCommitOptions so a caller
	// that does not know its branch cannot form the call at all. The value must
	// originate from the caller's remembered context, never a fresh HEAD read
	// (which would always match and check nothing).
	ExpectedBranch string `json:"expected_branch"`
	// SparseScopeActive is a caller-computed signal, never a client-supplied
	// field (json:"-"): true only when the caller has already determined a
	// sparse-checkout scope is active for root (see wsdoc.SparseCheckoutActive).
	// It makes stagingCommandsForCommit's `add` staging use `git add --sparse`
	// so an off-topic capture (e.g. a new idea/ ticket) can be staged and then
	// self-hide, instead of failing with "did not match any files". The zero
	// value (false) reproduces today's staging shape byte-for-byte, so every
	// existing caller and test is unaffected.
	SparseScopeActive bool `json:"-"`
}

type CommitResult struct {
	Hash          string         `json:"hash"`
	Paths         []string       `json:"paths"`
	Title         string         `json:"title"`
	TicketChanges []TicketChange `json:"ticket_changes,omitempty"`
	// Followups echoes the recorded follow-ups with their minted ids, in the
	// input order of CommitOptions.Followups.
	Followups []Followup `json:"followups,omitempty"`
	// Warnings carries non-blocking caller-attached notices (for example a
	// resolve of an unknown or already-resolved follow-up id).
	Warnings []string `json:"warnings,omitempty"`
	// Advisories carries non-blocking verifier text lines. Text-mode only;
	// see {#260626-git-commit-todo-reinjection} precedent — never serialized
	// to JSON.
	Advisories []string `json:"-"`
}

type TicketChange struct {
	Stem          string `json:"stem"`
	Path          string `json:"path"`
	OldPath       string `json:"old_path,omitempty"`
	FromStatus    string `json:"from_status,omitempty"`
	ToStatus      string `json:"to_status,omitempty"`
	ResultAdded   bool   `json:"result_added,omitempty"`
	ResultHeading string `json:"result_heading,omitempty"`
}

func (c Client) Commit(ctx context.Context, root string, opts CommitOptions) (CommitResult, error) {
	opts, err := normalizeCommitOptions(opts)
	if err != nil {
		return CommitResult{}, err
	}
	for _, path := range opts.Paths {
		if err := validateCommitPath(root, path); err != nil {
			return CommitResult{}, err
		}
	}
	runner := c.runner()
	// Branch guard first, before any staging mutation: resolve the actual
	// current branch and refuse if it disagrees with the caller's believed
	// branch (or if HEAD is detached). This is the whole point of the required
	// expected_branch field — a commit that lands on the wrong branch because a
	// parallel session switched the shared worktree is silent and hard to undo,
	// so it must be caught before the commit, not after.
	actualBranch := currentBranch(ctx, runner, root)
	if actualBranch == "" {
		return CommitResult{}, fmt.Errorf("git.commit refused: HEAD is detached, so there is no current branch to confirm against believed branch %q; a commit under a detached HEAD in a shared worktree is exactly the state this guard exists to stop — verify whether you should be committing here", opts.ExpectedBranch)
	}
	if actualBranch != opts.ExpectedBranch {
		refusal := fmt.Sprintf("git.commit refused: believed branch %q does not match the actual checkout %q (a parallel session may have switched this worktree); verify whether you should be committing here before retrying (believed: %s / actual: %s)", opts.ExpectedBranch, actualBranch, opts.ExpectedBranch, actualBranch)
		// When the actual checkout is a worker's impl/ branch, name the sanctioned
		// escape hatch so the reader does not reflexively `git switch` this shared
		// worktree onto their own branch.
		if strings.HasPrefix(actualBranch, "impl/") {
			base := "<the branch this worker was spawned from>"
			if parent := implBranchParent(actualBranch); parent != "" {
				base = fmt.Sprintf("%q", parent)
			}
			refusal += fmt.Sprintf("; the actual checkout is a worker's impl/ branch — housekeeping meanwhile goes through worktree.acquire(base: %s, profile: \"housekeeping\") and its returned key, not this root", base)
		}
		return CommitResult{}, fmt.Errorf("%s", refusal)
	}
	preStatusOut, err := runner.RunGit(ctx, root, StatusArgs()...)
	if err != nil {
		return CommitResult{}, err
	}
	preStatus := ParseStatus(preStatusOut)
	opts.Paths = expandCommitPathsForTicketMoves(preStatus, opts.Paths)
	for _, args := range stagingCommandsForCommit(opts.Paths, preStatus, opts.SparseScopeActive) {
		if _, err := runner.RunGit(ctx, root, args...); err != nil {
			return CommitResult{}, err
		}
	}
	statusOut, err := runner.RunGit(ctx, root, StatusArgs()...)
	if err != nil {
		return CommitResult{}, err
	}
	status := ParseStatus(statusOut)
	if err := validateCommitStatus(status, opts.Paths); err != nil {
		return CommitResult{}, err
	}
	// Verify runs after staging (so a blocked commit leaves the invalid state
	// staged for the caller to fix and re-verify, not reverted) and before the
	// commit message/`git commit` itself, matching validateCommitStatus's
	// gate position. The verifier only ever sees the delete-side-filtered
	// paths (see filterIndexDeleteSidePaths): a staged ticket rename or
	// deletion leaves its old path unreadable, and wsdoc.TicketVerify's
	// file-exists guardrail would otherwise reject a legitimate status
	// transition. validateCommitStatus above still sees the full expanded
	// opts.Paths, since narrowing what it sees would reopen the
	// unrelated-path guard for the delete-side path itself. See
	// {#260720-wsdoc-commit-boundary} for why this stays a wsgit-side filter
	// rather than a wsdoc.TicketVerify change.
	var advisories []string
	if verifyPaths := filterIndexDeleteSidePaths(status, opts.Paths); len(verifyPaths) > 0 {
		verifyAdvisories, err := c.verifier()(root, verifyPaths)
		if err != nil {
			// A veto (non-nil error) stops Commit here and returns the zero
			// CommitResult, so verifyAdvisories is intentionally discarded:
			// a vetoed commit has nothing to advise on.
			return CommitResult{}, err
		}
		advisories = verifyAdvisories
	}
	ticketChanges := detectTicketChanges(ctx, runner, root)
	if len(opts.UpdatedTickets) == 0 {
		opts.UpdatedTickets = ticketChangeSummaries(ticketChanges)
	}
	if err := mintFollowupIDs(opts.Followups, c.MintID); err != nil {
		return CommitResult{}, err
	}
	message := CommitMessage(opts)
	if _, err := runner.RunGit(ctx, root, "commit", "-m", message); err != nil {
		return CommitResult{}, err
	}
	hashOut, err := runner.RunGit(ctx, root, "rev-parse", "HEAD")
	if err != nil {
		return CommitResult{}, err
	}
	return CommitResult{Hash: strings.TrimSpace(string(hashOut)), Paths: opts.Paths, Title: opts.Title, TicketChanges: ticketChanges, Followups: opts.Followups, Advisories: advisories}, nil
}

// currentBranch resolves the short name of the branch HEAD points at, mirroring
// git.merge's resolution (`git symbolic-ref --quiet --short HEAD`). --quiet makes
// a detached HEAD exit non-zero with empty output rather than an error message,
// so any resolution failure is reported as an empty name: the caller then
// refuses (fail-closed) instead of committing unguarded.
func currentBranch(ctx context.Context, runner Runner, root string) string {
	out, err := runner.RunGit(ctx, root, "symbolic-ref", "--quiet", "--short", "HEAD")
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(out))
}

// implBranchParent returns the parent (merge root) segment of an
// "impl/<parent>/<stem>" branch, or "" for a rootless "impl/<stem>" or a
// non-impl branch. It is the wsgit-local twin of internal/mcp's
// parseImplBranchRoot: wsgit must not import internal/mcp (the dependency runs
// mcp -> wsgit), so the tiny last-slash split is duplicated rather than shared.
func implBranchParent(branch string) string {
	const prefix = "impl/"
	if !strings.HasPrefix(branch, prefix) {
		return ""
	}
	rest := strings.TrimPrefix(branch, prefix)
	idx := strings.LastIndex(rest, "/")
	if idx <= 0 {
		return ""
	}
	return rest[:idx]
}

func normalizeCommitOptions(opts CommitOptions) (CommitOptions, error) {
	rawAIContext := opts.AIContext
	opts.Title = strings.TrimSpace(opts.Title)
	opts.Description = strings.TrimSpace(opts.Description)
	opts.AIContext = trimStrings(opts.AIContext)
	opts.UpdatedTickets = trimStrings(opts.UpdatedTickets)
	opts.ExpectedBranch = strings.TrimSpace(opts.ExpectedBranch)
	followups, err := normalizeFollowups(opts.Followups)
	if err != nil {
		return CommitOptions{}, err
	}
	opts.Followups = followups
	resolves, err := normalizeResolves(opts.Resolves)
	if err != nil {
		return CommitOptions{}, err
	}
	opts.Resolves = resolves
	if opts.Title == "" {
		return CommitOptions{}, fmt.Errorf("title is required")
	}
	if strings.ContainsAny(opts.Title, "\r\n") {
		return CommitOptions{}, fmt.Errorf("title must be a single line")
	}
	if len(opts.AIContext) == 0 {
		switch {
		case rawAIContext == nil:
			return CommitOptions{}, fmt.Errorf("ai_context is required: no ai_context field was received")
		case len(rawAIContext) == 0:
			return CommitOptions{}, fmt.Errorf("ai_context requires at least one entry: received an empty array")
		default:
			plural := ""
			if len(rawAIContext) != 1 {
				plural = "ies"
			} else {
				plural = "y"
			}
			return CommitOptions{}, fmt.Errorf("ai_context requires at least one non-blank entry: received %d entr%s, all blank", len(rawAIContext), plural)
		}
	}
	if opts.ExpectedBranch == "" {
		return CommitOptions{}, fmt.Errorf("expected_branch is required: assert the branch you believe you are on so the commit is refused if the worktree was switched out from under you; do not read HEAD just to fill this — if you do not know it, verify whether you should be committing here at all")
	}
	paths := trimStrings(opts.Paths)
	if len(paths) == 0 {
		return CommitOptions{}, fmt.Errorf("paths requires at least one path")
	}
	opts.Paths = paths
	return opts, nil
}

// sparseActive threads the caller-computed SparseScopeActive signal into the
// `add` command only. The `rm --cached` branch never gets `--sparse`:
// deletedPathsUnderCommitRoot reads only the pre-staging `git status`, which
// never reports a tracked, skip-worktree, on-disk-absent, unmodified path at
// all (skip-worktree suppresses the worktree-vs-index comparison entirely),
// so that branch can never be asked to stage a merely-hidden path as deleted
// — `--sparse` would be scope creep there, not a guardrail.
func stagingCommandsForCommit(paths []string, status StatusResult, sparseActive bool) [][]string {
	addPaths := []string{}
	rmPaths := []string{}
	seen := map[string]bool{}
	for _, path := range paths {
		deletedPaths := deletedPathsUnderCommitRoot(status, path)
		if len(deletedPaths) > 0 && !commitRootHasAddableStatus(status, path) {
			for _, deletedPath := range deletedPaths {
				if !seen["rm:"+deletedPath] {
					rmPaths = append(rmPaths, deletedPath)
					seen["rm:"+deletedPath] = true
				}
			}
			continue
		}
		if !seen["add:"+path] {
			addPaths = append(addPaths, path)
			seen["add:"+path] = true
		}
	}
	commands := [][]string{}
	if len(addPaths) > 0 {
		addArgs := []string{"add", "-A"}
		if sparseActive {
			addArgs = append(addArgs, "--sparse")
		}
		addArgs = append(addArgs, "--")
		commands = append(commands, append(addArgs, addPaths...))
	}
	if len(rmPaths) > 0 {
		commands = append(commands, append([]string{"rm", "--cached", "--ignore-unmatch", "--"}, rmPaths...))
	}
	return commands
}

func deletedPathsUnderCommitRoot(status StatusResult, root string) []string {
	root = filepath.ToSlash(filepath.Clean(root))
	seen := map[string]bool{}
	var deleted []string
	for _, file := range status.ChangedFiles {
		if file.WorktreeStatus == "D" || file.IndexStatus == "D" {
			path := filepath.ToSlash(filepath.Clean(file.Path))
			if pathInCommitSet(path, []string{root}) && !seen[path] {
				deleted = append(deleted, path)
				seen[path] = true
			}
		}
		if file.OldPath != "" && (file.WorktreeStatus == "D" || file.IndexStatus == "D" || strings.HasPrefix(file.Status, "R")) {
			path := filepath.ToSlash(filepath.Clean(file.OldPath))
			if pathInCommitSet(path, []string{root}) && !seen[path] {
				deleted = append(deleted, path)
				seen[path] = true
			}
		}
	}
	return deleted
}

func commitRootHasAddableStatus(status StatusResult, root string) bool {
	root = filepath.ToSlash(filepath.Clean(root))
	for _, file := range status.ChangedFiles {
		path := filepath.ToSlash(filepath.Clean(file.Path))
		if !pathInCommitSet(path, []string{root}) {
			continue
		}
		if file.Status == "?" || file.Status == "!" {
			return true
		}
		if file.WorktreeStatus != "D" && file.IndexStatus != "D" {
			return true
		}
	}
	return false
}

// validateCommitPath refuses a path git.commit will not stage. The relative
// and inside-the-repository refusals name root, the directory every path
// resolves against, so a caller whose shell runs in another checkout can tell
// which checkout its session is bound to; an absolute path under root also
// gets its relative spelling. Absolute paths stay refused, never rebased.
func validateCommitPath(root, path string) error {
	if path == "" {
		return fmt.Errorf("paths may not contain empty entries")
	}
	if strings.HasPrefix(path, "-") {
		return fmt.Errorf("path %q must not start with '-'", path)
	}
	if filepath.IsAbs(path) || strings.HasPrefix(path, "/") {
		msg := fmt.Sprintf("path %q must be relative to the commit root %s, which every path resolves against", path, root)
		if rel, err := filepath.Rel(root, path); err == nil && rel != "." && rel != ".." && !strings.HasPrefix(filepath.ToSlash(rel), "../") {
			msg += fmt.Sprintf("; pass %q", filepath.ToSlash(rel))
		}
		return fmt.Errorf("%s", msg)
	}
	cleaned := filepath.Clean(path)
	if cleaned == "." || cleaned == ".." || strings.HasPrefix(cleaned, ".."+string(filepath.Separator)) || strings.HasPrefix(filepath.ToSlash(cleaned), "../") {
		return fmt.Errorf("path %q must stay inside the commit root %s, which every path resolves against", path, root)
	}
	return nil
}

func validateCommitStatus(status StatusResult, paths []string) error {
	staged := 0
	for _, file := range status.ChangedFiles {
		if strings.HasPrefix(file.Status, "U") {
			return fmt.Errorf("cannot commit while unmerged path %q is present", file.Path)
		}
		if file.IndexStatus == "" || file.IndexStatus == "." {
			continue
		}
		if !pathInCommitSet(file.Path, paths) && (file.OldPath == "" || !pathInCommitSet(file.OldPath, paths)) {
			return fmt.Errorf("refusing to commit unrelated staged path %q", file.Path)
		}
		staged++
	}
	if staged == 0 {
		return fmt.Errorf("no staged changes in requested paths")
	}
	return nil
}

func expandCommitPathsForTicketMoves(status StatusResult, paths []string) []string {
	stems := map[string]bool{}
	for _, path := range paths {
		if _, stem, ok := ticketStatusStem(path); ok {
			stems[stem] = true
		}
	}
	if len(stems) == 0 {
		return paths
	}
	expanded := append([]string(nil), paths...)
	seen := map[string]bool{}
	for _, path := range paths {
		seen[filepath.ToSlash(filepath.Clean(path))] = true
	}
	for _, file := range status.ChangedFiles {
		for _, path := range []string{file.Path, file.OldPath} {
			if path == "" {
				continue
			}
			_, stem, ok := ticketStatusStem(path)
			if !ok || !stems[stem] {
				continue
			}
			cleaned := filepath.ToSlash(filepath.Clean(path))
			if !seen[cleaned] {
				expanded = append(expanded, path)
				seen[cleaned] = true
			}
		}
	}
	return expanded
}

// filterIndexDeleteSidePaths drops paths that are the delete side of a staged
// rename (IndexStatus "R", via OldPath) or an outright staged deletion
// (IndexStatus "D") from the given expanded path list. It exists so Commit
// can hand the Verifier only paths that still exist to read; see the call
// site comment referencing {#260720-wsdoc-commit-boundary} for why this
// filter applies to the verifier call only, not to validateCommitStatus.
func filterIndexDeleteSidePaths(status StatusResult, paths []string) []string {
	deleteSide := map[string]bool{}
	for _, file := range status.ChangedFiles {
		if file.IndexStatus == "D" {
			deleteSide[filepath.ToSlash(filepath.Clean(file.Path))] = true
		}
		if file.IndexStatus == "R" && file.OldPath != "" {
			deleteSide[filepath.ToSlash(filepath.Clean(file.OldPath))] = true
		}
	}
	kept := make([]string, 0, len(paths))
	for _, path := range paths {
		if deleteSide[filepath.ToSlash(filepath.Clean(path))] {
			continue
		}
		kept = append(kept, path)
	}
	return kept
}

func pathInCommitSet(path string, roots []string) bool {
	path = filepath.ToSlash(filepath.Clean(path))
	for _, root := range roots {
		root = filepath.ToSlash(filepath.Clean(root))
		if path == root || strings.HasPrefix(path, root+"/") {
			return true
		}
	}
	return false
}

func CommitMessage(opts CommitOptions) string {
	var b strings.Builder
	b.WriteString(opts.Title)
	if opts.Description != "" {
		b.WriteString("\n\n")
		b.WriteString(opts.Description)
	}
	b.WriteString("\n\n## AI Context\n")
	for _, item := range opts.AIContext {
		fmt.Fprintf(&b, "- %s\n", item)
	}
	writeCommitSection(&b, "## Ticket Updates", opts.UpdatedTickets)
	followupLines := make([]string, 0, len(opts.Followups))
	for _, f := range opts.Followups {
		followupLines = append(followupLines, FollowupLine(f))
	}
	writeCommitSection(&b, FollowupsHeading, followupLines)
	writeCommitSection(&b, ResolvesHeading, opts.Resolves)
	return strings.TrimRight(b.String(), "\n")
}

func writeCommitSection(b *strings.Builder, heading string, values []string) {
	if len(values) == 0 {
		return
	}
	b.WriteString("\n\n")
	writeCommitHeading(b, heading, values)
}

func writeCommitHeading(b *strings.Builder, heading string, values []string) {
	b.WriteString(heading)
	b.WriteByte('\n')
	for _, value := range values {
		fmt.Fprintf(b, "- %s\n", value)
	}
}

func trimStrings(values []string) []string {
	out := make([]string, 0, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value != "" {
			out = append(out, value)
		}
	}
	return out
}

func detectTicketChanges(ctx context.Context, runner Runner, root string) []TicketChange {
	var changes []TicketChange
	if out, err := runner.RunGit(ctx, root, "diff", "--cached", "--name-status", "--", "ai-docs/tickets"); err == nil {
		changes = append(changes, parseTicketNameStatus(out)...)
	}
	if out, err := runner.RunGit(ctx, root, "diff", "--cached", "--unified=0", "--", "ai-docs/tickets"); err == nil {
		for _, change := range parseTicketResultAdditions(out) {
			changes = mergeTicketResultAddition(changes, change)
		}
	}
	sort.Slice(changes, func(i, j int) bool {
		return ticketChangeSortKey(changes[i]) < ticketChangeSortKey(changes[j])
	})
	return changes
}

func mergeTicketResultAddition(changes []TicketChange, result TicketChange) []TicketChange {
	for i, change := range changes {
		if change.Stem == result.Stem && change.Path == result.Path {
			changes[i].ResultAdded = result.ResultAdded
			changes[i].ResultHeading = result.ResultHeading
			return changes
		}
	}
	return append(changes, result)
}

func parseTicketNameStatus(out []byte) []TicketChange {
	var changes []TicketChange
	addsByStem := map[string][]TicketChange{}
	deletesByStem := map[string][]TicketChange{}
	explicitRenameStems := map[string]bool{}
	var passthrough []TicketChange

	for _, line := range strings.Split(strings.TrimSpace(string(out)), "\n") {
		if line == "" {
			continue
		}
		fields := strings.Split(line, "\t")
		if len(fields) < 2 {
			continue
		}
		code := fields[0]
		path := fields[1]
		oldPath := ""
		if strings.HasPrefix(code, "R") && len(fields) >= 3 {
			oldPath = fields[1]
			path = fields[2]
		}
		change, ok := ticketChangeForPath(path)
		if !ok {
			continue
		}
		if oldPath != "" {
			if oldChange, ok := ticketChangeForPath(oldPath); ok {
				change.OldPath = oldPath
				change.FromStatus = oldChange.ToStatus
				explicitRenameStems[change.Stem] = true
			}
			changes = append(changes, change)
			continue
		}

		switch code {
		case "A":
			addsByStem[change.Stem] = append(addsByStem[change.Stem], change)
		case "D":
			deletesByStem[change.Stem] = append(deletesByStem[change.Stem], change)
		default:
			passthrough = append(passthrough, change)
		}
	}

	pairedAdds := map[string]bool{}
	pairedDeletes := map[string]bool{}
	for stem, adds := range addsByStem {
		deletes := deletesByStem[stem]
		if explicitRenameStems[stem] || len(adds) != 1 || len(deletes) != 1 {
			continue
		}
		add := adds[0]
		deleteChange := deletes[0]
		if add.ToStatus == deleteChange.ToStatus {
			continue
		}
		add.OldPath = deleteChange.Path
		add.FromStatus = deleteChange.ToStatus
		changes = append(changes, add)
		pairedAdds[stem] = true
		pairedDeletes[stem] = true
	}

	for stem, adds := range addsByStem {
		if pairedAdds[stem] {
			continue
		}
		for _, change := range adds {
			changes = append(changes, change)
		}
	}
	for stem, deletes := range deletesByStem {
		if pairedDeletes[stem] {
			continue
		}
		for _, change := range deletes {
			changes = append(changes, change)
		}
	}
	for _, change := range passthrough {
		changes = append(changes, change)
	}
	return changes
}

func parseTicketResultAdditions(out []byte) []TicketChange {
	var changes []TicketChange
	var current TicketChange
	for _, line := range strings.Split(string(out), "\n") {
		if strings.HasPrefix(line, "+++ b/") {
			current = TicketChange{}
			if change, ok := ticketChangeForPath(strings.TrimPrefix(line, "+++ b/")); ok {
				current = change
			}
			continue
		}
		if current.Stem == "" || !isAddedTicketResultHeading(line) {
			continue
		}
		change := current
		change.ResultAdded = true
		change.ResultHeading = strings.TrimPrefix(line, "+")
		changes = append(changes, change)
	}
	return changes
}

func isAddedTicketResultHeading(line string) bool {
	return strings.HasPrefix(line, "+### Result") || strings.HasPrefix(line, "+#### Edition")
}

func ticketChangeForPath(path string) (TicketChange, bool) {
	status, stem, ok := ticketStatusStem(path)
	if !ok {
		return TicketChange{}, false
	}
	return TicketChange{Stem: stem, Path: path, ToStatus: status}, true
}

func ticketStatusStem(path string) (string, string, bool) {
	normalized := filepath.ToSlash(filepath.Clean(path))
	const prefix = "ai-docs/tickets/"
	if !strings.HasPrefix(normalized, prefix) || !strings.HasSuffix(normalized, ".md") {
		return "", "", false
	}
	rest := strings.TrimPrefix(normalized, prefix)
	parts := strings.Split(rest, "/")
	if len(parts) != 2 {
		return "", "", false
	}
	status := parts[0]
	switch status {
	case "idea", "todo", "ready", "wip", ".done", ".dropped":
	default:
		return "", "", false
	}
	stem := strings.TrimSuffix(parts[1], ".md")
	if stem == "" {
		return "", "", false
	}
	return status, stem, true
}

func ticketChangeSortKey(change TicketChange) string {
	return strings.Join([]string{change.Stem, change.Path, change.OldPath, change.FromStatus, change.ToStatus}, "\x00")
}

func ticketChangeSummaries(changes []TicketChange) []string {
	summaries := make([]string, 0, len(changes))
	for _, change := range changes {
		switch {
		case change.FromStatus != "" && change.FromStatus != change.ToStatus && change.ResultAdded:
			summaries = append(summaries, fmt.Sprintf("%s: moved %s -> %s and added %s", change.Stem, change.FromStatus, change.ToStatus, change.ResultHeading))
		case change.FromStatus != "" && change.FromStatus != change.ToStatus:
			summaries = append(summaries, fmt.Sprintf("%s: moved %s -> %s", change.Stem, change.FromStatus, change.ToStatus))
		case change.ResultAdded:
			summaries = append(summaries, fmt.Sprintf("%s: added %s", change.Stem, change.ResultHeading))
		}
	}
	return summaries
}
