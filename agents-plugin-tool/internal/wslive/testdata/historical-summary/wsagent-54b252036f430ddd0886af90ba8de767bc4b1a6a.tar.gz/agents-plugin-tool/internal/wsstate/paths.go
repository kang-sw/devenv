package wsstate

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/kang-sw/devenv/internal/wsexec"
)

const (
	defaultCacheDirName = "ws@kang-sw-devenv"
	// EnvCacheHome names the cache root override a caller process carries.
	EnvCacheHome  = "WS_CACHE_HOME"
	schemaVersion = 1
)

type Clock func() time.Time

type Options struct {
	CacheHome string
	Now       Clock
	// Env, when set, is the environment the manager's git runs under (and
	// resolves git against); nil means this process's own.
	Env []string
}

type Layout struct {
	CacheRoot   string
	ProjectKey  string
	WorktreeKey string

	ProjectDir  string
	ProjectMeta string
	SharedDir   string
	LocksDir    string

	WorktreesDir     string
	WorktreeDir      string
	WorktreeMeta     string
	AgentsDir        string
	ReviewDir        string
	PromptDir        string
	SessionsDir      string
	WorktreeLocksDir string
	TmpDir           string
}

type ProjectMetadata struct {
	SchemaVersion int    `json:"schema_version"`
	RootPath      string `json:"root_path"`
	RootID        string `json:"root_id"`
	RepoBasename  string `json:"repo_basename"`
	ProjectKey    string `json:"project_key"`
	CreatedAt     string `json:"created_at"`
	LastSeenAt    string `json:"last_seen_at"`
}

type WorktreeMetadata struct {
	SchemaVersion int    `json:"schema_version"`
	RootPath      string `json:"root_path"`
	RootID        string `json:"root_id"`
	ProjectKey    string `json:"project_key"`
	WorktreePath  string `json:"worktree_path"`
	WorktreeID    string `json:"worktree_id"`
	WorktreeName  string `json:"worktree_name"`
	WorktreeKey   string `json:"worktree_key"`
	CreatedAt     string `json:"created_at"`
	LastSeenAt    string `json:"last_seen_at"`
}

type Manager struct {
	opts Options
}

var metadataWriteMu sync.Mutex

func NewManager(opts Options) Manager {
	return Manager{opts: opts}
}

func CacheRoot(opts Options) (string, error) {
	if opts.CacheHome != "" {
		return canonicalPath(opts.CacheHome)
	}
	if env := os.Getenv(EnvCacheHome); env != "" {
		return canonicalPath(env)
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return "", fmt.Errorf("resolve home dir: %w", err)
	}
	return filepath.Join(home, ".cache", defaultCacheDirName), nil
}

func (m Manager) Resolve(repoPath string) (Layout, ProjectMetadata, WorktreeMetadata, error) {
	root, commonRoot, err := gitIdentity(m.opts.Env, repoPath)
	if err != nil {
		return Layout{}, ProjectMetadata{}, WorktreeMetadata{}, err
	}
	cacheRoot, err := CacheRoot(m.opts)
	if err != nil {
		return Layout{}, ProjectMetadata{}, WorktreeMetadata{}, err
	}

	rootID := shortHash(commonRoot)
	worktreeID := shortHash(root)
	projectKey := rootID
	worktreeKey := projectKey
	if root != commonRoot {
		worktreeKey = projectKey + "@" + worktreeID
	}
	now := m.now().UTC().Format(time.RFC3339)

	layout := layoutFor(cacheRoot, projectKey, worktreeKey)
	project := ProjectMetadata{
		SchemaVersion: schemaVersion,
		RootPath:      commonRoot,
		RootID:        rootID,
		RepoBasename:  filepath.Base(commonRoot),
		ProjectKey:    projectKey,
		CreatedAt:     now,
		LastSeenAt:    now,
	}
	worktree := WorktreeMetadata{
		SchemaVersion: schemaVersion,
		RootPath:      commonRoot,
		RootID:        rootID,
		ProjectKey:    projectKey,
		WorktreePath:  root,
		WorktreeID:    worktreeID,
		WorktreeName:  filepath.Base(root),
		WorktreeKey:   worktreeKey,
		CreatedAt:     now,
		LastSeenAt:    now,
	}
	return layout, project, worktree, nil
}

func (m Manager) Ensure(repoPath string) (Layout, ProjectMetadata, WorktreeMetadata, error) {
	layout, project, worktree, err := m.Resolve(repoPath)
	if err != nil {
		return Layout{}, ProjectMetadata{}, WorktreeMetadata{}, err
	}
	for _, dir := range []string{
		layout.LocksDir,
		layout.AgentsDir,
		layout.ReviewDir,
		layout.PromptDir,
		layout.SessionsDir,
		layout.WorktreeLocksDir,
		layout.TmpDir,
	} {
		if err := os.MkdirAll(dir, 0o755); err != nil {
			return Layout{}, ProjectMetadata{}, WorktreeMetadata{}, fmt.Errorf("create %s: %w", dir, err)
		}
	}
	if err := upsertJSON(layout.ProjectMeta, &project); err != nil {
		return Layout{}, ProjectMetadata{}, WorktreeMetadata{}, err
	}
	if err := upsertJSON(layout.WorktreeMeta, &worktree); err != nil {
		return Layout{}, ProjectMetadata{}, WorktreeMetadata{}, err
	}
	return layout, project, worktree, nil
}

func (m Manager) now() time.Time {
	if m.opts.Now != nil {
		return m.opts.Now()
	}
	return time.Now()
}

func layoutFor(cacheRoot, projectKey, worktreeKey string) Layout {
	projectDir := filepath.Join(cacheRoot, "proj", projectKey)
	sharedDir := filepath.Join(projectDir, "shared")
	worktreesDir := filepath.Join(cacheRoot, "proj")
	worktreeDir := filepath.Join(cacheRoot, "proj", worktreeKey)
	return Layout{
		CacheRoot:        cacheRoot,
		ProjectKey:       projectKey,
		WorktreeKey:      worktreeKey,
		ProjectDir:       projectDir,
		ProjectMeta:      filepath.Join(projectDir, "project.json"),
		SharedDir:        sharedDir,
		LocksDir:         filepath.Join(sharedDir, "locks"),
		WorktreesDir:     worktreesDir,
		WorktreeDir:      worktreeDir,
		WorktreeMeta:     filepath.Join(worktreeDir, "worktree.json"),
		AgentsDir:        filepath.Join(worktreeDir, "agents"),
		ReviewDir:        filepath.Join(worktreeDir, "review-paths"),
		PromptDir:        filepath.Join(worktreeDir, "prompt-paths"),
		SessionsDir:      filepath.Join(worktreeDir, "sessions"),
		WorktreeLocksDir: filepath.Join(worktreeDir, "locks"),
		TmpDir:           filepath.Join(worktreeDir, "tmp"),
	}
}

func LayoutForWorktreeKey(cacheRoot, worktreeKey string) (Layout, error) {
	if !validWorktreeKey(worktreeKey) {
		return Layout{}, fmt.Errorf("invalid worktree key %q", worktreeKey)
	}
	projectKey := worktreeKey
	if before, _, ok := strings.Cut(worktreeKey, "@"); ok {
		projectKey = before
	}
	return layoutFor(cacheRoot, projectKey, worktreeKey), nil
}

func validWorktreeKey(value string) bool {
	if len(value) != 8 && len(value) != 17 {
		return false
	}
	for i, r := range value {
		if i == 8 && len(value) == 17 {
			if r != '@' {
				return false
			}
			continue
		}
		if !((r >= '0' && r <= '9') || (r >= 'a' && r <= 'f')) {
			return false
		}
	}
	return true
}

func gitIdentity(env []string, repoPath string) (worktreeRoot string, commonRoot string, err error) {
	abs, err := canonicalPath(repoPath)
	if err != nil {
		return "", "", err
	}
	root, err := git(env, abs, "rev-parse", "--show-toplevel")
	if err != nil {
		return "", "", err
	}
	root, err = canonicalPath(root)
	if err != nil {
		return "", "", err
	}
	commonGitDir, err := git(env, abs, "rev-parse", "--path-format=absolute", "--git-common-dir")
	if err != nil {
		return "", "", err
	}
	commonRoot, err = commonRootFromGitDir(commonGitDir)
	if err == nil {
		return root, commonRoot, nil
	}
	// commonRootFromGitDir rejected the git-common-dir. An absorbed submodule's
	// common dir lives under the superproject's .git/modules tree, so it lands
	// here by design; probe for that shape and, when confirmed, treat the
	// submodule as an independent single-worktree project (root == commonRoot).
	// Probing only on this error path is deliberate: every layout that resolves
	// today still takes its original code path, so submodule support cannot
	// reclassify it, and ordinary roots pay no extra git process.
	superprojectRoot, probeErr := git(env, abs, "rev-parse", "--show-superproject-working-tree")
	if probeErr != nil || superprojectRoot == "" {
		// Not a submodule, or the probe itself failed: preserve the original
		// fail-loud error. A worktree created inside a submodule normally lands
		// here, because git reports no superproject for a checkout the parent
		// does not track. The exception is a submodule worktree placed at a path
		// the superproject records as a gitlink: git does report a superproject
		// for it, so it resolves as an independent project instead of failing
		// loud. That is accepted — the superproject genuinely tracks that
		// checkout — but it is not the blanket fail-loud the non-goal implies.
		return "", "", err
	}
	return root, root, nil
}

func commonRootFromGitDir(gitDir string) (string, error) {
	gitDir, err := canonicalPath(gitDir)
	if err != nil {
		return "", err
	}
	if filepath.Base(gitDir) != ".git" {
		return "", fmt.Errorf("unsupported git common dir %q: expected a non-bare .git directory", gitDir)
	}
	return canonicalPath(filepath.Dir(gitDir))
}

func git(env []string, dir string, args ...string) (string, error) {
	cmd := wsexec.Command(env, "git", args...)
	cmd.Dir = dir
	out, err := cmd.Output()
	if err != nil {
		var exit *exec.ExitError
		if errors.As(err, &exit) {
			return "", fmt.Errorf("git %s: %s", strings.Join(args, " "), strings.TrimSpace(string(exit.Stderr)))
		}
		return "", fmt.Errorf("git %s: %w", strings.Join(args, " "), err)
	}
	return strings.TrimSpace(string(out)), nil
}

func canonicalPath(path string) (string, error) {
	if path == "" {
		return "", errors.New("empty path")
	}
	abs, err := filepath.Abs(path)
	if err != nil {
		return "", err
	}
	if evaluated, err := filepath.EvalSymlinks(abs); err == nil {
		abs = evaluated
	}
	return filepath.Clean(abs), nil
}

func shortHash(value string) string {
	sum := sha256.Sum256([]byte(value))
	return hex.EncodeToString(sum[:])[:8]
}

func upsertJSON(path string, next any) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return fmt.Errorf("create metadata dir %s: %w", filepath.Dir(path), err)
	}

	metadataWriteMu.Lock()
	defer metadataWriteMu.Unlock()

	now := ""
	switch v := next.(type) {
	case *ProjectMetadata:
		now = v.LastSeenAt
		if existing, ok := readProjectMetadata(path); ok && existing.CreatedAt != "" {
			v.CreatedAt = existing.CreatedAt
		}
	case *WorktreeMetadata:
		now = v.LastSeenAt
		if existing, ok := readWorktreeMetadata(path); ok && existing.CreatedAt != "" {
			v.CreatedAt = existing.CreatedAt
		}
	}
	if now == "" {
		return fmt.Errorf("metadata %s has empty last_seen_at", path)
	}

	data, err := json.MarshalIndent(next, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal metadata %s: %w", path, err)
	}
	tmpFile, err := os.CreateTemp(filepath.Dir(path), filepath.Base(path)+".*.tmp")
	if err != nil {
		return fmt.Errorf("create metadata temp %s: %w", path, err)
	}
	tmp := tmpFile.Name()
	if _, err := tmpFile.Write(append(data, '\n')); err != nil {
		_ = tmpFile.Close()
		_ = os.Remove(tmp)
		return fmt.Errorf("write metadata %s: %w", tmp, err)
	}
	if err := tmpFile.Close(); err != nil {
		_ = os.Remove(tmp)
		return fmt.Errorf("close metadata %s: %w", tmp, err)
	}
	if err := replaceFile(tmp, path); err != nil {
		_ = os.Remove(tmp)
		return fmt.Errorf("replace metadata %s: %w", path, err)
	}
	return nil
}

func replaceFile(tmp, path string) error {
	return AtomicReplaceFile(tmp, path)
}

func readProjectMetadata(path string) (ProjectMetadata, bool) {
	var data ProjectMetadata
	raw, err := os.ReadFile(path)
	if err != nil {
		return data, false
	}
	return data, json.Unmarshal(raw, &data) == nil
}

func readWorktreeMetadata(path string) (WorktreeMetadata, bool) {
	var data WorktreeMetadata
	raw, err := os.ReadFile(path)
	if err != nil {
		return data, false
	}
	return data, json.Unmarshal(raw, &data) == nil
}
