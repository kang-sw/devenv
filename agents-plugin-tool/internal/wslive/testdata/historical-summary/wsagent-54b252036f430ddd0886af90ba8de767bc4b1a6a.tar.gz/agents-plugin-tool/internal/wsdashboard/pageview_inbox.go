package wsdashboard

import (
	"cmp"
	"html/template"
	"os"
	"slices"
	"strconv"
	"strings"

	"github.com/kang-sw/devenv/internal/wsi18n"
	"github.com/kang-sw/devenv/internal/wsinbox"
	"github.com/kang-sw/devenv/internal/wslive"
)

// HeldView is a message the user sent from the page that the session has
// not received yet: it sits in the session's board-answer inbox until the
// host adapter drains it at the end of a turn, or at the next tool boundary
// once promoted to steering, and can be cancelled until then.
type HeldView struct {
	// ID is the inbox entry's ID, which the cancel and steer controls name.
	ID string
	// Steer is set once the user promoted the message to steering; the
	// bubble then shows a steer marker instead of the steer control.
	Steer bool
	// At is the send's time (epoch ms), kept by a steer.
	At int64
	// Parts are the send's text; an entry merged before sends stopped
	// merging holds one per send, and the bubble divides them.
	Parts  []string
	Chips  []wsinbox.Chip
	Topics []wsinbox.TopicNote
	// Mentions are the board text the message points at, shown as capsules
	// after the answer capsules.
	Mentions []wsinbox.Mention
	// Picks and Consoles are the picked page elements and attached console
	// errors, shown as capsules after the mentions.
	Picks    []wsinbox.Pick
	Consoles []wsinbox.Console
	// Images are the entry's attached images.
	Images []AttachmentView
	// Command is a command entry's slash command; the bubble shows its
	// typed line and offers no steer control, since a command waits for the
	// turn end.
	Command *wsinbox.Command
}

// Answers are the held message's chips and topic notes as the capsules a
// delivered message's answer block shows (ConvEntry.Answers), one per chip.
func (h HeldView) Answers() []wsinbox.AnswerLine {
	var out []wsinbox.AnswerLine
	for _, c := range h.Chips {
		out = append(out, wsinbox.AnswerLine{IDs: c.ID, Value: c.Answer, Note: c.Note})
	}
	for _, t := range h.Topics {
		out = append(out, wsinbox.AnswerLine{Topic: t.Topic, Note: t.Note})
	}
	return out
}

// AttachmentView is one image a message carries. Src is the attachment
// route's URL when Path names a file in this session's attachments
// directory; the page shows any other path as text. Num is the image's
// number, which the message's "[Image #N]" markers name it by; 0 for an
// image a message carried before images were numbered.
type AttachmentView struct {
	Path, Name, Src string
	Num             int
}

// attachmentView maps image n's path to its view: a thumbnail for a file
// that exists in attachDir, the session replyID's attachments directory,
// else the path, so a removed attachment shows as text, not a broken image.
func attachmentView(attachDir, replyID string, n int, path string) AttachmentView {
	if name, ok := wsinbox.AttachmentName(attachDir, path); ok && ValidReplyID(replyID) && regularFile(path) {
		return AttachmentView{Path: path, Name: name, Src: AttachmentSrc(replyID, name), Num: n}
	}
	return AttachmentView{Path: path, Num: n}
}

// markedText renders a message text with each image marker
// (wsinbox.ImageMarker) as a tag, escaping the rest; the page shows the text
// as it is otherwise, whitespace kept.
func markedText(lang, text string) template.HTML {
	var b strings.Builder
	last := 0
	wsinbox.ImageMarkers(text, func(start, end, n int) {
		b.WriteString(template.HTMLEscapeString(text[last:start]))
		b.WriteString(`<span class="imgtag" title="` + template.HTMLEscapeString(wsi18n.T(lang, "imgtag.title", n)) + `">#` + strconv.Itoa(n) + `</span>`)
		last = end
	})
	b.WriteString(template.HTMLEscapeString(text[last:]))
	return template.HTML(b.String())
}

func regularFile(path string) bool {
	info, err := os.Stat(path)
	return err == nil && info.Mode().IsRegular()
}

// splitUserEntries takes each user entry's answer block
// (wsinbox.ParseAnswerBlock), the mentions after it (wsinbox.ParseMentions),
// the picks and console blocks after those (wsinbox.ParseWebElements), and
// attached images (userImages) out of its text; a malformed block or element
// stays in the text.
func splitUserEntries(entries []ConvEntry, attachDir, replyID string) {
	for i, e := range entries {
		if e.Kind == wslive.RingUser {
			text := e.Text
			if lines, rest, ok := wsinbox.ParseAnswerBlock(text); ok {
				entries[i].Answers, text = lines, rest
			}
			entries[i].Mentions, text = wsinbox.ParseMentions(text)
			entries[i].Picks, entries[i].Consoles, text = wsinbox.ParseWebElements(text)
			entries[i].Text, entries[i].Images = userImages(text, attachDir, replyID)
		}
	}
}

// userImages takes the image lines (wsinbox.ParseImageLine: the numbered
// form and the older unnumbered one) that name this session's existing
// attachments out of a delivered user message, returning the text left and
// their views. A line naming any other path, or a removed attachment, stays
// in the text.
func userImages(text, attachDir, replyID string) (string, []AttachmentView) {
	if !strings.Contains(text, "[image: ") && !strings.Contains(text, "Image #") {
		return text, nil
	}
	var kept []string
	var images []AttachmentView
	for _, line := range strings.Split(text, "\n") {
		if n, path, ok := wsinbox.ParseImageLine(strings.TrimSpace(line)); ok {
			if v := attachmentView(attachDir, replyID, n, path); v.Src != "" {
				images = append(images, v)
				continue
			}
		}
		// Keep one blank line where a removed block left two.
		if strings.TrimSpace(line) == "" && len(kept) > 0 && strings.TrimSpace(kept[len(kept)-1]) == "" {
			continue
		}
		kept = append(kept, line)
	}
	if len(images) == 0 {
		return text, nil
	}
	return strings.Trim(strings.Join(kept, "\n"), "\n"), images
}

// SentMark is the latest answer sent for one board item, from the inbox:
// Held while the message holding it is undrained.
type SentMark struct {
	ID, Answer, Note string
	Held             bool
}

// heldViews lists the held entries in the order given, the inbox's queue
// order (wsinbox.Held: steered, then the rest); attachDir and replyID map
// their images as attachmentView does.
func heldViews(held []wsinbox.Record, attachDir, replyID string) []HeldView {
	out := make([]HeldView, 0, len(held))
	for _, r := range held {
		v := HeldView{ID: r.ID(), Steer: r.Entry.Steer, At: r.Entry.SentAt, Parts: r.Entry.Parts, Chips: r.Entry.Chips, Topics: r.Entry.Topics, Mentions: r.Entry.Mentions, Picks: r.Entry.Picks, Consoles: r.Entry.Consoles, Command: r.Entry.Command}
		nums := r.Entry.Nums()
		for i, path := range r.Entry.Images {
			v.Images = append(v.Images, attachmentView(attachDir, replyID, nums[i], path))
		}
		out = append(out, v)
	}
	return out
}

// newestTurn is the conversation's newest finished turn: the newest RingTurn
// record of ring (oldest first); false when ring holds none.
func newestTurn(ring []wslive.RingRecord) (wslive.RingRecord, bool) {
	for i := len(ring) - 1; i >= 0; i-- {
		if ring[i].Kind == wslive.RingTurn {
			return ring[i], true
		}
	}
	return wslive.RingRecord{}, false
}

// turnStart is a finished turn's start, epoch milliseconds: its record's
// time less its duration. False when the turn carries no duration (its
// turn_end came after the state lost the turn's start, as across a daemon
// restart): its start would read as its end, and a chip sent during the
// turn would count as sent before it.
//
// The start is approximate. At is the ring file's write stamp, taken after
// the adapter's turn_end reached ws-mcp and the ring flushed, while
// DurationMs comes from the event clocks, so the start runs late by that
// latency. The answer check's held-message gate and its coalescing delay
// absorb it.
func turnStart(turn wslive.RingRecord) (int64, bool) {
	if turn.DurationMs <= 0 {
		return 0, false
	}
	return turn.At.UnixMilli() - turn.DurationMs, true
}

// settledTurnStart is the start of the conversation's newest finished turn
// (newestTurn, turnStart); 0 when there is none or it has no usable start.
// A chip sent before it was in the inbox when that turn began, and both
// adapters drain the inbox as a turn starts, so the turn has handled it.
func settledTurnStart(ring []wslive.RingRecord) int64 {
	turn, ok := newestTurn(ring)
	if !ok {
		return 0
	}
	start, _ := turnStart(turn)
	return start
}

// sentMarks derives each board item's sent mark from the inbox: the newest
// chip for the item across the drained records and then the held entries, so
// a held answer shows over an earlier delivered one. The drained records are
// on disk, so a mark survives a page reload while the newest DrainedCap
// records hold it. reasked maps a board item's ID to its latest re-ask time
// (epoch ms, PageContent.Reasked): a chip for it sent before that time
// answered an earlier ask and marks nothing, so the item waits on the user
// again. A chip without a send time (written before chips carried one)
// keeps its mark.
//
// settled is the newest settled turn's start (settledTurnStart, 0 for none):
// a drained note-only chip (no answer value) sent before it was delivered
// to a turn that has finished, so it clears its item's mark, and the item
// waits on the user again; an older value chip's mark does not come back.
// The note stays in the delivered message and the drained record. A held
// chip, and a value chip, keep their marks.
func sentMarks(drained, held []wsinbox.Record, reasked map[int]int64, settled int64) []SentMark {
	var order []string
	seen := map[string]bool{}
	marks := map[string]SentMark{}
	stale := func(c wsinbox.Chip) bool {
		if c.SentAt == 0 || len(reasked) == 0 {
			return false
		}
		id, err := strconv.Atoi(c.ID)
		if err != nil {
			return false
		}
		at, ok := reasked[id]
		return ok && c.SentAt < at
	}
	add := func(records []wsinbox.Record, isHeld bool) {
		// The newest send's chip wins, so read the chips in send order: a
		// steer moves an entry ahead of later sends in queue order (held)
		// and gives it a newer name (drained). A chip's own send time
		// counts (an entry merged before sends stopped merging holds chips
		// of several sends), its entry's when it has none; the sort is
		// stable, so a tie keeps the given order.
		type timed struct {
			c  wsinbox.Chip
			at int64
		}
		var list []timed
		for _, r := range records {
			for _, c := range r.Entry.Chips {
				at := c.SentAt
				if at == 0 {
					at = r.Entry.SentAt
				}
				list = append(list, timed{c, at})
			}
		}
		slices.SortStableFunc(list, func(a, b timed) int { return cmp.Compare(a.at, b.at) })
		for _, tc := range list {
			c := tc.c
			if stale(c) {
				continue
			}
			if !isHeld && c.Answer == "" && c.SentAt > 0 && c.SentAt < settled {
				delete(marks, c.ID)
				continue
			}
			if !seen[c.ID] {
				seen[c.ID] = true
				order = append(order, c.ID)
			}
			marks[c.ID] = SentMark{ID: c.ID, Answer: c.Answer, Note: c.Note, Held: isHeld}
		}
	}
	add(drained, false)
	add(held, true)
	out := make([]SentMark, 0, len(order))
	for _, id := range order {
		if m, ok := marks[id]; ok {
			out = append(out, m)
		}
	}
	return out
}
