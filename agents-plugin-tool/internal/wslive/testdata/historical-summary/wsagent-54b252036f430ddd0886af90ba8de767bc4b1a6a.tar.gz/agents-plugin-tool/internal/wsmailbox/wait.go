package wsmailbox

import (
	"errors"
	"time"

	"github.com/kang-sw/devenv/internal/wsinbox"
	"github.com/kang-sw/devenv/internal/wswake"
)

// wait.go implements the host-neutral half of the wake path
// (260913-feat-cross-session-mailbox-wake Phase 1, Decision 6): a
// level-triggered blocking check over the durable queues a caller is
// entitled to drain — the owner's name-keyed inbox when a slug is set, and
// always the caller's own reply-id queue — with no MCP tool call and no
// polling at the tool-call layer (Cross-Child Decision 16). The internal
// recheck loop below is the CLI process blocking on itself, which Decision 6
// explicitly permits ("blocking lives in a CLI process... never an MCP
// tool"); it is not the "poll loop" Decision 16 forbids, which is about a
// caller repeatedly re-invoking a tool.
//
// Wait never drains: draining is mailbox.recv's job (server-gated,
// session-state-aware). This file only peeks and reports, so re-invoking the
// agent after Wait returns always goes through the normal recv path with no
// risk of double-consuming a message this CLI process already "saw".

// WaitTarget identifies which durable queues a Wait call should check.
type WaitTarget struct {
	// SessionKey is the caller's own session_key: always used to compute the
	// caller's reply-id queue, and compared against the named inbox's Owner
	// pointer when Slug is set.
	SessionKey string
	// Root is the caller's own canonicalized worktree/clone root, needed to
	// resolve a worktree/clone-scope Slug's store path (see
	// ai-docs/manuals/ws-mcp.md on why process cwd is unreliable). Ignored
	// for a machine-scope Slug or when Slug is empty.
	Root string
	// Slug is an optional explicit "name@scope" to also check the named
	// inbox for. Empty means reply-id-only (the env-less path, wake half of
	// Decision 14): Wait never re-derives a slug from WS_MAILBOX/
	// WS_MAILBOX_AUTO itself, because a fresh CLI process re-reading
	// WS_MAILBOX_AUTO would mint a different random stem than the
	// already-registered server process — the caller passes the address it
	// already knows (from the workflow ambient block or lookup_peers' self
	// entry) instead.
	Slug string
	// Paths resolves the stores; the zero value is this process's
	// environment. A wait the dashboard daemon runs for a launcher sets it
	// from the launcher's environment.
	Paths Paths
	// InboxDir is the session's board-answer inbox directory (internal/
	// wsinbox) to also watch; empty means not watched. The caller derives it
	// because the dashboard's state directory is not this package's to know.
	// Wait only peeks at it, never drains.
	InboxDir string
	// InboxSteerOnly narrows the InboxDir watch to entries marked for
	// steering: a held follow-up does not wake the wait, a steered one does.
	InboxSteerOnly bool
	// InboxInterrupt also watches InboxDir for interrupt entries, counted in
	// WaitResult.Interrupt, beside the held-message watch.
	InboxInterrupt bool
	// InboxInterruptOnly watches InboxDir for interrupt entries alone: no
	// held message, steered or not, wakes the wait. It implies
	// InboxInterrupt.
	InboxInterruptOnly bool
}

// WaitResult is one Wait call's outcome: the envelopes found in each queue
// (never drained), or TimedOut when neither held anything before the
// deadline.
type WaitResult struct {
	TimedOut bool
	Named    []Envelope // from the named inbox, when Slug was set and owned
	Reply    []Envelope // from the caller's own reply-id queue
	// Board is how many held messages the watched inbox (WaitTarget.InboxDir)
	// had, only the steered ones under InboxSteerOnly; zero when it is not
	// watched, under InboxInterruptOnly, or empty. It never counts an
	// interrupt entry.
	Board int
	// Interrupt is how many interrupt entries the watched inbox had; zero
	// unless InboxInterrupt or InboxInterruptOnly is set.
	Interrupt int
	// Entry names are stable identities for stream deduplication, including
	// same-count replacements after a board merge or promotion.
	boardNames, interruptNames []string
}

// Total returns the combined unread mail count across both queues; held
// inbox entries are counted in Board, not here.
func (r WaitResult) Total() int { return len(r.Named) + len(r.Reply) }

// Woke reports whether this result is an arrival: unread mail, a held
// message in a watched inbox, or a watched interrupt entry.
func (r WaitResult) Woke() bool { return r.Total() > 0 || r.Board > 0 || r.Interrupt > 0 }

// DefaultWaitPoll is Wait's internal recheck interval when WaitOptions.Poll
// is unset. Implementation-chosen default, not a cross-ticket contract.
const DefaultWaitPoll = 500 * time.Millisecond

// WakeBackstopPoll is the recheck interval of a Wait whose WaitOptions.Wake
// is set and Poll unset: the wakes carry the arrivals, and this backstop
// covers a lost one.
const WakeBackstopPoll = 10 * time.Second

// WakeNudgeInterval is the least time between two nudge-driven rechecks of
// one Wait. A nudge names no store, and nudges for unrelated stores can
// arrive many times a second, so a nudge inside the interval defers to one
// trailing recheck at the interval's end.
const WakeNudgeInterval = time.Second

// WaitOptions configures one Wait call. Now/Sleep are the injectable
// clock/sleep (mirroring mailbox_runtime.go's mailboxNow convention) so
// tests exercise the full blocking-then-wakes-on-arrival path without real
// wall-clock delay.
type WaitOptions struct {
	// Timeout bounds how long Wait blocks with nothing to report. Zero means
	// block until mail arrives (no deadline).
	Timeout time.Duration
	// Poll is the internal recheck interval; <= 0 defaults to
	// DefaultWaitPoll, or to WakeBackstopPoll when Wake is set.
	Poll time.Duration
	// Now defaults to time.Now.
	Now func() time.Time
	// Sleep defaults to time.Sleep. A wait with Wake set never sleeps; it
	// waits on After instead.
	Sleep func(time.Duration)
	// Wake, when set, also ends a wait between polls: a hard wake rechecks
	// at once, a nudge at most once per WakeNudgeInterval plus one trailing
	// recheck for nudges that land inside it. Nil polls alone.
	Wake *wswake.Hub
	// After is a Wake wait's timer: it returns a channel that receives once
	// d has passed. Nil uses a real timer.
	After func(d time.Duration) <-chan time.Time
	// Done, when set, ends the wait early: Wait returns ErrWaitCancelled
	// once it closes, within one Poll. A wait the dashboard daemon hosts
	// for a launcher sets it to the stream's end.
	Done <-chan struct{}
}

// ErrWaitCancelled reports that WaitOptions.Done closed before mail
// arrived or Timeout elapsed.
var ErrWaitCancelled = errors.New("mailbox wait cancelled")

// Wait performs target's level-triggered check: an immediate peek, returned
// at once if either queue already holds unread mail, or a watched inbox a held entry (Decision 6's lost-
// wakeup avoidance — the arm/drain gap is covered because the store is
// durable and this is a synchronous read on startup, not a wait on a bare
// arrival event), otherwise blocking in Poll-sized increments until mail
// arrives or Timeout elapses.
func Wait(target WaitTarget, opts WaitOptions) (WaitResult, error) {
	// Resolve once, outside the loop: for a worktree/clone Slug,
	// PathForScope resolves through wsnote/wsstate, which shells out to git
	// and rewrites project/worktree metadata (see ai-docs/manuals/ws-mcp.md
	// on why process cwd alone cannot stand in for this). Re-resolving on
	// every poll tick would spawn a git process and rewrite metadata every
	// DefaultWaitPoll for the whole armed-wait lifetime (unbounded with
	// Timeout == 0), and would also mean one transient resolution failure
	// hours into an idle wait kills the wake path outright. Only the cheap
	// Load/LoadReplyStore disk reads repeat per tick below.
	resolved, err := resolveWaitTarget(target)
	if err != nil {
		return WaitResult{}, err
	}
	return waitLoop(resolved.peek, opts)
}

// waitLoop is Wait's recheck loop over peek.
func waitLoop(peek func() (WaitResult, error), opts WaitOptions) (WaitResult, error) {
	now := opts.Now
	if now == nil {
		now = time.Now
	}
	sleep := opts.Sleep
	if sleep == nil {
		sleep = time.Sleep
	}
	if opts.Done != nil {
		// A cancellable wait sleeps on the timer and Done together, so the
		// cancel takes at once instead of after the current tick.
		inner := sleep
		sleep = func(d time.Duration) {
			if opts.Sleep != nil {
				inner(d)
				return
			}
			t := time.NewTimer(d)
			defer t.Stop()
			select {
			case <-t.C:
			case <-opts.Done:
			}
		}
	}
	poll := opts.Poll
	if poll <= 0 {
		poll = DefaultWaitPoll
		if opts.Wake != nil {
			poll = WakeBackstopPoll
		}
	}

	hasDeadline := opts.Timeout > 0
	var deadline time.Time
	if hasDeadline {
		deadline = now().Add(opts.Timeout)
	}
	if opts.Wake != nil {
		return wakeLoop(peek, opts, now, poll, hasDeadline, deadline)
	}

	for {
		if opts.Done != nil {
			select {
			case <-opts.Done:
				return WaitResult{}, ErrWaitCancelled
			default:
			}
		}
		result, err := peek()
		if err != nil {
			return WaitResult{}, err
		}
		if result.Woke() {
			return result, nil
		}
		if !hasDeadline {
			sleep(poll)
			continue
		}
		remaining := deadline.Sub(now())
		if remaining <= 0 {
			return WaitResult{TimedOut: true}, nil
		}
		if remaining < poll {
			sleep(remaining)
		} else {
			sleep(poll)
		}
	}
}

// wakeLoop is waitLoop with opts.Wake set: between rechecks it waits on
// the poll timer, the hub's signals, and Done together. A nudge rechecks at
// once when the last nudge-driven recheck is WakeNudgeInterval old or
// older; otherwise it arms one trailing recheck at that interval's end and
// stops listening for nudges until then, so a burst costs one recheck per
// interval plus the trailing one.
func wakeLoop(peek func() (WaitResult, error), opts WaitOptions, now func() time.Time, poll time.Duration, hasDeadline bool, deadline time.Time) (WaitResult, error) {
	timer := func(d time.Duration) (<-chan time.Time, func()) {
		if opts.After != nil {
			return opts.After(d), func() {}
		}
		t := time.NewTimer(d)
		return t.C, func() { t.Stop() }
	}
	sub := opts.Wake.Subscribe()
	defer sub.Close()
	var lastNudge time.Time
	var trailing <-chan time.Time
	stopTrailing := func() {}
	defer func() { stopTrailing() }()

	for {
		if opts.Done != nil {
			select {
			case <-opts.Done:
				return WaitResult{}, ErrWaitCancelled
			default:
			}
		}
		result, err := peek()
		if err != nil {
			return WaitResult{}, err
		}
		if result.Woke() {
			return result, nil
		}
		d := poll
		if hasDeadline {
			remaining := deadline.Sub(now())
			if remaining <= 0 {
				return WaitResult{TimedOut: true}, nil
			}
			if remaining < d {
				d = remaining
			}
		}
		tick, stopTick := timer(d)
	block:
		for {
			nudge := sub.Nudge()
			if trailing != nil {
				nudge = nil
			}
			select {
			case <-tick:
				break block
			case <-sub.Hard():
				break block
			case <-trailing:
				trailing = nil
				// The trailing recheck covers every nudge that came since.
				select {
				case <-sub.Nudge():
				default:
				}
				lastNudge = now()
				break block
			case <-nudge:
				t := now()
				if t.Sub(lastNudge) >= WakeNudgeInterval {
					lastNudge = t
					break block
				}
				trailing, stopTrailing = timer(lastNudge.Add(WakeNudgeInterval).Sub(t))
			case <-opts.Done:
				stopTick()
				return WaitResult{}, ErrWaitCancelled
			}
		}
		stopTick()
	}
}

// resolvedWaitTarget holds the one-time-resolved paths/identity a Wait
// call's recheck loop needs, computed once by resolveWaitTarget.
type resolvedWaitTarget struct {
	sessionKey string
	namedPath  string // "" when target.Slug was empty
	namedName  string
	replyPath  string
	replyID    string
	inboxDir   string // "" when the board-answer inbox is not watched
	steerOnly  bool   // count only the inbox entries marked for steering
	interrupt  bool   // also count the interrupt entries
	noBoard    bool   // count no held message, only interrupt entries
}

// resolveWaitTarget performs every resolution step that only needs to run
// once per Wait call: parsing/resolving an explicit Slug's store path, and
// deriving the caller's reply-id + registry path.
func resolveWaitTarget(target WaitTarget) (resolvedWaitTarget, error) {
	r := resolvedWaitTarget{
		sessionKey: target.SessionKey,
		inboxDir:   target.InboxDir,
		steerOnly:  target.InboxSteerOnly,
		interrupt:  target.InboxInterrupt || target.InboxInterruptOnly,
		noBoard:    target.InboxInterruptOnly,
	}

	if target.Slug != "" {
		name, scope, err := ParseSlugScope(target.Slug)
		if err != nil {
			return resolvedWaitTarget{}, err
		}
		path, err := target.Paths.ForScope(scope, target.Root)
		if err != nil {
			return resolvedWaitTarget{}, err
		}
		r.namedName = name
		r.namedPath = path
	}

	r.replyID = ReplyID(target.SessionKey)
	replyPath, err := target.Paths.ReplyRegistry()
	if err != nil {
		return resolvedWaitTarget{}, err
	}
	r.replyPath = replyPath
	return r, nil
}

// peek reads both queues once from their already-resolved paths, without
// draining either.
func (r resolvedWaitTarget) peek() (WaitResult, error) {
	var named []Envelope
	if r.namedPath != "" {
		store, err := Load(r.namedPath)
		if err != nil {
			return WaitResult{}, err
		}
		if p, ok := store.Presence[r.namedName]; ok && p.Owner != "" && p.Owner == r.sessionKey {
			named = store.Queues[r.namedName]
		}
	}

	replyStore, err := LoadReplyStore(r.replyPath)
	if err != nil {
		return WaitResult{}, err
	}
	result := WaitResult{Named: named, Reply: replyStore.Queues[r.replyID]}
	if r.inboxDir != "" && !r.noBoard {
		names, err := wsinbox.MessageNames(r.inboxDir)
		if r.steerOnly {
			names, err = wsinbox.SteerNames(r.inboxDir)
		}
		if err != nil {
			return WaitResult{}, err
		}
		result.Board = len(names)
		result.boardNames = names
	}
	if r.inboxDir != "" && r.interrupt {
		names, err := wsinbox.InterruptNames(r.inboxDir)
		if err != nil {
			return WaitResult{}, err
		}
		result.Interrupt = len(names)
		result.interruptNames = names
	}
	return result, nil
}

// NamedInboxStatus is a one-time startup diagnostic (never part of the
// recheck loop): it reports whether target.Slug currently has a presence
// record and is owned by target.SessionKey, so a CLI caller can warn when an
// armed --slug wait cannot actually reach the named inbox it names instead
// of degrading to a reply-id-only wait with no explanation (an unbound,
// stale, or wrong-root slug otherwise times out silently reporting "no
// unread mail" while the named inbox it was meant to watch fills up).
// Returns present=false, owned=false, err=nil when target.Slug is empty.
func NamedInboxStatus(target WaitTarget) (present, owned bool, err error) {
	if target.Slug == "" {
		return false, false, nil
	}
	name, scope, err := ParseSlugScope(target.Slug)
	if err != nil {
		return false, false, err
	}
	path, err := target.Paths.ForScope(scope, target.Root)
	if err != nil {
		return false, false, err
	}
	store, err := Load(path)
	if err != nil {
		return false, false, err
	}
	p, ok := store.Presence[name]
	if !ok {
		return false, false, nil
	}
	return true, p.Owner != "" && p.Owner == target.SessionKey, nil
}
